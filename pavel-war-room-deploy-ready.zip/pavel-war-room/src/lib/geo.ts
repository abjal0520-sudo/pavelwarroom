import type { GeoTag } from "./types";

type Kind = GeoTag["kind"];
// key, en, bn, lat, lng, kind, parent-country-key, regex source
type Row = [string, string, string, number, number, Kind, string, string];

const ROWS: Row[] = [
  ["russia", "Russia", "রাশিয়া", 55.75, 37.62, "country", "", "\\b(russia|russian|kremlin|moscow|putin)\\b"],
  ["ukraine", "Ukraine", "ইউক্রেন", 50.45, 30.52, "country", "", "\\b(ukraine|ukrainian|kyiv|kiev|zelensky\\w*)\\b"],
  ["china", "China", "চীন", 39.9, 116.4, "country", "", "\\b(china|chinese|beijing|pla)\\b"],
  ["taiwan", "Taiwan", "তাইওয়ান", 25.03, 121.56, "country", "", "\\b(taiwan|taiwanese|taipei)\\b"],
  ["usa", "United States", "যুক্তরাষ্ট্র", 38.9, -77.04, "country", "", "\\b(united states|u\\.s\\.|us (forces|military|troops|navy|strikes?)|american|pentagon|washington|trump)\\b"],
  ["israel", "Israel", "ইসরায়েল", 31.77, 35.21, "country", "", "\\b(israel|israeli|idf|tel aviv|jerusalem)\\b"],
  ["gaza", "Gaza / Palestine", "গাজা / ফিলিস্তিন", 31.5, 34.45, "country", "", "\\b(gaza|hamas|palestin\\w*|west bank|rafah)\\b"],
  ["iran", "Iran", "ইরান", 35.69, 51.39, "country", "", "\\b(iran|iranian|tehran|irgc)\\b"],
  ["iraq", "Iraq", "ইরাক", 33.31, 44.37, "country", "", "\\b(iraq|iraqi|baghdad)\\b"],
  ["syria", "Syria", "সিরিয়া", 33.51, 36.29, "country", "", "\\b(syria|syrian|damascus)\\b"],
  ["lebanon", "Lebanon", "লেবানন", 33.89, 35.5, "country", "", "\\b(lebanon|lebanese|hezbollah|beirut)\\b"],
  ["yemen", "Yemen", "ইয়েমেন", 15.35, 44.2, "country", "", "\\b(yemen|yemeni|houthi\\w*|sanaa)\\b"],
  ["saudi", "Saudi Arabia", "সৌদি আরব", 24.71, 46.68, "country", "", "\\b(saudi|riyadh)\\b"],
  ["turkey", "Türkiye", "তুরস্ক", 39.93, 32.86, "country", "", "\\b(turkey|turkish|türkiye|ankara)\\b"],
  ["nkorea", "North Korea", "উত্তর কোরিয়া", 39.03, 125.75, "country", "", "\\b(north korea\\w*|pyongyang|kim jong)\\b"],
  ["skorea", "South Korea", "দক্ষিণ কোরিয়া", 37.57, 126.98, "country", "", "\\b(south korea\\w*|seoul)\\b"],
  ["japan", "Japan", "জাপান", 35.68, 139.69, "country", "", "\\b(japan|japanese|tokyo)\\b"],
  ["india", "India", "ভারত", 28.61, 77.21, "country", "", "\\b(india|indian|new delhi|delhi)\\b"],
  ["pakistan", "Pakistan", "পাকিস্তান", 33.69, 73.05, "country", "", "\\b(pakistan|pakistani|islamabad)\\b"],
  ["afghanistan", "Afghanistan", "আফগানিস্তান", 34.53, 69.17, "country", "", "\\b(afghanistan|afghan|taliban|kabul)\\b"],
  ["bangladesh", "Bangladesh", "বাংলাদেশ", 23.81, 90.41, "country", "", "\\b(bangladesh\\w*|dhaka)\\b"],
  ["myanmar", "Myanmar", "মিয়ানমার", 19.76, 96.08, "country", "", "\\b(myanmar|burma|burmese|rohingya)\\b"],
  ["sudan", "Sudan", "সুদান", 15.5, 32.56, "country", "", "\\b(sudan\\w*|khartoum|rsf|el fasher|darfur)\\b"],
  ["ethiopia", "Ethiopia", "ইথিওপিয়া", 9.03, 38.74, "country", "", "\\b(ethiopia\\w*|tigray)\\b"],
  ["somalia", "Somalia", "সোমালিয়া", 2.05, 45.32, "country", "", "\\b(somalia\\w*|mogadishu|al-shabaab)\\b"],
  ["libya", "Libya", "লিবিয়া", 32.89, 13.19, "country", "", "\\b(libya\\w*|tripoli)\\b"],
  ["drc", "DR Congo", "ডিআর কঙ্গো", -4.32, 15.31, "country", "", "\\b(congo|congolese|goma|m23)\\b"],
  ["mali", "Mali / Sahel", "মালি / সাহেল", 12.64, -8.0, "country", "", "\\b(mali|sahel|burkina faso)\\b"],
  ["nigeria", "Nigeria", "নাইজেরিয়া", 9.08, 7.4, "country", "", "\\b(nigeria\\w*|abuja)\\b"],
  ["egypt", "Egypt", "মিশর", 30.04, 31.24, "country", "", "\\b(egypt\\w*|cairo)\\b"],
  ["poland", "Poland", "পোল্যান্ড", 52.23, 21.01, "country", "", "\\b(poland|polish|warsaw)\\b"],
  ["germany", "Germany", "জার্মানি", 52.52, 13.4, "country", "", "\\b(germany|german|berlin)\\b"],
  ["france", "France", "ফ্রান্স", 48.86, 2.35, "country", "", "\\b(france|french|paris|macron)\\b"],
  ["uk", "United Kingdom", "যুক্তরাজ্য", 51.5, -0.12, "country", "", "\\b(britain|british|u\\.k\\.|uk (government|military|forces|navy)|london|royal navy)\\b"],
  ["belarus", "Belarus", "বেলারুশ", 53.9, 27.57, "country", "", "\\b(belarus\\w*|minsk)\\b"],
  ["armenia", "Armenia", "আর্মেনিয়া", 40.18, 44.51, "country", "", "\\b(armenia\\w*|yerevan)\\b"],
  ["azerbaijan", "Azerbaijan", "আজারবাইজান", 40.41, 49.87, "country", "", "\\b(azerbaijan\\w*|baku)\\b"],
  ["venezuela", "Venezuela", "ভেনেজুয়েলা", 10.49, -66.88, "country", "", "\\b(venezuela\\w*|caracas)\\b"],
  ["philippines", "Philippines", "ফিলিপাইন", 14.6, 120.98, "country", "", "\\b(philippines|philippine|filipino|manila)\\b"],
  ["finland", "Finland", "ফিনল্যান্ড", 60.17, 24.94, "country", "", "\\b(finland|finnish|helsinki)\\b"],
  ["lithuania", "Lithuania", "লিথুয়ানিয়া", 54.69, 25.28, "country", "", "\\b(lithuania\\w*|vilnius|kaliningrad)\\b"],
  ["qatar", "Qatar", "কাতার", 25.29, 51.53, "country", "", "\\b(qatar\\w*|doha)\\b"],
  ["uae", "UAE", "সংযুক্ত আরব আমিরাত", 24.45, 54.38, "country", "", "\\b(uae|emirati|abu dhabi|dubai)\\b"],
  ["jordan", "Jordan", "জর্ডান", 31.95, 35.93, "country", "", "\\b(jordan|jordanian|amman)\\b"],
  ["greece", "Greece", "গ্রিস", 37.98, 23.73, "country", "", "\\b(greece|greek|athens)\\b"],
  ["haiti", "Haiti", "হাইতি", 18.54, -72.34, "country", "", "\\b(haiti\\w*)\\b"],
  ["mexico", "Mexico", "মেক্সিকো", 19.43, -99.13, "country", "", "\\b(mexico|mexican)\\b"],
  ["nato", "NATO", "ন্যাটো", 50.88, 4.42, "country", "", "\\b(nato)\\b"],
  // cities -> parent country
  ["kharkiv", "Kharkiv", "খারকিভ", 49.99, 36.23, "city", "ukraine", "\\b(kharkiv|kharkov)\\b"],
  ["odesa", "Odesa", "ওডেসা", 46.48, 30.72, "city", "ukraine", "\\b(odesa|odessa)\\b"],
  ["zaporizhzhia", "Zaporizhzhia", "জাপোরিঝিয়া", 47.84, 35.14, "city", "ukraine", "\\b(zaporizhzhia|zaporozhye)\\b"],
  ["donetsk", "Donetsk", "দোনেৎস্ক", 48.0, 37.8, "city", "ukraine", "\\b(donetsk|donbas\\w*|luhansk)\\b"],
  ["kherson", "Kherson", "খেরসন", 46.64, 32.62, "city", "ukraine", "\\b(kherson)\\b"],
  ["crimea", "Crimea", "ক্রিমিয়া", 44.95, 34.1, "region", "ukraine", "\\b(crimea\\w*|sevastopol)\\b"],
  ["gazacity", "Gaza City", "গাজা সিটি", 31.5, 34.47, "city", "gaza", "\\b(gaza city|khan younis)\\b"],
  ["elfasher", "El Fasher", "এল ফাশের", 13.63, 25.35, "city", "sudan", "\\b(el fasher)\\b"],
  ["kashmir", "Kashmir", "কাশ্মীর", 34.08, 74.8, "region", "", "\\b(kashmir\\w*)\\b"],
  // regions / chokepoints
  ["hormuz", "Strait of Hormuz", "হরমুজ প্রণালী", 26.57, 56.25, "region", "", "\\b(hormuz|persian gulf|gulf of oman)\\b"],
  ["taiwanstrait", "Taiwan Strait", "তাইওয়ান প্রণালী", 24.5, 119.5, "region", "", "\\b(taiwan strait)\\b"],
  ["redsea", "Red Sea", "লোহিত সাগর", 20.0, 38.5, "region", "", "\\b(red sea|bab el-mandeb|bab al-mandab|gulf of aden)\\b"],
  ["blacksea", "Black Sea", "কৃষ্ণ সাগর", 43.5, 34.0, "region", "", "\\b(black sea)\\b"],
  ["scs", "South China Sea", "দক্ষিণ চীন সাগর", 14.0, 114.0, "region", "", "\\b(south china sea|spratly\\w*|scarborough)\\b"],
  ["baltic", "Baltic Sea", "বাল্টিক সাগর", 58.0, 20.0, "region", "", "\\b(baltic)\\b"],
  ["suez", "Suez Canal", "সুয়েজ খাল", 30.5, 32.34, "region", "", "\\b(suez)\\b"],
];

export interface GeoEntry extends GeoTag {
  parent: string;
  re: RegExp;
}

export const GAZETTEER: GeoEntry[] = ROWS.map(([key, name, nameBn, lat, lng, kind, parent, re]) => ({
  key,
  name,
  nameBn,
  lat,
  lng,
  kind,
  parent,
  re: new RegExp(re, "i"),
}));

export const GEO_BY_KEY: Record<string, GeoEntry> = Object.fromEntries(GAZETTEER.map((g) => [g.key, g]));

/** Find place mentions in the order they first appear in the text. */
export function findGeo(text: string): GeoTag[] {
  const hits: { idx: number; g: GeoEntry }[] = [];
  for (const g of GAZETTEER) {
    const m = g.re.exec(text);
    if (m) hits.push({ idx: m.index, g });
  }
  hits.sort((a, b) => a.idx - b.idx);
  return hits.map(({ g }) => ({ key: g.key, name: g.name, nameBn: g.nameBn, lat: g.lat, lng: g.lng, kind: g.kind }));
}

/* Country codes used by threat-infrastructure feeds (abuse.ch etc.) */
export const CC: Record<string, { en: string; bn: string; lat: number; lng: number }> = {
  US: { en: "United States", bn: "যুক্তরাষ্ট্র", lat: 39.0, lng: -98.0 },
  DE: { en: "Germany", bn: "জার্মানি", lat: 51.0, lng: 10.0 },
  NL: { en: "Netherlands", bn: "নেদারল্যান্ডস", lat: 52.2, lng: 5.5 },
  FR: { en: "France", bn: "ফ্রান্স", lat: 46.6, lng: 2.4 },
  GB: { en: "United Kingdom", bn: "যুক্তরাজ্য", lat: 54.0, lng: -2.5 },
  RU: { en: "Russia", bn: "রাশিয়া", lat: 56.0, lng: 38.0 },
  UA: { en: "Ukraine", bn: "ইউক্রেন", lat: 49.0, lng: 31.0 },
  CN: { en: "China", bn: "চীন", lat: 35.0, lng: 103.0 },
  HK: { en: "Hong Kong", bn: "হংকং", lat: 22.3, lng: 114.2 },
  IN: { en: "India", bn: "ভারত", lat: 22.0, lng: 79.0 },
  SG: { en: "Singapore", bn: "সিঙ্গাপুর", lat: 1.35, lng: 103.8 },
  JP: { en: "Japan", bn: "জাপান", lat: 36.0, lng: 138.0 },
  KR: { en: "South Korea", bn: "দক্ষিণ কোরিয়া", lat: 36.5, lng: 127.9 },
  CA: { en: "Canada", bn: "কানাডা", lat: 56.0, lng: -106.0 },
  BR: { en: "Brazil", bn: "ব্রাজিল", lat: -10.0, lng: -52.0 },
  TR: { en: "Türkiye", bn: "তুরস্ক", lat: 39.0, lng: 35.0 },
  PL: { en: "Poland", bn: "পোল্যান্ড", lat: 52.0, lng: 19.0 },
  SE: { en: "Sweden", bn: "সুইডেন", lat: 62.0, lng: 15.0 },
  IT: { en: "Italy", bn: "ইতালি", lat: 42.8, lng: 12.5 },
  ES: { en: "Spain", bn: "স্পেন", lat: 40.0, lng: -4.0 },
  CH: { en: "Switzerland", bn: "সুইজারল্যান্ড", lat: 46.8, lng: 8.2 },
  RO: { en: "Romania", bn: "রোমানিয়া", lat: 45.9, lng: 25.0 },
  LT: { en: "Lithuania", bn: "লিথুয়ানিয়া", lat: 55.2, lng: 23.9 },
  AU: { en: "Australia", bn: "অস্ট্রেলিয়া", lat: -25.0, lng: 134.0 },
  ZA: { en: "South Africa", bn: "দক্ষিণ আফ্রিকা", lat: -29.0, lng: 24.0 },
  IR: { en: "Iran", bn: "ইরান", lat: 32.0, lng: 53.0 },
  ID: { en: "Indonesia", bn: "ইন্দোনেশিয়া", lat: -2.0, lng: 118.0 },
  VN: { en: "Vietnam", bn: "ভিয়েতনাম", lat: 16.0, lng: 107.0 },
  BD: { en: "Bangladesh", bn: "বাংলাদেশ", lat: 23.8, lng: 90.4 },
  FI: { en: "Finland", bn: "ফিনল্যান্ড", lat: 64.0, lng: 26.0 },
  LU: { en: "Luxembourg", bn: "লুক্সেমবার্গ", lat: 49.8, lng: 6.1 },
  BG: { en: "Bulgaria", bn: "বুলগেরিয়া", lat: 42.7, lng: 25.5 },
  MD: { en: "Moldova", bn: "মোলদোভা", lat: 47.0, lng: 28.5 },
};

export interface Flashpoint {
  key: string;
  bn: string;
  en: string;
  ar: string;
  lat: number;
  lng: number;
  radiusKm: number;
}

/** Real strategic chokepoints / flashpoints used for naval monitoring, weather and simulation. */
export const FLASHPOINTS: Flashpoint[] = [
  { key: "hormuz", bn: "হরমুজ প্রণালী", en: "Strait of Hormuz", ar: "مضيق هرمز", lat: 26.57, lng: 56.25, radiusKm: 220 },
  { key: "taiwanstrait", bn: "তাইওয়ান প্রণালী", en: "Taiwan Strait", ar: "مضيق تايوان", lat: 24.5, lng: 119.5, radiusKm: 260 },
  { key: "redsea", bn: "লোহিত সাগর / বাব-এল-মান্দেব", en: "Red Sea / Bab el-Mandeb", ar: "البحر الأحمر", lat: 13.5, lng: 42.8, radiusKm: 300 },
  { key: "blacksea", bn: "কৃষ্ণ সাগর", en: "Black Sea", ar: "البحر الأسود", lat: 43.5, lng: 34.0, radiusKm: 380 },
  { key: "scs", bn: "দক্ষিণ চীন সাগর", en: "South China Sea", ar: "بحر الصين الجنوبي", lat: 14.0, lng: 114.0, radiusKm: 420 },
  { key: "baltic", bn: "বাল্টিক সাগর", en: "Baltic Sea", ar: "بحر البلطيق", lat: 57.0, lng: 19.5, radiusKm: 300 },
  { key: "suez", bn: "সুয়েজ খাল", en: "Suez Canal", ar: "قناة السويس", lat: 30.5, lng: 32.34, radiusKm: 150 },
  { key: "malacca", bn: "মালাক্কা প্রণালী", en: "Strait of Malacca", ar: "مضيق ملقا", lat: 2.5, lng: 101.5, radiusKm: 220 },
];

/** Land flashpoints for weather overlay (real coordinates of widely reported theatres). */
export const THEATRES: { key: string; bn: string; en: string; ar: string; lat: number; lng: number }[] = [
  { key: "donbas", bn: "পূর্ব ইউরোপ (দোনেৎস্ক)", en: "Eastern Europe (Donetsk)", ar: "شرق أوروبا", lat: 48.0, lng: 37.8 },
  { key: "gaza", bn: "গাজা", en: "Gaza", ar: "غزة", lat: 31.5, lng: 34.45 },
  { key: "hormuz", bn: "হরমুজ প্রণালী", en: "Strait of Hormuz", ar: "مضيق هرمز", lat: 26.57, lng: 56.25 },
  { key: "taiwanstrait", bn: "তাইওয়ান প্রণালী", en: "Taiwan Strait", ar: "مضيق تايوان", lat: 24.5, lng: 119.5 },
  { key: "redsea", bn: "লোহিত সাগর", en: "Red Sea", ar: "البحر الأحمر", lat: 15.0, lng: 42.0 },
  { key: "korea", bn: "কোরীয় উপদ্বীপ (ডিএমজেড)", en: "Korean DMZ", ar: "شبه الجزيرة الكورية", lat: 38.0, lng: 127.0 },
  { key: "kashmir", bn: "কাশ্মীর", en: "Kashmir", ar: "كشمير", lat: 34.08, lng: 74.8 },
  { key: "sudan", bn: "সুদান (খার্তুম)", en: "Sudan (Khartoum)", ar: "السودان", lat: 15.5, lng: 32.56 },
];
