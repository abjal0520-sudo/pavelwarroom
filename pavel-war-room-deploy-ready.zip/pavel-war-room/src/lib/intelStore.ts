"use client";
import { useSyncExternalStore } from "react";
import { sfx } from "./audio";
import type { Intel, Lang, NewsItem } from "./types";

export type Conn = "connecting" | "live" | "offline";
interface State {
  intel: Intel | null;
  fresh: ReadonlySet<string>;
  conn: Conn;
  lastFlush: number;
}

let state: State = { intel: null, fresh: new Set(), conn: "connecting", lastFlush: 0 };
const listeners = new Set<() => void>();
const alertListeners = new Set<(items: NewsItem[]) => void>();
let currentLang: Lang | null = null;
let pollTimer: ReturnType<typeof setInterval> | null = null;
let flushTimer: ReturnType<typeof setTimeout> | null = null;
let pending: Intel | null = null;
let requestController: AbortController | null = null;
let requestLang: Lang | null = null;
let browserListenersInstalled = false;
const seen = new Set<string>();
const THROTTLE = 4000;
const POLL_INTERVAL = 30_000;

const emit = () => listeners.forEach((l) => l());
const set = (p: Partial<State>) => {
  state = { ...state, ...p };
  emit();
};

function flush() {
  flushTimer = null;
  if (!pending) return;
  const next = pending;
  pending = null;
  const first = seen.size === 0;
  const fresh = new Set<string>();
  const alerts: NewsItem[] = [];
  for (const it of next.items) {
    if (!seen.has(it.id)) {
      seen.add(it.id);
      if (!first) {
        fresh.add(it.id);
        if (it.level === "HIGH" || it.level === "CRITICAL") alerts.push(it);
      }
    }
  }
  set({ intel: next, fresh, conn: "live", lastFlush: Date.now() });
  if (alerts.length) {
    sfx.alert();
    alertListeners.forEach((l) => l(alerts));
  }
}

function receive(intel: Intel) {
  pending = intel;
  const wait = Math.max(0, THROTTLE - (Date.now() - state.lastFlush));
  if (!state.intel || wait === 0) flush();
  else if (!flushTimer) flushTimer = setTimeout(flush, wait);
}

async function refreshIntel(lang: Lang) {
  if (requestController && requestLang === lang) return;
  requestController?.abort();
  const controller = new AbortController();
  requestController = controller;
  requestLang = lang;
  try {
    const response = await fetch(`/api/intel?lang=${lang}`, {
      cache: "no-store",
      signal: controller.signal,
    });
    if (!response.ok) throw new Error(`Intel request failed (${response.status})`);
    const intel = (await response.json()) as Intel;
    if (currentLang === lang && intel.lang === lang) receive(intel);
  } catch {
    if (!controller.signal.aborted && currentLang === lang) set({ conn: "offline" });
  } finally {
    if (requestController === controller) {
      requestController = null;
      requestLang = null;
    }
  }
}

function handleOnline() {
  if (currentLang) void refreshIntel(currentLang);
}
function handleOffline() {
  set({ conn: "offline" });
}

export function startIntel(lang: Lang) {
  if (typeof window === "undefined") return;
  if (currentLang === lang && pollTimer) return;

  currentLang = lang;
  if (pollTimer) clearInterval(pollTimer);
  pollTimer = null;
  set({ conn: state.intel ? "live" : "connecting" });
  void refreshIntel(lang);
  pollTimer = setInterval(() => void refreshIntel(lang), POLL_INTERVAL);

  if (!browserListenersInstalled) {
    window.addEventListener("online", handleOnline, { passive: true });
    window.addEventListener("offline", handleOffline, { passive: true });
    browserListenersInstalled = true;
  }
}

export const onAlert = (fn: (items: NewsItem[]) => void) => {
  alertListeners.add(fn);
  return () => {
    alertListeners.delete(fn);
  };
};

const subscribe = (cb: () => void) => {
  listeners.add(cb);
  return () => listeners.delete(cb);
};
const snap = () => state;
export const useIntelState = () => useSyncExternalStore(subscribe, snap, snap);
export const useIntel = () => useIntelState().intel;
export const getIntelState = () => state;
export const subscribeIntel = subscribe;
