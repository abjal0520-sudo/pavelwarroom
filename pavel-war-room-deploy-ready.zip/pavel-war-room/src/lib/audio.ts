"use client";
import { useSyncExternalStore } from "react";

/* Native Web Audio API (OscillatorNode) — no audio files are ever downloaded. */
let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let unlocked = false;
let muted = false;
let lastTyping = 0;
const listeners = new Set<() => void>();

if (typeof window !== "undefined") {
  try {
    muted = localStorage.getItem("pwr-muted") === "1";
  } catch {
    /* ignore */
  }
  const unlock = () => {
    unlocked = true;
    ensure();
    window.removeEventListener("pointerdown", unlock);
    window.removeEventListener("keydown", unlock);
  };
  window.addEventListener("pointerdown", unlock, { passive: true });
  window.addEventListener("keydown", unlock);
}

function ensure(): AudioContext | null {
  if (!unlocked || typeof window === "undefined") return null;
  if (!ctx) {
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AC) return null;
    ctx = new AC();
    master = ctx.createGain();
    master.gain.value = 0.9;
    master.connect(ctx.destination);
  }
  if (ctx.state === "suspended") void ctx.resume();
  return ctx;
}

interface ToneOpts {
  f: number;
  to?: number;
  d: number;
  type?: OscillatorType;
  g?: number;
  at?: number;
}
function tone({ f, to, d, type = "sine", g = 0.03, at = 0 }: ToneOpts) {
  if (muted) return;
  const c = ensure();
  if (!c || !master) return;
  const t0 = c.currentTime + at;
  const o = c.createOscillator();
  const v = c.createGain();
  o.type = type;
  o.frequency.setValueAtTime(f, t0);
  if (to) o.frequency.exponentialRampToValueAtTime(to, t0 + d);
  v.gain.setValueAtTime(0.0001, t0);
  v.gain.exponentialRampToValueAtTime(g, t0 + 0.008);
  v.gain.exponentialRampToValueAtTime(0.0001, t0 + d);
  o.connect(v).connect(master);
  o.start(t0);
  o.stop(t0 + d + 0.02);
}

export const sfx = {
  click: () => tone({ f: 1900, to: 1300, d: 0.05, type: "square", g: 0.012 }),
  ping: () => tone({ f: 1250, to: 760, d: 0.55, g: 0.035 }),
  lock: () => {
    tone({ f: 2300, d: 0.07, type: "square", g: 0.014 });
    tone({ f: 2300, d: 0.07, type: "square", g: 0.014, at: 0.12 });
    tone({ f: 3100, d: 0.18, type: "square", g: 0.012, at: 0.24 });
  },
  alert: () => {
    tone({ f: 520, d: 0.16, type: "sawtooth", g: 0.014 });
    tone({ f: 390, d: 0.2, type: "sawtooth", g: 0.014, at: 0.2 });
  },
  holo: () => {
    tone({ f: 260, to: 1400, d: 0.45, g: 0.018 });
    tone({ f: 390, to: 2100, d: 0.45, g: 0.008, type: "triangle" });
  },
  type: () => {
    const n = performance.now();
    if (n - lastTyping < 45) return;
    lastTyping = n;
    tone({ f: 900 + Math.random() * 300, d: 0.012, type: "square", g: 0.005 });
  },
  boot: () => {
    tone({ f: 90, to: 240, d: 1.2, type: "sawtooth", g: 0.02 });
    tone({ f: 600, to: 1800, d: 0.9, g: 0.015, at: 0.3 });
  },
};

export function setMuted(m: boolean) {
  muted = m;
  try {
    localStorage.setItem("pwr-muted", m ? "1" : "0");
  } catch {
    /* ignore */
  }
  listeners.forEach((l) => l());
  if (!m) sfx.holo();
}
export const isMuted = () => muted;
/** Called from a user gesture to allow sound immediately. */
export function unlockAudio() {
  unlocked = true;
  ensure();
}

const subscribe = (cb: () => void) => {
  listeners.add(cb);
  return () => listeners.delete(cb);
};
export function useMuted(): boolean {
  return useSyncExternalStore(subscribe, () => muted, () => false);
}
