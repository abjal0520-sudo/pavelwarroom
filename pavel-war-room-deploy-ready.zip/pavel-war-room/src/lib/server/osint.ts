import { desc, inArray } from "drizzle-orm";
import { getDb } from "@/db";
import { newsItems } from "@/db/schema";
import { FLASHPOINTS, THEATRES } from "../geo";
import { translateMany } from "./translate";

const UA = "Mozilla/5.0 (compatible; PavelWarRoom/1.0; +osint)";

async function getJson<T>(url: string, ms = 9000, headers: Record<string, string> = {}): Promise<T> {
  const r = await fetch(url, { headers: { "User-Agent": UA, ...headers }, signal: AbortSignal.timeout(ms), cache: "no-store" });
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  return (await r.json()) as T;
}
async function getRaw(url: string, ms = 9000): Promise<string> {
  const r = await fetch(url, { headers: { "User-Agent": UA }, signal: AbortSignal.timeout(ms), cache: "no-store" });
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  return r.text();
}

interface Cached<T> {
  at: number;
  value: T;
}
const caches = new Map<string, Cached<unknown>>();
async function cached<T>(key: string, ttl: number, fn: () => Promise<T>): Promise<T> {
  const c = caches.get(key) as Cached<T> | undefined;
  if (c && Date.now() - c.at < ttl) return c.value;
  try {
    const value = await fn();
    caches.set(key, { at: Date.now(), value });
    return value;
  } catch (e) {
    if (c) return c.value; // serve last known real data when upstream is rate-limiting
    throw e;
  }
}

/* ---------------------------- aircraft (OpenSky) ---------------------------- */
const MIL_PREFIX = /^(RCH|REACH|FORTE|HOMER|JAKE|DUKE|NCHO|LAGR|MOOSE|DOOM|TOPCT|CNV|NAVY|PAT|VENUS|RRR|ASCOT|NATO|GAF|IAM|CTM|FAF|BAF|PLF|HAF|SHF|QID|KNIGHT|BLKCAT|SPAR|EXEC|SAM|MAF|CFC|NAF|RFR|HUNT|GRZLY|TEAL|BOLT|VIPER|COBRA|LION|KING|DEMON|IRON|SLAM|ETHYL|MAZDA|PEARL|WOLF|SKULL|TITAN|HAWK)\d/;
function isMil(icao: string, call: string): boolean {
  const n = parseInt(icao, 16);
  if (n >= 0xae0000 && n <= 0xafffff) return true; // US military allocation
  if (n >= 0x43c000 && n <= 0x43cfff) return true; // UK military
  if (n >= 0x3a8000 && n <= 0x3affff) return true; // France mil block
  if (n >= 0x3f4000 && n <= 0x3f7fff) return true; // Germany mil block
  return MIL_PREFIX.test(call);
}

export interface Aircraft {
  i: string;
  c: string;
  o: string;
  x: number;
  y: number;
  a: number;
  v: number;
  h: number;
  m: 0 | 1;
  s: string;
}

export async function getAircraft() {
  return cached("aircraft", 60000, async () => {
    const auth: Record<string, string> = process.env.OPENSKY_USER && process.env.OPENSKY_PASS ? { Authorization: "Basic " + Buffer.from(`${process.env.OPENSKY_USER}:${process.env.OPENSKY_PASS}`).toString("base64") } : {};
    const j = await getJson<{ time: number; states: unknown[][] | null }>("https://opensky-network.org/api/states/all", 20000, auth);
    const states = j.states ?? [];
    const mil: Aircraft[] = [];
    const civ: Aircraft[] = [];
    let airborne = 0;
    let emergencies = 0;
    for (const s of states) {
      if (s[5] == null || s[6] == null || s[8]) continue;
      airborne++;
      const call = String(s[1] ?? "").trim();
      const squawk = String(s[14] ?? "");
      if (squawk === "7700" || squawk === "7600" || squawk === "7500") emergencies++;
      const ac: Aircraft = {
        i: String(s[0]),
        c: call,
        o: String(s[2] ?? ""),
        x: Math.round(Number(s[5]) * 1000) / 1000,
        y: Math.round(Number(s[6]) * 1000) / 1000,
        a: Math.round(Number(s[13] ?? s[7] ?? 0)),
        v: Math.round(Number(s[9] ?? 0)),
        h: Math.round(Number(s[10] ?? 0)),
        m: isMil(String(s[0]), call) ? 1 : 0,
        s: squawk,
      };
      (ac.m ? mil : civ).push(ac);
    }
    const step = Math.max(1, Math.ceil(civ.length / 650));
    const sample = civ.filter((_, idx) => idx % step === 0);
    return {
      time: j.time,
      fetchedAt: Date.now(),
      total: states.length,
      airborne,
      military: mil.length,
      emergencies,
      aircraft: [...mil.slice(0, 400), ...sample],
    };
  });
}

/* ---------------------------- satellites (CelesTrak) ---------------------------- */
export async function getSatellites() {
  return cached("sats", 3600000, async () => {
    const urls: [string, string][] = [
      ["military", "https://celestrak.org/NORAD/elements/gp.php?GROUP=military&FORMAT=tle"],
      ["NROL", "https://celestrak.org/NORAD/elements/gp.php?NAME=NROL&FORMAT=tle"],
      ["YAOGAN", "https://celestrak.org/NORAD/elements/gp.php?NAME=YAOGAN&FORMAT=tle"],
    ];
    const res = await Promise.allSettled(urls.map(([, u]) => getRaw(u, 12000)));
    const sats: { n: string; g: string; l1: string; l2: string }[] = [];
    res.forEach((r, idx) => {
      if (r.status !== "fulfilled") return;
      const lines = r.value.split(/\r?\n/).map((l) => l.trimEnd()).filter(Boolean);
      for (let k = 0; k + 2 < lines.length; k += 3) {
        if (lines[k + 1].startsWith("1 ") && lines[k + 2].startsWith("2 ")) {
          sats.push({ n: lines[k].trim(), g: urls[idx][0], l1: lines[k + 1], l2: lines[k + 2] });
        }
      }
    });
    if (!sats.length) throw new Error("no TLE data");
    const seen = new Set<string>();
    const uniq = sats.filter((s) => (seen.has(s.l1.slice(2, 7)) ? false : (seen.add(s.l1.slice(2, 7)), true)));
    return { fetchedAt: Date.now(), sats: uniq.slice(0, 90) };
  });
}

/* ---------------------------- submarine cables & pipelines ---------------------------- */
type Pos = [number, number];
interface CableFeature {
  type: "Feature";
  properties: { name: string; color: string };
  geometry: { type: "MultiLineString"; coordinates: Pos[][] };
}

// Approximate, publicly documented routes (illustrative polylines)
const PIPELINES = {
  type: "FeatureCollection" as const,
  features: [
    { name: "Nord Stream 1/2 (Vyborg → Greifswald)", c: [[28.7, 60.57], [26.5, 59.9], [22.0, 58.5], [18.5, 56.4], [15.5, 55.3], [13.65, 54.15]] },
    { name: "TurkStream (Anapa → Kıyıköy)", c: [[37.3, 44.9], [34.5, 43.6], [31.0, 42.5], [28.1, 41.6]] },
    { name: "Baltic Pipe (Denmark → Poland)", c: [[11.9, 55.4], [13.8, 55.1], [15.2, 54.6], [16.1, 54.2]] },
    { name: "Blue Stream (Dzhubga → Samsun)", c: [[38.7, 44.3], [36.5, 43.1], [35.5, 41.9], [36.2, 41.3]] },
  ].map((p) => ({ type: "Feature" as const, properties: { name: p.name }, geometry: { type: "LineString" as const, coordinates: p.c } })),
};

const hav = (a: Pos, b: Pos) => {
  const R = 6371;
  const dLat = ((b[1] - a[1]) * Math.PI) / 180;
  const dLng = ((b[0] - a[0]) * Math.PI) / 180;
  const s = Math.sin(dLat / 2) ** 2 + Math.cos((a[1] * Math.PI) / 180) * Math.cos((b[1] * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(s));
};

async function loadCables() {
  return cached("cables", 6 * 3600000, async () => {
    const j = await getJson<{ features: { properties: { name?: string; color?: string }; geometry: { type: string; coordinates: Pos[][] | Pos[][][] } }[] }>(
      "https://www.submarinecablemap.com/api/v3/cable/cable-geo.json",
      25000,
    );
    const features: CableFeature[] = [];
    for (const f of j.features) {
      const g = f.geometry;
      let lines: Pos[][] = [];
      if (g.type === "MultiLineString") lines = g.coordinates as Pos[][];
      else if (g.type === "LineString") lines = [g.coordinates as unknown as Pos[]];
      else continue;
      const rounded = lines.map((ln) => ln.filter((_, i) => i % 2 === 0 || i === ln.length - 1).map((p) => [Math.round(p[0] * 100) / 100, Math.round(p[1] * 100) / 100] as Pos));
      features.push({ type: "Feature", properties: { name: f.properties.name ?? "", color: f.properties.color ?? "#22d3ee" }, geometry: { type: "MultiLineString", coordinates: rounded } });
    }
    const alerts = FLASHPOINTS.map((fp) => {
      let n = 0;
      for (const f of features) {
        let near = false;
        for (const ln of f.geometry.coordinates) {
          for (const p of ln) {
            if (hav(p, [fp.lng, fp.lat]) < fp.radiusKm + 120) {
              near = true;
              break;
            }
          }
          if (near) break;
        }
        if (near) n++;
      }
      return { key: fp.key, cables: n };
    }).filter((a) => a.cables > 0);
    return { fetchedAt: Date.now(), cables: { type: "FeatureCollection" as const, features }, pipelines: PIPELINES, alerts };
  });
}
export async function getCables() {
  return loadCables();
}
export async function getCableAlerts() {
  const c = await loadCables();
  return { fetchedAt: c.fetchedAt, alerts: c.alerts, count: c.cables.features.length };
}

/* ---------------------------- thermal anomalies ---------------------------- */
export async function getThermal() {
  return cached("thermal", 600000, async () => {
    const key = process.env.FIRMS_MAP_KEY;
    if (key) {
      try {
        const csv = await getRaw(`https://firms.modaps.eosdis.nasa.gov/api/area/csv/${key}/VIIRS_SNPP_NRT/world/1`, 40000);
        const lines = csv.split("\n");
        const head = lines[0].split(",");
        const iLat = head.indexOf("latitude");
        const iLng = head.indexOf("longitude");
        const iFrp = head.indexOf("frp");
        const iConf = head.indexOf("confidence");
        const pts: [number, number, number][] = [];
        for (let k = 1; k < lines.length; k++) {
          const c = lines[k].split(",");
          if (c.length < head.length) continue;
          const frp = Number(c[iFrp]);
          if (c[iConf] === "l" || frp < 12) continue;
          pts.push([Number(c[iLng]), Number(c[iLat]), frp]);
        }
        const step = Math.max(1, Math.ceil(pts.length / 4000));
        return { source: "NASA FIRMS (VIIRS SNPP NRT)", live: true, fetchedAt: Date.now(), points: pts.filter((_, i) => i % step === 0) };
      } catch {
        /* fall through to EONET */
      }
    }
    const j = await getJson<{ events: { title: string; geometry: { coordinates: [number, number] | number[]; date: string }[]; categories: { id: string }[] }[] }>(
      "https://eonet.gsfc.nasa.gov/api/v3/events?status=open&category=wildfires,volcanoes,severeStorms&limit=200",
      15000,
    );
    const pts: [number, number, number][] = [];
    for (const e of j.events) {
      const g = e.geometry[e.geometry.length - 1];
      if (g && g.coordinates.length >= 2 && typeof g.coordinates[0] === "number") pts.push([g.coordinates[0] as number, g.coordinates[1] as number, 30]);
    }
    return { source: "NASA EONET (open thermal / hazard events)", live: false, fetchedAt: Date.now(), points: pts };
  });
}

/* ---------------------------- weather (Open-Meteo) ---------------------------- */
export async function getWeather() {
  return cached("weather", 600000, async () => {
    const lat = THEATRES.map((t) => t.lat).join(",");
    const lng = THEATRES.map((t) => t.lng).join(",");
    const j = await getJson<unknown>(
      `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lng}&current=temperature_2m,cloud_cover,visibility,wind_speed_10m,wind_gusts_10m,precipitation,weather_code&timezone=UTC`,
      12000,
    );
    const arr = (Array.isArray(j) ? j : [j]) as { current: Record<string, number> }[];
    return {
      fetchedAt: Date.now(),
      points: THEATRES.map((t, i) => ({
        key: t.key,
        lat: t.lat,
        lng: t.lng,
        temp: arr[i]?.current?.temperature_2m ?? null,
        cloud: arr[i]?.current?.cloud_cover ?? null,
        vis: arr[i]?.current?.visibility ?? null,
        wind: arr[i]?.current?.wind_speed_10m ?? null,
        gust: arr[i]?.current?.wind_gusts_10m ?? null,
        precip: arr[i]?.current?.precipitation ?? null,
        code: arr[i]?.current?.weather_code ?? 0,
      })),
    };
  });
}

/* ---------------------------- cyber (abuse.ch Feodo + CISA KEV) ---------------------------- */
export async function getCyber() {
  return cached("cyber", 1800000, async () => {
    const [feodo, kev] = await Promise.allSettled([
      getJson<{ ip_address: string; status: string; country: string; malware: string; as_name: string; last_online: string }[]>("https://feodotracker.abuse.ch/downloads/ipblocklist.json", 12000),
      getJson<{ count: number; vulnerabilities: { cveID: string; vendorProject: string; product: string; vulnerabilityName: string; dateAdded: string; knownRansomwareCampaignUse: string }[] }>(
        "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json",
        30000,
      ),
    ]);
    const c2 = feodo.status === "fulfilled" ? feodo.value : [];
    const byCountry = new Map<string, number>();
    const byMalware = new Map<string, number>();
    for (const e of c2) {
      byCountry.set(e.country || "??", (byCountry.get(e.country || "??") ?? 0) + 1);
      byMalware.set(e.malware, (byMalware.get(e.malware) ?? 0) + 1);
    }
    const vul = kev.status === "fulfilled" ? kev.value.vulnerabilities : [];
    const since = Date.now() - 30 * 86400e3;
    const sorted = [...vul].sort((a, b) => b.dateAdded.localeCompare(a.dateAdded));
    if (!c2.length && !vul.length) throw new Error("cyber feeds unavailable");
    return {
      fetchedAt: Date.now(),
      c2: {
        total: c2.length,
        online: c2.filter((e) => e.status === "online").length,
        byCountry: [...byCountry.entries()].sort((a, b) => b[1] - a[1]).slice(0, 12).map(([cc, n]) => ({ cc, n })),
        byMalware: [...byMalware.entries()].sort((a, b) => b[1] - a[1]).slice(0, 6).map(([name, n]) => ({ name, n })),
      },
      kev: {
        total: vul.length,
        last30: vul.filter((v) => Date.parse(v.dateAdded) >= since).length,
        ransomware: vul.filter((v) => v.knownRansomwareCampaignUse === "Known").length,
        latest: sorted.slice(0, 10).map((v) => ({ id: v.cveID, vendor: v.vendorProject, product: v.product, name: v.vulnerabilityName, added: v.dateAdded, ransomware: v.knownRansomwareCampaignUse === "Known" })),
      },
    };
  });
}

/* ---------------------------- social (Mastodon public timelines) ---------------------------- */
const TAGS = ["osint", "ukraine", "gaza", "military", "cybersecurity", "iran"];
interface MastoPost {
  id: string;
  created_at: string;
  url: string;
  language: string | null;
  content: string;
  favourites_count: number;
  reblogs_count: number;
  account: { acct: string; display_name: string };
}

export async function getSocial(lang: string) {
  const base = await cached("social", 120000, async () => {
    const res = await Promise.allSettled(TAGS.map((t) => getJson<MastoPost[]>(`https://mastodon.social/api/v1/timelines/tag/${t}?limit=20`, 8000)));
    const posts: { id: string; at: string; url: string; user: string; text: string; tag: string; fav: number; boost: number }[] = [];
    const seen = new Set<string>();
    res.forEach((r, i) => {
      if (r.status !== "fulfilled") return;
      for (const p of r.value) {
        if (p.language && p.language !== "en") continue;
        const text = p.content.replace(/<br\s*\/?>/g, " ").replace(/<[^>]*>/g, " ").replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/\s+/g, " ").trim();
        if (text.length < 40 || seen.has(p.id)) continue;
        seen.add(p.id);
        posts.push({ id: p.id, at: p.created_at, url: p.url, user: p.account.acct, text: text.slice(0, 280), tag: TAGS[i], fav: p.favourites_count, boost: p.reblogs_count });
      }
    });
    if (!posts.length) throw new Error("no social data");
    posts.sort((a, b) => Date.parse(b.at) - Date.parse(a.at));
    return { fetchedAt: Date.now(), posts: posts.slice(0, 14) };
  });
  let tr = new Map<string, string>();
  if (lang !== "en") tr = await translateMany(base.posts.map((p) => p.text), lang);
  return { fetchedAt: base.fetchedAt, posts: base.posts.map((p) => ({ ...p, textT: tr.get(p.text) ?? p.text })) };
}

/* ---------------------------- timeline (persisted live items) ---------------------------- */
export async function getTimeline() {
  const db = getDb();
  if (!db) return { items: [] };
  try {
    const rows = await db
      .select()
      .from(newsItems)
      .where(inArray(newsItems.level, ["GUARDED", "ELEVATED", "HIGH", "CRITICAL"]))
      .orderBy(desc(newsItems.publishedAt))
      .limit(14);
    return { items: rows.map((r) => ({ id: r.id, title: r.title, titleBn: r.titleBn, source: r.source, url: r.url, level: r.level, category: r.category, at: r.publishedAt.toISOString() })) };
  } catch {
    return { items: [] };
  }
}
