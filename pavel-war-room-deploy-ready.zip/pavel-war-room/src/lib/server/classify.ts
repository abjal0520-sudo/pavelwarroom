import type { CategoryKey, PropagandaRisk, ThreatLevel, Verification } from "../types";

const CAT_RE: [CategoryKey, RegExp][] = [
  ["nuclear", /\b(nuclear|atomic|uranium|enrichment|warheads?|iaea|radiation|plutonium|dirty bomb)\b/i],
  ["missile", /\b(missiles?|ballistic|hypersonic|icbm|interceptors?|iron dome|rockets?|air defen[cs]e|patriot system|s-400)\b/i],
  ["naval", /\b(navy|naval|warships?|destroyers?|submarines?|aircraft carrier|frigates?|fleet|maritime|coast guard|tankers?|red sea|strait)\b/i],
  ["cyber", /\b(cyber\w*|hackers?|hacked|hacking|ransomware|malware|data breach|ddos|spyware)\b/i],
  ["airstrike", /\b(air ?strikes?|drones?|uavs?|bombs?|bombing|bombed|shelling|shelled|warplanes?|fighter jets?|air raid|bombardment)\b/i],
  ["border", /\b(border|troops|military build-?up|incursion|frontline|front line|invasion|clashes?|army|soldiers?|militants?|offensive|insurgents?|ceasefire|war)\b/i],
];

const GENERAL = /\b(war|military|army|troops|soldiers?|attack(ed|s)?|killed|defen[cs]e|ceasefire|conflict|offensive|shell\w*|bomb\w*|weapons?|security forces|militants?|terror\w*|hostages?|invasion|rebels?|insurgen\w*|armed forces|missile|drone)\b/i;

const LETHAL = /\b(killed|dead|deaths?|casualt\w*|massacre|wounded|dozens|hundreds)\b/i;
const INTENSE = /\b(massive|largest|deadliest|major|heavy|wave|barrage|intercept\w*|ballistic|hypersonic|icbm|escalat\w*|retaliat\w*|invasion|declares? war|state of emergency|mobili[sz]\w*)\b/i;
const DIRECT = /\b(attack(s|ed)?|strikes?|hits?|launch(es|ed)?|fires?|fired|shoot\w*|bombard\w*|shell\w*)\b/i;
const NUKE_HEAVY = /\b(nuclear (test|weapon|warhead|strike|threat|alert)|icbm|radiation leak)\b/i;
const DEESC = /\b(ceasefire|talks|negotiat\w*|peace|agreement|deal|truce|diplomat\w*|summit|calls? for|condemn\w*)\b/i;
const SOFT = /\b(analysis|opinion|explained|what we know|review|podcast|interview)\b/i;

const BASE: Record<CategoryKey, number> = { nuclear: 1.7, missile: 1.8, airstrike: 1.6, naval: 1.1, cyber: 1.1, border: 0.8 };

export interface Classified {
  relevant: boolean;
  category: CategoryKey;
  level: ThreatLevel;
  score: number;
}

export function classify(title: string, summary: string): Classified {
  let category: CategoryKey | null = null;
  for (const [c, re] of CAT_RE) {
    if (re.test(title)) {
      category = c;
      break;
    }
  }
  if (!category) {
    for (const [c, re] of CAT_RE) {
      if (c !== "border" && re.test(summary)) {
        category = c;
        break;
      }
    }
  }
  const text = `${title} ${summary}`;
  if (!category && /\b(strikes?|struck|shelled|killed in)\b/i.test(title) && GENERAL.test(text)) category = "airstrike";
  const relevant = !!category && (category !== "border" || GENERAL.test(text)) && (category !== "naval" || GENERAL.test(text));
  if (!relevant && GENERAL.test(title)) category = category ?? "border";
  const isRel = relevant || GENERAL.test(title);
  const cat: CategoryKey = category ?? "border";

  let s = BASE[cat];
  if (LETHAL.test(text)) s += 1.2;
  if (INTENSE.test(text)) s += 1.0;
  if (DIRECT.test(title)) s += 0.8;
  if (NUKE_HEAVY.test(text)) s += 1.5;
  if (DEESC.test(title)) s -= 1.2;
  if (SOFT.test(title)) s -= 0.4;

  const level: ThreatLevel = s < 1.6 ? "LOW" : s < 2.6 ? "GUARDED" : s < 3.6 ? "ELEVATED" : s < 4.8 ? "HIGH" : "CRITICAL";
  return { relevant: isRel, category: cat, level, score: s };
}

/* ---------------- source reliability ---------------- */
const TIER1 = /\b(reuters|bbc|associated press|ap news|apnews|ap|afp|agence france|npr|pbs|dw|deutsche welle|guardian|financial times|ft\.com|new york times|nytimes|washington post|wall street journal|wsj|bloomberg|france 24)\b/i;
const TIER2 = /\b(al jazeera|aljazeera|cnn|cbs|nbc|abc news|sky news|the hindu|times of india|hindustan times|dawn|japan times|kyiv independent|times of israel|jerusalem post|haaretz|politico|the hill|fox news|newsweek|axios|euronews|defense news|breaking defense|military times|the diplomat|al-monitor|middle east eye|independent|telegraph|straits times|channel news asia|south china morning post|scmp|the print|daily star|prothom alo|ukrinform|ukrainska pravda|rferl|radio free europe|usni|the war zone|twz|janes|foreign policy|the economist|time|the atlantic|nikkei|yonhap|kyodo|anadolu|trt world|arab news|the national)\b/i;
const TIER4 = /\b(rt|tass|sputnik|ria novosti|ria\.ru|xinhua|xinhuanet|cgtn|global times|globaltimes|china daily|press tv|presstv|irna|kcna|al-manar|sana|tehran times|mehr|fars|tasnim|almasirah|pravda)\b/i;

export function sourceTier(source: string): 1 | 2 | 3 | 4 {
  if (TIER4.test(source)) return 4;
  if (TIER1.test(source)) return 1;
  if (TIER2.test(source)) return 2;
  return 3;
}

export function verify(source: string, corroboration: number): Verification {
  const tier = sourceTier(source);
  const base = { 1: 88, 2: 76, 3: 56, 4: 38 }[tier];
  const score = Math.min(98, base + Math.min(10, corroboration * 4));
  let risk: PropagandaRisk;
  if (tier === 4) risk = "HIGH";
  else if (tier === 1) risk = corroboration >= 1 ? "MIN" : "LOW";
  else if (tier === 2) risk = corroboration >= 1 ? "LOW" : "MED";
  else risk = corroboration >= 2 ? "MED" : "HIGH";
  return { score, risk, corroboration, tier, unverified: score < 60 };
}

const STOP = new Set("the and for with that this from have has had will would after over into amid says said say are was were its their they them his her about more than been being who what when where which while also not but out off new news latest live update updates report reports says".split(" "));
export function tokens(title: string): Set<string> {
  return new Set(
    title
      .toLowerCase()
      .replace(/[^a-z0-9 ]/g, " ")
      .split(/\s+/)
      .filter((w) => w.length > 3 && !STOP.has(w)),
  );
}
export function jaccard(a: Set<string>, b: Set<string>): number {
  if (!a.size || !b.size) return 0;
  let inter = 0;
  for (const x of a) if (b.has(x)) inter++;
  return inter / (a.size + b.size - inter);
}
