import { createHash } from "crypto";
import { inArray } from "drizzle-orm";
import { getDb } from "@/db";
import { translations } from "@/db/schema";

const mem = new Map<string, string>();
const keyOf = (lang: string, text: string) => createHash("sha1").update(`${lang}|${text}`).digest("hex");

async function gtx(text: string, lang: string): Promise<string | null> {
  try {
    const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${lang}&dt=t&q=${encodeURIComponent(text)}`;
    const r = await fetch(url, { signal: AbortSignal.timeout(7000), cache: "no-store" });
    if (!r.ok) return null;
    const j = (await r.json()) as unknown[][];
    const out = (j[0] as unknown[][]).map((p) => String(p[0] ?? "")).join("");
    return out.trim() || null;
  } catch {
    return null;
  }
}

/** Translate many strings (English -> bn / ar). Results are cached in memory + PostgreSQL. */
export async function translateMany(texts: string[], lang: string): Promise<Map<string, string>> {
  const out = new Map<string, string>();
  if (lang === "en") {
    texts.forEach((t) => out.set(t, t));
    return out;
  }
  const uniq = [...new Set(texts.filter(Boolean))];
  const pending: string[] = [];
  for (const t of uniq) {
    const k = keyOf(lang, t);
    const m = mem.get(k);
    if (m) out.set(t, m);
    else pending.push(t);
  }
  if (!pending.length) return out;

  // PostgreSQL cache is optional. In-memory cache remains available on every deployment.
  const db = getDb();
  if (db) {
    try {
      const keys = pending.map((t) => keyOf(lang, t));
      const rows = await db.select().from(translations).where(inArray(translations.key, keys));
      const byKey = new Map(rows.map((r) => [r.key, r.text]));
      for (let i = pending.length - 1; i >= 0; i--) {
        const hit = byKey.get(keyOf(lang, pending[i]));
        if (hit) {
          mem.set(keyOf(lang, pending[i]), hit);
          out.set(pending[i], hit);
          pending.splice(i, 1);
        }
      }
    } catch {
      /* Continue with the in-memory cache and translation provider. */
    }
  }

  // network translation, limited concurrency
  const fresh: { key: string; lang: string; text: string }[] = [];
  let cursor = 0;
  const worker = async () => {
    while (cursor < pending.length) {
      const t = pending[cursor++];
      const tr = await gtx(t, lang);
      if (tr) {
        const k = keyOf(lang, t);
        mem.set(k, tr);
        out.set(t, tr);
        fresh.push({ key: k, lang, text: tr });
      }
    }
  };
  await Promise.all(Array.from({ length: 5 }, worker));

  if (db && fresh.length) {
    try {
      await db.insert(translations).values(fresh).onConflictDoNothing();
    } catch {
      /* Translation results are still retained in memory for this runtime. */
    }
  }
  if (mem.size > 6000) {
    const first = mem.keys().next().value;
    if (first) mem.delete(first);
  }
  return out;
}
