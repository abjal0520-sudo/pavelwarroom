import { createHash } from "crypto";
import { sql } from "drizzle-orm";
import { XMLParser } from "fast-xml-parser";
import { getDb } from "@/db";
import { newsItems } from "@/db/schema";
import { GEO_BY_KEY, findGeo } from "../geo";
import {
  CATEGORIES,
  LEVELS,
  LEVEL_WEIGHT,
  type AnalysisMetrics,
  type CategoryKey,
  type CountryScore,
  type GeoTag,
  type Hotspot,
  type Intel,
  type Lang,
  type NewsItem,
  type SourceStatus,
  type ThreatLevel,
  type Trajectory,
} from "../types";
import { classify, jaccard, tokens, verify } from "./classify";
import { translateMany } from "./translate";

interface Raw {
  title: string;
  summary: string;
  url: string;
  source: string;
  via: string;
  publishedAt: number;
}

const UA = "Mozilla/5.0 (compatible; PavelWarRoom/1.0; +osint)";
const parser = new XMLParser({ ignoreAttributes: false, attributeNamePrefix: "@_", processEntities: true });

const txt = (x: unknown): string => {
  if (x == null) return "";
  if (typeof x === "string") return x;
  if (typeof x === "number") return String(x);
  if (typeof x === "object" && "#text" in (x as object)) return String((x as Record<string, unknown>)["#text"]);
  return "";
};
const clean = (s: string) =>
  s
    .replace(/<[^>]*>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/\s+/g, " ")
    .trim();

async function getText(url: string, ms = 8000): Promise<string> {
  const r = await fetch(url, { headers: { "User-Agent": UA, Accept: "*/*" }, signal: AbortSignal.timeout(ms), cache: "no-store" });
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  return r.text();
}

async function fetchRss(url: string, via: string, defaultSource: string, google = false): Promise<Raw[]> {
  const xml = await getText(url);
  const j = parser.parse(xml);
  let items = j?.rss?.channel?.item ?? [];
  if (!Array.isArray(items)) items = [items];
  const out: Raw[] = [];
  for (const it of items) {
    let title = clean(txt(it.title));
    if (!title) continue;
    let source = defaultSource;
    if (google) {
      source = clean(txt(it.source)) || defaultSource;
      const suffix = ` - ${source}`;
      if (title.endsWith(suffix)) title = title.slice(0, -suffix.length);
    }
    const t = Date.parse(txt(it.pubDate));
    if (!t) continue;
    out.push({
      title,
      summary: google ? "" : clean(txt(it.description)).slice(0, 420),
      url: txt(it.link),
      source,
      via,
      publishedAt: t,
    });
  }
  return out;
}

let gdeltCache: { at: number; items: Raw[]; status: SourceStatus } | null = null;
async function fetchGdelt(): Promise<{ items: Raw[]; status: SourceStatus }> {
  if (gdeltCache && Date.now() - gdeltCache.at < 300000) return gdeltCache;
  const q = encodeURIComponent("(missile OR airstrike OR drone OR cyberattack OR nuclear OR warship OR troops) sourcelang:english");
  try {
    const body = await getText(
      `https://api.gdeltproject.org/api/v2/doc/doc?query=${q}&mode=artlist&format=json&maxrecords=60&sort=datedesc&timespan=12h`,
      12000,
    );
    const j = JSON.parse(body) as { articles?: { url: string; title: string; seendate: string; domain: string }[] };
    const items: Raw[] = (j.articles ?? []).map((a) => {
      const d = a.seendate; // 20261111T123000Z
      const t = Date.parse(`${d.slice(0, 4)}-${d.slice(4, 6)}-${d.slice(6, 8)}T${d.slice(9, 11)}:${d.slice(11, 13)}:${d.slice(13, 15)}Z`);
      return { title: clean(a.title), summary: "", url: a.url, source: a.domain, via: "GDELT", publishedAt: t };
    });
    gdeltCache = { at: Date.now(), items, status: { name: "GDELT", ok: items.length > 0, count: items.length, note: items.length ? undefined : "empty" } };
  } catch (e) {
    const note = String((e as Error).message).includes("429") ? "ratelimit" : "error";
    gdeltCache = { at: Date.now() - 240000, items: gdeltCache?.items ?? [], status: { name: "GDELT", ok: false, count: gdeltCache?.items.length ?? 0, note } };
  }
  return gdeltCache;
}

async function fetchNewsApi(): Promise<{ items: Raw[]; status: SourceStatus }> {
  const key = process.env.NEWSAPI_KEY;
  if (!key) return { items: [], status: { name: "NewsAPI", ok: false, count: 0, note: "nokey" } };
  try {
    const q = encodeURIComponent("(military OR missile OR airstrike OR cyberattack OR nuclear OR warship)");
    const r = await fetch(`https://newsapi.org/v2/everything?q=${q}&language=en&sortBy=publishedAt&pageSize=40&apiKey=${key}`, {
      signal: AbortSignal.timeout(8000),
      cache: "no-store",
    });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    const j = (await r.json()) as { articles?: { title: string; description: string; url: string; source: { name: string }; publishedAt: string }[] };
    const items: Raw[] = (j.articles ?? []).map((a) => ({
      title: clean(a.title ?? ""),
      summary: clean(a.description ?? "").slice(0, 420),
      url: a.url,
      source: a.source?.name ?? "NewsAPI",
      via: "NewsAPI",
      publishedAt: Date.parse(a.publishedAt),
    }));
    return { items, status: { name: "NewsAPI", ok: true, count: items.length } };
  } catch {
    return { items: [], status: { name: "NewsAPI", ok: false, count: 0, note: "error" } };
  }
}

async function fetchAcled(): Promise<{ items: Raw[]; status: SourceStatus }> {
  const key = process.env.ACLED_KEY;
  const email = process.env.ACLED_EMAIL;
  if (!key || !email) return { items: [], status: { name: "ACLED", ok: false, count: 0, note: "nokey" } };
  try {
    const r = await fetch(`https://api.acleddata.com/acled/read?key=${key}&email=${encodeURIComponent(email)}&limit=40`, {
      signal: AbortSignal.timeout(9000),
      cache: "no-store",
    });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    const j = (await r.json()) as { data?: { event_date: string; event_type: string; notes: string; country: string; location: string }[] };
    const items: Raw[] = (j.data ?? []).map((e) => ({
      title: `${e.event_type}: ${e.location}, ${e.country}`,
      summary: clean(e.notes ?? "").slice(0, 420),
      url: "https://acleddata.com/",
      source: "ACLED",
      via: "ACLED",
      publishedAt: Date.parse(e.event_date),
    }));
    return { items, status: { name: "ACLED", ok: true, count: items.length } };
  } catch {
    return { items: [], status: { name: "ACLED", ok: false, count: 0, note: "error" } };
  }
}

const gnews = (q: string) => `https://news.google.com/rss/search?q=${encodeURIComponent(q)}&hl=en-US&gl=US&ceid=US:en`;

async function collectRaw(): Promise<{ raws: Raw[]; sources: SourceStatus[] }> {
  const group = async (name: string, jobs: Promise<Raw[]>[]): Promise<{ items: Raw[]; status: SourceStatus }> => {
    const res = await Promise.allSettled(jobs);
    const items = res.flatMap((r) => (r.status === "fulfilled" ? r.value : []));
    return { items, status: { name, ok: items.length > 0, count: items.length, note: items.length ? undefined : "error" } };
  };

  const [bbc, aj, reuters, ap, gdelt, napi, acled] = await Promise.all([
    group("BBC", [
      fetchRss("https://feeds.bbci.co.uk/news/world/rss.xml", "BBC RSS", "BBC"),
      fetchRss("https://feeds.bbci.co.uk/news/world/middle_east/rss.xml", "BBC RSS", "BBC"),
      fetchRss("https://feeds.bbci.co.uk/news/world/europe/rss.xml", "BBC RSS", "BBC"),
      fetchRss("https://feeds.bbci.co.uk/news/world/asia/rss.xml", "BBC RSS", "BBC"),
    ]),
    group("Al Jazeera", [fetchRss("https://www.aljazeera.com/xml/rss/all.xml", "Al Jazeera RSS", "Al Jazeera")]),
    group("Reuters", [
      fetchRss(gnews("site:reuters.com (military OR missile OR war OR strike OR cyber OR nuclear OR navy) when:2d"), "Reuters (News index)", "Reuters", true),
    ]),
    group("AP", [fetchRss(gnews("site:apnews.com (war OR military OR missile OR strike OR drone) when:2d"), "AP (News index)", "AP", true)]),
    fetchGdelt(),
    fetchNewsApi(),
    fetchAcled(),
  ]);

  const all = [bbc, aj, reuters, ap, gdelt, napi, acled];
  return { raws: all.flatMap((g) => g.items), sources: all.map((g) => g.status) };
}

/* ------------------------------------------------------------------ */

const prevScores = new Map<string, number>();
const decay = (hoursAgo: number) => Math.pow(0.5, Math.max(0, hoursAgo) / 12);
const sat = (s: number, k: number) => 100 * (1 - Math.exp(-s / k));
const lvlFromScore = (s: number): ThreatLevel => (s < 20 ? "LOW" : s < 40 ? "GUARDED" : s < 60 ? "ELEVATED" : s < 80 ? "HIGH" : "CRITICAL");

type BaseIntel = Omit<Intel, "lang">;

function buildBase(raws: Raw[], sources: SourceStatus[]): BaseIntel {
  const now = Date.now();
  const seen = new Set<string>();
  const cand: { raw: Raw; id: string; geo: GeoTag[]; cls: ReturnType<typeof classify>; tok: Set<string> }[] = [];

  for (const raw of raws) {
    if (!raw.title || !raw.url || !Number.isFinite(raw.publishedAt)) continue;
    const age = now - raw.publishedAt;
    if (age > 72 * 3600e3 || age < -3600e3) continue;
    const norm = raw.title.toLowerCase().replace(/[^a-z0-9]/g, "");
    const dk = `${raw.source}|${norm}`;
    if (seen.has(dk)) continue;
    seen.add(dk);
    const cls = classify(raw.title, raw.summary);
    if (!cls.relevant) continue;
    const id = createHash("sha1").update(`${raw.source}|${norm}`).digest("hex").slice(0, 24);
    cand.push({ raw, id, geo: findGeo(`${raw.title} ${raw.summary}`), cls, tok: tokens(raw.title) });
  }

  const items: NewsItem[] = cand.map((c) => {
    let corr = 0;
    const srcs = new Set<string>();
    for (const o of cand) {
      if (o === c || o.raw.source === c.raw.source || srcs.has(o.raw.source)) continue;
      if (jaccard(c.tok, o.tok) >= 0.4) {
        srcs.add(o.raw.source);
        corr++;
      }
    }
    return {
      id: c.id,
      title: c.raw.title,
      titleT: c.raw.title,
      summary: c.raw.summary,
      summaryT: c.raw.summary,
      url: c.raw.url,
      source: c.raw.source,
      via: c.raw.via,
      publishedAt: new Date(c.raw.publishedAt).toISOString(),
      category: c.cls.category,
      level: c.cls.level,
      verification: verify(c.raw.source, corr),
      geo: c.geo,
      translated: false,
    };
  });
  items.sort((a, b) => Date.parse(b.publishedAt) - Date.parse(a.publishedAt));
  const top = items.slice(0, 70);

  /* stats */
  const byCategory = Object.fromEntries(CATEGORIES.map((c) => [c, 0])) as Record<CategoryKey, number>;
  const byLevel = Object.fromEntries(LEVELS.map((l) => [l, 0])) as Record<ThreatLevel, number>;
  const series = Object.fromEntries([...CATEGORIES, "all"].map((k) => [k, new Array<number>(24).fill(0)])) as Intel["series"];
  const S = (cats?: CategoryKey[]) => {
    let s = 0;
    for (const it of top) {
      if (cats && !cats.includes(it.category)) continue;
      s += LEVEL_WEIGHT[it.level] * decay((now - Date.parse(it.publishedAt)) / 3600e3);
    }
    return s;
  };
  for (const it of top) {
    const h = Math.floor((now - Date.parse(it.publishedAt)) / 3600e3);
    byLevel[it.level]++;
    if (h < 24 && h >= 0) {
      byCategory[it.category]++;
      series.all[23 - h]++;
      series[it.category][23 - h]++;
    }
  }

  /* geo aggregation */
  const hs = new Map<string, { g: GeoTag; s: number; n: number }>();
  const cs = new Map<string, number>();
  const cn = new Map<string, number>();
  const hiPerZone = new Map<string, number>();
  for (const it of top) {
    const w = LEVEL_WEIGHT[it.level] * decay((now - Date.parse(it.publishedAt)) / 3600e3);
    const seenC = new Set<string>();
    for (const g of it.geo.slice(0, 3)) {
      const h = hs.get(g.key) ?? { g, s: 0, n: 0 };
      h.s += w;
      h.n++;
      hs.set(g.key, h);
      const ck = g.kind === "country" ? g.key : GEO_BY_KEY[g.key]?.parent || (g.kind === "region" ? g.key : "");
      if (ck && !seenC.has(ck)) {
        seenC.add(ck);
        if (g.key !== "nato" && GEO_BY_KEY[ck]?.kind === "country") {
          cs.set(ck, (cs.get(ck) ?? 0) + w);
          cn.set(ck, (cn.get(ck) ?? 0) + 1);
        }
        if (LEVEL_WEIGHT[it.level] >= 3) hiPerZone.set(ck, (hiPerZone.get(ck) ?? 0) + 1);
      }
    }
  }

  const countries: CountryScore[] = [...cs.entries()]
    .map(([key, s]) => {
      const g = GEO_BY_KEY[key];
      const score = Math.round(sat(s, 14));
      const prev = prevScores.get(key);
      return { key, en: g.name, bn: g.nameBn, lat: g.lat, lng: g.lng, score, count: cn.get(key) ?? 0, delta: prev == null ? 0 : score - prev };
    })
    .sort((a, b) => b.score - a.score)
    .slice(0, 14);
  for (const c of countries) prevScores.set(c.key, c.score);

  const hotspots: Hotspot[] = [...hs.values()]
    .map(({ g, s, n }) => {
      const score = Math.round(sat(s, 14));
      return { key: g.key, name: g.name, nameBn: g.nameBn, lat: g.lat, lng: g.lng, count: n, score, level: lvlFromScore(score) };
    })
    .sort((a, b) => b.score - a.score)
    .slice(0, 24);

  let activeConflicts = [...hiPerZone.values()].filter((n) => n >= 2).length;
  if (!activeConflicts) activeConflicts = countries.filter((c) => c.score >= 45).length;

  /* trajectories derived from reporting (news geo-tags) */
  const missiles: Trajectory[] = [];
  const cyberRoutes: Trajectory[] = [];
  for (const it of top) {
    if (!it.geo.length) continue;
    const isMissile = it.category === "missile" || /\b(missiles?|rockets?|ballistic|icbm)\b/i.test(it.title);
    const toTag = (g: GeoTag) => g;
    if (isMissile && missiles.length < 6 && LEVEL_WEIGHT[it.level] >= 2) {
      const [a, b] = it.geo;
      missiles.push({ id: `m-${it.id}`, newsId: it.id, title: it.title, level: it.level, from: b ? toTag(a) : null, to: toTag(b ?? a) });
    }
    if (it.category === "cyber" && it.geo.length >= 2 && cyberRoutes.length < 5) {
      cyberRoutes.push({ id: `c-${it.id}`, newsId: it.id, title: it.title, level: it.level, from: it.geo[0], to: it.geo[1] });
    }
  }

  /* analytics */
  const geoSet = ["border", "airstrike", "missile"] as CategoryKey[];
  const sB = S(geoSet);
  const inCats = top.filter((i) => geoSet.includes(i.category));
  const recent6 = inCats.filter((i) => now - Date.parse(i.publishedAt) < 6 * 3600e3).length;
  const day = inCats.filter((i) => now - Date.parse(i.publishedAt) < 24 * 3600e3).length;
  const trend = day > 0 ? recent6 / 6 / (day / 24) : 1;
  const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
  const analysis: AnalysisMetrics = {
    borderEscalation: Math.round(clamp(sat(sB, 120) * clamp(trend, 0.7, 1.3), 5, 96)),
    conflictProbability: countries[0]?.score ?? 0,
    nuclearRisk: Math.round(sat(S(["nuclear"]), 9)),
    cyberThreat: Math.round(sat(S(["cyber"]), 6)),
    instability: Math.round(countries.slice(0, 8).reduce((a, c) => a + c.score, 0) / Math.max(1, Math.min(8, countries.length))),
    movementActivity: Math.round(sat(S(["naval", "airstrike", "border"]), 70)),
    topHotspot: countries[0]?.en ?? null,
    topHotspotBn: countries[0]?.bn ?? null,
    basisCount: top.length,
    recentCount: recent6,
  };
  const nuclearIndex = analysis.nuclearRisk;
  const nuclearLevel: ThreatLevel = nuclearIndex < 15 ? "LOW" : nuclearIndex < 35 ? "GUARDED" : nuclearIndex < 55 ? "ELEVATED" : nuclearIndex < 75 ? "HIGH" : "CRITICAL";

  return {
    generatedAt: new Date(now).toISOString(),
    items: top,
    sources,
    stats: { total: top.length, byCategory, byLevel, activeConflicts, gti: Math.round(sat(S(), 60)), nuclearLevel, nuclearIndex },
    series,
    countries,
    hotspots,
    missiles,
    cyberRoutes,
    analysis,
  };
}

/* ------------------------------------------------------------------ */

let base: { at: number; value: BaseIntel } | null = null;
let baseInflight: Promise<BaseIntel> | null = null;
const langCache = new Map<string, { key: string; value: Intel }>();
const langInflight = new Map<string, Promise<Intel>>();

async function getBase(): Promise<BaseIntel> {
  if (base && Date.now() - base.at < 100000) return base.value;
  if (!baseInflight) {
    baseInflight = (async () => {
      try {
        const { raws, sources } = await collectRaw();
        const value = buildBase(raws, sources);
        if (value.items.length || !base) base = { at: Date.now(), value };
        else base = { at: Date.now() - 60000, value: base.value };
        return base.value;
      } finally {
        baseInflight = null;
      }
    })();
  }
  return baseInflight;
}

async function persist(items: NewsItem[], bn: Map<string, string> | null) {
  try {
    const rows = items.slice(0, 60).map((i) => ({
      id: i.id,
      source: i.source,
      title: i.title,
      titleBn: bn?.get(i.title) ?? null,
      url: i.url,
      category: i.category,
      level: i.level,
      publishedAt: new Date(i.publishedAt),
      geo: i.geo.map((g) => g.key),
    }));
    const db = getDb();
    if (!db || !rows.length) return;
    await db
      .insert(newsItems)
      .values(rows)
      .onConflictDoUpdate({ target: newsItems.id, set: { titleBn: sql`coalesce(excluded.title_bn, ${newsItems.titleBn})`, level: sql`excluded.level` } });
  } catch {
    /* ignore */
  }
}

export async function getIntel(lang: Lang): Promise<Intel> {
  const b = await getBase();
  const key = `${lang}:${b.generatedAt}`;
  const hit = langCache.get(lang);
  if (hit && hit.key === key) return hit.value;
  const running = langInflight.get(key);
  if (running) return running;

  const p = (async () => {
    let titles = new Map<string, string>();
    let sums = new Map<string, string>();
    if (lang !== "en") {
      titles = await translateMany(b.items.map((i) => i.title), lang);
      sums = await translateMany(
        b.items
          .slice(0, 24)
          .map((i) => i.summary)
          .filter((s) => s.length > 20),
        lang,
      );
    }
    const items = b.items.map((i) => ({
      ...i,
      titleT: titles.get(i.title) ?? i.title,
      summaryT: sums.get(i.summary) ?? i.summary,
      translated: lang === "en" ? true : titles.has(i.title),
    }));
    const value: Intel = { ...b, lang, items };
    langCache.set(lang, { key, value });
    if (lang === "bn") void persist(b.items, titles);
    else void persist(b.items, null);
    return value;
  })();
  langInflight.set(key, p);
  try {
    return await p;
  } finally {
    langInflight.delete(key);
  }
}
