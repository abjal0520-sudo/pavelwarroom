export type HistType = "missile" | "invasion" | "cyber" | "naval" | "peace";

export interface HistEvent {
  date: string; // ISO date
  type: HistType;
  bn: string;
  en: string;
  ar: string;
}

/** Documented, widely-reported historical events (public record). */
export const HISTORY: HistEvent[] = [
  { date: "2025-06-24", type: "peace", bn: "ইসরায়েল–ইরান যুদ্ধবিরতি কার্যকর (জুনের ১২ দিনের সংঘাতের পর)", en: "Israel–Iran ceasefire takes effect after the June 12-day conflict", ar: "بدء وقف إطلاق النار بين إسرائيل وإيران" },
  { date: "2025-05-10", type: "peace", bn: "ভারত–পাকিস্তান সামরিক সংঘাত বন্ধে যুদ্ধবিরতি ঘোষণা", en: "India–Pakistan ceasefire announced after cross-border strikes", ar: "إعلان وقف إطلاق النار بين الهند وباكستان" },
  { date: "2025-01-19", type: "peace", bn: "গাজায় যুদ্ধবিরতি চুক্তি কার্যকর হয়", en: "Gaza ceasefire agreement takes effect", ar: "دخول اتفاق وقف إطلاق النار في غزة حيز التنفيذ" },
  { date: "2024-10-01", type: "missile", bn: "ইরান ইসরায়েলের দিকে ব্যালিস্টিক ক্ষেপণাস্ত্র নিক্ষেপ করে", en: "Iran fires ballistic missiles at Israel", ar: "إيران تطلق صواريخ باليستية على إسرائيل" },
  { date: "2024-04-13", type: "missile", bn: "ইরান ইসরায়েলের দিকে ড্রোন ও ক্ষেপণাস্ত্র হামলা চালায়", en: "Iran launches drones and missiles at Israel", ar: "إيران تطلق طائرات مسيرة وصواريخ نحو إسرائيل" },
  { date: "2023-10-07", type: "invasion", bn: "হামাসের ইসরায়েলে আকস্মিক হামলা; গাজা যুদ্ধের সূচনা", en: "Hamas attack on Israel; start of the Gaza war", ar: "هجوم حماس على إسرائيل وبداية حرب غزة" },
  { date: "2022-09-26", type: "naval", bn: "বাল্টিক সাগরে নর্ড স্ট্রিম পাইপলাইনে বিস্ফোরণ", en: "Explosions rupture Nord Stream pipelines in the Baltic Sea", ar: "انفجارات تستهدف أنابيب نورد ستريم في بحر البلطيق" },
  { date: "2022-07-22", type: "peace", bn: "কৃষ্ণ সাগর শস্য উদ্যোগ চুক্তি স্বাক্ষর (জাতিসংঘ ও তুরস্কের মধ্যস্থতায়)", en: "Black Sea Grain Initiative signed (UN & Türkiye brokered)", ar: "توقيع مبادرة حبوب البحر الأسود" },
  { date: "2022-04-14", type: "naval", bn: "কৃষ্ণ সাগরে রুশ ক্রুজার ‘মস্কভা’ ডুবে যায়", en: "Russian cruiser Moskva sinks in the Black Sea", ar: "غرق الطراد الروسي موسكفا في البحر الأسود" },
  { date: "2022-02-24", type: "invasion", bn: "রাশিয়া ইউক্রেনে পূর্ণমাত্রার আক্রমণ শুরু করে", en: "Russia launches full-scale invasion of Ukraine", ar: "روسيا تبدأ غزوًا شاملاً لأوكرانيا" },
  { date: "2021-05-07", type: "cyber", bn: "কলোনিয়াল পাইপলাইনে র‍্যানসমওয়্যার হামলা, মার্কিন জ্বালানি সরবরাহ ব্যাহত", en: "Colonial Pipeline ransomware attack disrupts US fuel supply", ar: "هجوم فدية على خط أنابيب كولونيال" },
  { date: "2020-12-13", type: "cyber", bn: "সোলারউইন্ডস সাপ্লাই-চেইন সাইবার অনুপ্রবেশ প্রকাশ্যে আসে", en: "SolarWinds supply-chain intrusion disclosed", ar: "الكشف عن اختراق سلسلة التوريد في سولار ويندز" },
  { date: "2020-11-10", type: "peace", bn: "নাগোর্নো-কারাবাখ যুদ্ধবিরতি চুক্তি স্বাক্ষর", en: "Nagorno-Karabakh ceasefire agreement signed", ar: "توقيع اتفاق وقف إطلاق النار في ناغورني قره باغ" },
  { date: "2020-09-15", type: "peace", bn: "আব্রাহাম চুক্তি স্বাক্ষর (ইসরায়েল–ইউএই–বাহরাইন)", en: "Abraham Accords signed (Israel–UAE–Bahrain)", ar: "توقيع اتفاقيات إبراهيم" },
  { date: "2020-02-29", type: "peace", bn: "যুক্তরাষ্ট্র–তালেবান দোহা চুক্তি স্বাক্ষর", en: "US–Taliban Doha agreement signed", ar: "توقيع اتفاق الدوحة بين الولايات المتحدة وطالبان" },
  { date: "2017-05-12", type: "cyber", bn: "ওয়ানাক্রাই র‍্যানসমওয়্যার বিশ্বজুড়ে ছড়িয়ে পড়ে", en: "WannaCry ransomware spreads worldwide", ar: "انتشار برمجية الفدية واناكراي عالميًا" },
  { date: "2015-07-14", type: "peace", bn: "ইরান পারমাণবিক চুক্তি (জেসিপিওএ) স্বাক্ষর", en: "Iran nuclear deal (JCPOA) concluded", ar: "التوصل إلى الاتفاق النووي الإيراني" },
  { date: "2007-04-27", type: "cyber", bn: "এস্তোনিয়ায় বড় আকারের সাইবার হামলা শুরু", en: "Large-scale cyber attacks begin against Estonia", ar: "بدء هجمات سيبرانية واسعة ضد إستونيا" },
];

export const HIST_META: Record<HistType, { bn: string; en: string; ar: string; color: string }> = {
  missile: { bn: "ক্ষেপণাস্ত্র", en: "Missile", ar: "صاروخ", color: "#ef4444" },
  invasion: { bn: "আক্রমণ", en: "Invasion", ar: "غزو", color: "#fb923c" },
  cyber: { bn: "সাইবার", en: "Cyber", ar: "سيبراني", color: "#a78bfa" },
  naval: { bn: "নৌ ঘটনা", en: "Naval", ar: "بحري", color: "#22d3ee" },
  peace: { bn: "শান্তি চুক্তি", en: "Peace", ar: "سلام", color: "#4ade80" },
};
