"use client";
import { useSyncExternalStore } from "react";
import { setMuted, sfx } from "./audio";
import { GAZETTEER } from "./geo";
import { getIntelState } from "./intelStore";
import { setLayer, type LayerId } from "./layers";
import { flyTo } from "./mapController";
import type { Lang } from "./types";

/* ---------------- optical shader mode store (root CSS filter) ---------------- */
export type Vision = "std" | "nvg" | "flir" | "crt";
let vision: Vision = "std";
const vl = new Set<() => void>();
export function setVision(v: Vision) {
  vision = v;
  if (typeof document !== "undefined") document.documentElement.dataset.vision = v;
  try {
    localStorage.setItem("pwr-vision", v);
  } catch {
    /* ignore */
  }
  vl.forEach((l) => l());
}
export function initVision() {
  try {
    const s = localStorage.getItem("pwr-vision") as Vision | null;
    if (s && ["std", "nvg", "flir", "crt"].includes(s)) setVision(s);
  } catch {
    /* ignore */
  }
}
export const useVision = () =>
  useSyncExternalStore(
    (cb) => {
      vl.add(cb);
      return () => vl.delete(cb);
    },
    () => vision,
    () => "std" as Vision,
  );

export function scrollToId(id: string) {
  (document.getElementById(id) ?? document.querySelector(`[data-lazy="${id}"]`))?.scrollIntoView({ behavior: "smooth", block: "start" });
}

export interface CmdCtx {
  setLang: (l: Lang) => void;
  lang: Lang;
}
export interface CmdResult {
  ok: boolean;
  message: string;
}

const has = (t: string, ...ks: string[]) => ks.some((k) => t.includes(k));

/** Interprets Bangla / English commands (voice or typed) and drives the interface. */
export function runCommand(raw: string, ctx: CmdCtx): CmdResult {
  const t = raw.toLowerCase().trim();
  const bn = ctx.lang === "bn";
  const m = (b: string, e: string) => (bn ? b : e);
  if (!t) return { ok: false, message: m("কোনো কমান্ড পাওয়া যায়নি", "No command received") };
  sfx.lock();

  // vision modes
  if (has(t, "নাইট ভিশন", "নাইট", "night", "nvg")) {
    setVision("nvg");
    return { ok: true, message: m("নাইট ভিশন (NVG) মোড সক্রিয়", "Night-vision (NVG) mode active") };
  }
  if (has(t, "flir", "ফ্লির") || (has(t, "থার্মাল", "thermal") && !has(t, "বিস্ফোরণ", "firms", "explosion"))) {
    setVision("flir");
    return { ok: true, message: m("থার্মাল (FLIR) ক্যামেরা মোড সক্রিয়", "FLIR thermal mode active") };
  }
  if (has(t, "crt", "ট্যাকটিক্যাল রাডার", "রাডার মোড", "radar mode")) {
    setVision("crt");
    return { ok: true, message: m("ট্যাকটিক্যাল রাডার (CRT) মোড সক্রিয়", "Tactical radar (CRT) mode active") };
  }
  if (has(t, "সাধারণ", "standard", "normal")) {
    setVision("std");
    return { ok: true, message: m("সাধারণ স্যাটেলাইট ভিউ ফিরিয়ে আনা হয়েছে", "Standard satellite view restored") };
  }

  // audio / language
  if (has(t, "অডিও বন্ধ", "মিউট", "mute", "sound off")) {
    setMuted(true);
    return { ok: true, message: m("অডিও বন্ধ করা হয়েছে", "Audio muted") };
  }
  if (has(t, "অডিও চালু", "আনমিউট", "unmute", "sound on")) {
    setMuted(false);
    return { ok: true, message: m("অডিও চালু করা হয়েছে", "Audio enabled") };
  }
  if (has(t, "ইংরেজি", "english")) {
    ctx.setLang("en");
    return { ok: true, message: "Language switched to English" };
  }
  if (has(t, "আরবি", "arabic")) {
    ctx.setLang("ar");
    return { ok: true, message: "تم تغيير اللغة إلى العربية" };
  }
  if (has(t, "বাংলা", "bangla", "bengali")) {
    ctx.setLang("bn");
    return { ok: true, message: "ভাষা বাংলায় পরিবর্তন করা হয়েছে" };
  }

  // layers / sections
  const layer = (id: LayerId, msg: string, section = "map"): CmdResult => {
    setLayer(id, true);
    scrollToId(section);
    return { ok: true, message: msg };
  };
  if (has(t, "স্যাটেলাইট", "satellite")) {
    setLayer("spysat", true);
    return layer("satmode", m("স্যাটেলাইট নজরদারি মোড চালু — কক্ষপথ ও লক্ষ্য ট্র্যাকিং সক্রিয়", "Satellite surveillance mode online — orbit and target tracking active"));
  }
  if (has(t, "সাইবার", "cyber")) {
    setLayer("cyber", true);
    scrollToId("cyber");
    return { ok: true, message: m("সাইবার ওয়ারফেয়ার সেন্টার খোলা হয়েছে", "Cyber warfare center opened") };
  }
  if (has(t, "বিস্ফোরণ", "firms", "explosion")) return layer("thermal", m("NASA থার্মাল অসঙ্গতি লেয়ার চালু", "NASA thermal anomaly layer on"));
  if (has(t, "জ্যামিং", "jamming", "spoof")) return layer("gpsjam", m("জিপিএস জ্যামিং / ইডব্লিউ লেয়ার চালু", "GPS jamming / EW layer on"));
  if (has(t, "ক্যাবল", "cable", "পাইপলাইন", "pipeline")) return layer("cables", m("সাবমেরিন ক্যাবল ও পাইপলাইন লেয়ার চালু", "Submarine cable & pipeline layer on"));
  if (has(t, "ক্ষেপণাস্ত্র", "missile")) return layer("missiles", m("ক্ষেপণাস্ত্র ট্র্যাজেক্টরি লেয়ার চালু", "Missile trajectory layer on"));
  if (has(t, "বিমান", "aircraft", "flight")) return layer("aircraft", m("বিমান ট্র্যাকিং লেয়ার চালু", "Aircraft tracking layer on"));
  if (has(t, "আবহাওয়া", "weather")) {
    setLayer("weather", true);
    scrollToId("weather");
    return { ok: true, message: m("আবহাওয়া ওভারলে সক্রিয়", "Weather overlay active") };
  }
  const sections: [string[], string, string, string][] = [
    [["পারমাণবিক", "nuclear", "ডিফকন", "defcon"], "threat", "পারমাণবিক ঝুঁকি মিটার দেখানো হচ্ছে", "Showing nuclear risk meter"],
    [["সিমুলেটর", "simulat", "ওয়ার-গেম", "war game", "wargame"], "wargame", "এআই যুদ্ধ পরিস্থিতি সিমুলেটর খোলা হয়েছে", "War-game simulator opened"],
    [["ড্যাশবোর্ড", "dashboard"], "dashboard", "বৈশ্বিক থ্রেট ড্যাশবোর্ড", "Global threat dashboard"],
    [["বিশ্লেষণ", "analysis"], "analysis", "এআই হুমকি বিশ্লেষণ", "AI threat analysis"],
    [["নৌ", "naval", "navy"], "naval", "নৌ নজরদারি প্যানেল", "Naval surveillance panel"],
    [["টাইমলাইন", "timeline"], "timeline", "ইভেন্ট টাইমলাইন", "Event timeline"],
    [["সোশ্যাল", "social", "টেলিগ্রাম", "টুইটার"], "social", "সামাজিক মাধ্যম পর্যবেক্ষণ", "Social media monitoring"],
    [["খবর", "সংবাদ", "news"], "news", "ব্রেকিং ইন্টেলিজেন্স ফিড", "Breaking intelligence feed"],
    [["ম্যাপ", "মানচিত্র", "map"], "map", "ট্যাকটিক্যাল ম্যাপ", "Tactical map"],
    [["কমান্ড", "command"], "terminal", "কমান্ড টার্মিনাল", "Command terminal"],
  ];

  // country lookup (after sections so "রাশিয়ার তথ্য দেখাও" still resolves)
  for (const g of GAZETTEER) {
    if (g.kind === "city") continue;
    if (t.includes(g.nameBn.split(" ")[0].toLowerCase()) || t.includes(g.name.toLowerCase()) || t.includes(g.key)) {
      flyTo(g.lat, g.lng, g.kind === "region" ? 4.4 : 3.8);
      scrollToId("map");
      const score = getIntelState().intel?.countries.find((c) => c.key === g.key)?.score;
      const nm = bn ? g.nameBn : g.name;
      return {
        ok: true,
        message: score != null ? m(`${nm} — লাইভ হুমকি স্কোর ${score}/100`, `${nm} — live threat score ${score}/100`) : m(`${nm} অঞ্চলে ফোকাস করা হয়েছে`, `Focused on ${nm}`),
      };
    }
  }
  for (const [keys, id, b, e] of sections) {
    if (has(t, ...keys)) {
      scrollToId(id);
      return { ok: true, message: m(b, e) };
    }
  }
  if (has(t, "সাহায্য", "help")) {
    return {
      ok: true,
      message: m(
        "উদাহরণ: “রাশিয়ার তথ্য দেখাও”, “সাইবার হুমকি চালু করো”, “স্যাটেলাইট মোড চালু করো”, “নাইট ভিশন”, “থার্মাল ক্যামেরা”, “অডিও বন্ধ”",
        'Examples: "show Russia", "cyber threats on", "satellite mode on", "night vision", "thermal camera", "mute"',
      ),
    };
  }
  return { ok: false, message: m("কমান্ড বোঝা যায়নি — “সাহায্য” বলুন", 'Command not recognised — say "help"') };
}
