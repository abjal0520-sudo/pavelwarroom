"use client";
import { useEffect, useSyncExternalStore } from "react";

export type Kind = "aircraft" | "satellites" | "cables" | "cablealerts" | "thermal" | "weather" | "cyber" | "social" | "timeline";

interface Entry {
  data: unknown;
  at: number;
  error: string | null;
  loading: boolean;
  refs: number;
  timer: ReturnType<typeof setInterval> | null;
  version: number;
}
const entries = new Map<Kind, Entry>();
const listeners = new Map<Kind, Set<() => void>>();
const EMPTY = { data: null, at: 0, error: null, loading: false, version: 0 } as const;
export interface OsintView<T> {
  data: T | null;
  at: number;
  error: string | null;
  loading: boolean;
  version: number;
}
const views = new Map<Kind, OsintView<unknown>>();

function publish(kind: Kind) {
  const e = entries.get(kind);
  views.set(kind, e ? { data: e.data, at: e.at, error: e.error, loading: e.loading, version: e.version } : EMPTY);
  listeners.get(kind)?.forEach((l) => l());
}

async function load(kind: Kind, lang: string) {
  const e = entries.get(kind);
  if (!e) return;
  e.loading = true;
  publish(kind);
  try {
    const r = await fetch(`/api/osint/${kind}?lang=${lang}`);
    const j = await r.json();
    if (!entries.get(kind)) return;
    if (!r.ok) throw new Error(j?.error ?? "error");
    e.data = j;
    e.at = Date.now();
    e.error = null;
    e.version++;
  } catch (err) {
    e.error = String((err as Error).message || "error");
  } finally {
    e.loading = false;
    publish(kind);
  }
}

/** Reference-counted polling: a feed only runs (and holds memory) while something uses it. */
export function acquire(kind: Kind, intervalMs: number, lang = "bn"): () => void {
  let e = entries.get(kind);
  if (!e) {
    e = { data: null, at: 0, error: null, loading: false, refs: 0, timer: null, version: 0 };
    entries.set(kind, e);
    void load(kind, lang);
    e.timer = setInterval(() => void load(kind, lang), intervalMs);
  }
  e.refs++;
  return () => {
    const cur = entries.get(kind);
    if (!cur) return;
    cur.refs--;
    if (cur.refs <= 0) {
      if (cur.timer) clearInterval(cur.timer);
      entries.delete(kind);
      publish(kind);
    }
  };
}

export function peek<T>(kind: Kind): T | null {
  return (entries.get(kind)?.data as T) ?? null;
}

export function subscribeKind(kind: Kind, cb: () => void) {
  let s = listeners.get(kind);
  if (!s) listeners.set(kind, (s = new Set()));
  s.add(cb);
  return () => {
    s!.delete(cb);
  };
}

export function useOsint<T>(kind: Kind, intervalMs: number, opts: { lang?: string; enabled?: boolean } = {}): OsintView<T> {
  const { lang = "bn", enabled = true } = opts;
  useEffect(() => {
    if (!enabled) return;
    return acquire(kind, intervalMs, lang);
  }, [kind, intervalMs, lang, enabled]);
  const view = useSyncExternalStore(
    (cb) => subscribeKind(kind, cb),
    () => (views.get(kind) as OsintView<T> | undefined) ?? (EMPTY as OsintView<T>),
    () => EMPTY as OsintView<T>,
  );
  return view;
}
