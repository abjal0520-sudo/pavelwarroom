"use client";
import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import type { Lang } from "./types";

type L = (bn: string, en: string, ar?: string) => string;
interface Ctx {
  lang: Lang;
  setLang: (l: Lang) => void;
  L: L;
  dir: "ltr" | "rtl";
}
const LangCtx = createContext<Ctx>({ lang: "bn", setLang: () => {}, L: (bn) => bn, dir: "ltr" });

export function LangProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>("bn");

  useEffect(() => {
    try {
      const s = localStorage.getItem("pwr-lang") as Lang | null;
      if (s === "en" || s === "ar" || s === "bn") setLangState(s);
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
  }, [lang]);

  const setLang = useCallback((l: Lang) => {
    document.body.style.transition = "opacity .18s";
    document.body.style.opacity = "0.25";
    setTimeout(() => {
      setLangState(l);
      try {
        localStorage.setItem("pwr-lang", l);
      } catch {
        /* ignore */
      }
      document.body.style.opacity = "1";
    }, 180);
  }, []);

  const value = useMemo<Ctx>(
    () => ({
      lang,
      setLang,
      dir: lang === "ar" ? "rtl" : "ltr",
      L: (bn, en, ar) => (lang === "bn" ? bn : lang === "ar" ? (ar ?? en) : en),
    }),
    [lang, setLang],
  );
  return <LangCtx.Provider value={value}>{children}</LangCtx.Provider>;
}

export const useLang = () => useContext(LangCtx);

export function tri<T extends { bn: string; en: string; ar: string }>(lang: Lang, t: T): string {
  return t[lang];
}
