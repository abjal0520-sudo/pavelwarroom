"use client";
import "maplibre-gl/dist/maplibre-gl.css";
import type { GeoJSONSource, LayerSpecification, Map as MLMap, StyleSpecification } from "maplibre-gl";
import * as satellite from "satellite.js";
import { FLASHPOINTS, CC } from "./geo";
import { getIntelState, subscribeIntel } from "./intelStore";
import { getLayers, subscribeLayers, type LayerId } from "./layers";
import { acquire, peek, subscribeKind, type Kind } from "./osintStore";
import { LEVEL_COLOR, type Lang, type ThreatLevel } from "./types";

/**
 * SINGLE WebGL CONTEXT: one MapLibre globe instance is shared by the hero and the tactical map.
 * The host element is physically moved between "slots" by an IntersectionObserver, and all moving
 * objects (aircraft, missiles, satellites, pings) are drawn on ONE 2D canvas via requestAnimationFrame.
 */

type Mode = "hero" | "tactical" | "none";
interface Slot {
  el: HTMLElement;
  mode: Mode;
  ratio: number;
}
interface Ac {
  i: string;
  c: string;
  o: string;
  x: number;
  y: number;
  a: number;
  v: number;
  h: number;
  m: 0 | 1;
}
interface AircraftData {
  fetchedAt: number;
  aircraft: Ac[];
}
interface SatsData {
  sats: { n: string; g: string; l1: string; l2: string }[];
}
interface SatObj {
  name: string;
  rec: satellite.SatRec;
  lat: number;
  lng: number;
  alt: number;
  track: [number, number][];
}

const DEG = Math.PI / 180;
const slots = new Map<HTMLElement, Slot>();
let host: HTMLDivElement | null = null;
let canvas: HTMLCanvasElement | null = null;
let cx: CanvasRenderingContext2D | null = null;
let map: MLMap | null = null;
let loaded = false;
let initStarted = false;
let mode: Mode = "none";
let booted = false;
let raf = 0;
let lastFrame = 0;
let W = 0;
let H = 0;
let dpr = 1;
let io: IntersectionObserver | null = null;
let labelLang: Lang = "bn";
let sats: SatObj[] = [];
let satVer = -1;
let satCalc = 0;
let trackCalc = 0;
let lastRot = 0;
let MLNS: typeof import("maplibre-gl") | null = null;
let navCtl: unknown = null;

type MapStatus = "loading" | "ready" | "error";
let status: MapStatus = "loading";
const statusL = new Set<(s: MapStatus) => void>();
export const getMapStatus = () => status;
export const subscribeMapStatus = (cb: (s: MapStatus) => void) => {
  statusL.add(cb);
  cb(status);
  return () => {
    statusL.delete(cb);
  };
};
const setStatus = (s: MapStatus) => {
  status = s;
  statusL.forEach((l) => l(s));
};

export interface ViewInfo {
  lat: number;
  lng: number;
  zoom: number;
  pitch: number;
  bearing: number;
  cursor: { lat: number; lng: number } | null;
}
const viewL = new Set<(v: ViewInfo) => void>();
let cursor: { lat: number; lng: number } | null = null;
let viewQueued = false;
function emitView() {
  if (viewQueued || !map) return;
  viewQueued = true;
  setTimeout(() => {
    viewQueued = false;
    if (!map) return;
    const c = map.getCenter();
    const v: ViewInfo = { lat: c.lat, lng: c.lng, zoom: map.getZoom(), pitch: map.getPitch(), bearing: map.getBearing(), cursor };
    viewL.forEach((l) => l(v));
  }, 120);
}
export const subscribeView = (cb: (v: ViewInfo) => void) => {
  viewL.add(cb);
  return () => {
    viewL.delete(cb);
  };
};

export const setLabelLang = (l: Lang) => {
  labelLang = l;
};
export function setBooted(b: boolean) {
  booted = b;
  pick();
}

/* ------------------------------------------------------------------ */
export function registerSlot(el: HTMLElement, m: Exclude<Mode, "none">): () => void {
  slots.set(el, { el, mode: m, ratio: 0 });
  if (!initStarted) void init();
  if (io) io.observe(el);
  return () => {
    io?.unobserve(el);
    slots.delete(el);
    pick();
  };
}

export function flyTo(lat: number, lng: number, zoom = 4) {
  if (!map) return;
  map.flyTo({ center: [lng, lat], zoom, duration: 2200, essential: true });
}

async function init() {
  initStarted = true;
  try {
    host = document.createElement("div");
    host.style.cssText = "position:absolute;inset:0;overflow:hidden;background:#02050b";
    const mapEl = document.createElement("div");
    mapEl.style.cssText = "position:absolute;inset:0";
    host.appendChild(mapEl);
    canvas = document.createElement("canvas");
    canvas.style.cssText = "position:absolute;inset:0;width:100%;height:100%;pointer-events:none;z-index:2";
    host.appendChild(canvas);
    cx = canvas.getContext("2d");
    dpr = Math.min(window.devicePixelRatio || 1, 1.5);

    io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          const s = slots.get(e.target as HTMLElement);
          if (s) s.ratio = e.isIntersecting ? e.intersectionRatio : 0;
        }
        pick();
      },
      { threshold: [0, 0.05, 0.15, 0.3, 0.5, 0.75, 1] },
    );
    slots.forEach((s) => io!.observe(s.el));

    const ml = await import("maplibre-gl");
    MLNS = ml;
    const style = {
      version: 8,
      projection: { type: "globe" },
      sky: {
        "sky-color": "#0a2540",
        "horizon-color": "#38bdf8",
        "fog-color": "#0b1a30",
        "sky-horizon-blend": 0.55,
        "horizon-fog-blend": 0.6,
        "fog-ground-blend": 0.35,
        "atmosphere-blend": ["interpolate", ["linear"], ["zoom"], 0, 1, 5, 1, 7, 0],
      },
      sources: {
        sat: {
          type: "raster",
          tiles: ["https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"],
          tileSize: 256,
          maxzoom: 17,
          attribution: "Imagery © Esri, Maxar, Earthstar Geographics",
        },
      },
      layers: [
        { id: "bg", type: "background", paint: { "background-color": "#02050b" } },
        { id: "sat", type: "raster", source: "sat", paint: { "raster-brightness-max": 0.8, "raster-saturation": -0.3, "raster-contrast": 0.18 } },
      ],
    } as unknown as StyleSpecification;

    map = new ml.Map({
      container: mapEl,
      style,
      center: [38, 28],
      zoom: 1.6,
      pixelRatio: Math.min(window.devicePixelRatio || 1, 1.5),
      fadeDuration: 0,
      maxPitch: 60,
      attributionControl: false,
      renderWorldCopies: false,
      cooperativeGestures: false,
      locale: {
        "CooperativeGesturesHandler.WindowsHelpText": "ম্যাপ জুম করতে Ctrl + স্ক্রল করুন",
        "CooperativeGesturesHandler.MacHelpText": "ম্যাপ জুম করতে ⌘ + স্ক্রল করুন",
        "CooperativeGesturesHandler.MobileHelpText": "ম্যাপ সরাতে দুই আঙুল ব্যবহার করুন",
      },
    });
    map.addControl(new ml.AttributionControl({ compact: true }), "bottom-right");
    navCtl = new ml.NavigationControl({ showCompass: true, visualizePitch: true });

    map.on("load", () => {
      loaded = true;
      void addBorders();
      setStatus("ready");
      resizeAll();
      if (mode !== "none") applyMode();
      syncAll();
    });
    map.on("error", () => {
      /* tile errors are non-fatal */
    });
    map.on("move", emitView);
    map.on("mousemove", (e) => {
      cursor = { lat: e.lngLat.lat, lng: e.lngLat.lng };
      emitView();
    });

    const ro = new ResizeObserver(() => resizeAll());
    ro.observe(host);

    subscribeLayers(() => {
      syncLeases();
      syncAll();
    });
    subscribeIntel(() => syncAll());
    (["aircraft", "satellites", "cables", "thermal", "cyber", "weather"] as Kind[]).forEach((k) => subscribeKind(k, () => syncAll()));
    pick();
  } catch {
    setStatus("error");
  }
}

async function addBorders() {
  if (!map) return;
  const [topo, world] = await Promise.all([import("topojson-client"), import("world-atlas/countries-110m.json")]);
  if (!map) return;
  const t = (world.default ?? world) as unknown as Parameters<typeof topo.mesh>[0];
  const objs = (t as unknown as { objects: { countries: Parameters<typeof topo.mesh>[1] } }).objects;
  const borders = topo.mesh(t, objs.countries, (a, b) => a !== b);
  const coast = topo.mesh(t, objs.countries, (a, b) => a === b);
  map.addSource("borders", { type: "geojson", data: { type: "Feature", properties: {}, geometry: borders } });
  map.addSource("coast", { type: "geojson", data: { type: "Feature", properties: {}, geometry: coast } });
  map.addLayer({ id: "coast-l", type: "line", source: "coast", paint: { "line-color": "#67e8f9", "line-opacity": 0.35, "line-width": 0.6 } });
  map.addLayer({ id: "borders-l", type: "line", source: "borders", paint: { "line-color": "#22d3ee", "line-opacity": 0.55, "line-width": ["interpolate", ["linear"], ["zoom"], 1, 0.5, 6, 1.4] } });
}

function resizeAll() {
  if (!host || !canvas || !map) return;
  const r = host.getBoundingClientRect();
  W = r.width;
  H = r.height;
  if (W < 2 || H < 2) return;
  canvas.width = Math.round(W * dpr);
  canvas.height = Math.round(H * dpr);
  map.resize();
}

/* ---------------------- slot arbitration ---------------------- */
function pick() {
  let best: Slot | null = null;
  slots.forEach((s) => {
    if (s.ratio > 0.05 && (!best || s.ratio > best.ratio + 0.001)) best = s;
  });
  const b = best as Slot | null;
  if (!b || !booted || !host) {
    if (mode !== "none") {
      mode = "none";
      stopLoop();
    }
    return;
  }
  if (host.parentElement !== b.el) {
    b.el.prepend(host);
    resizeAll();
  }
  if (mode !== b.mode) {
    mode = b.mode;
    applyMode();
  }
  syncLeases();
  startLoop();
}

function fitZoom(): number {
  const d = Math.min(W || window.innerWidth, (H || window.innerHeight) * 1.05);
  return Math.max(1, Math.log2((d * Math.PI) / 512));
}

function applyMode() {
  if (!map) return;
  const hs = ["dragPan", "dragRotate", "scrollZoom", "touchZoomRotate", "doubleClickZoom", "keyboard", "boxZoom", "touchPitch"] as const;
  if (mode === "hero") {
    hs.forEach((h) => map![h].disable());
    if (navCtl) {
      try {
        map.removeControl(navCtl as never);
      } catch {
        /* not added */
      }
    }
    map.easeTo({ zoom: fitZoom() + 0.15, pitch: 0, bearing: 0, duration: 1600 });
  } else if (mode === "tactical") {
    hs.forEach((h) => map![h].enable());
    const touch = window.matchMedia("(pointer: coarse)").matches;
    if (touch || !touch) map.cooperativeGestures.enable();
    if (navCtl && MLNS) {
      try {
        map.addControl(navCtl as never, "top-right");
      } catch {
        /* already added */
      }
    }
    map.easeTo({ zoom: Math.max(fitZoom() - 0.1, 1.4), duration: 1400 });
  }
  emitView();
}

/* ---------------------- data leases ---------------------- */
const leases = new Map<LayerId | "aircraft", { release: (() => void) | null; timer: ReturnType<typeof setTimeout> | null }>();
const KIND_FOR: Partial<Record<LayerId, [Kind, number]>> = {
  aircraft: ["aircraft", 45000],
  spysat: ["satellites", 3600000],
  cables: ["cables", 6 * 3600000],
  thermal: ["thermal", 600000],
  cyber: ["cyber", 1800000],
  weather: ["weather", 600000],
};
function syncLeases() {
  const L = getLayers();
  (Object.keys(KIND_FOR) as LayerId[]).forEach((id) => {
    const want = L[id] && mode === "tactical";
    const [kind, iv] = KIND_FOR[id]!;
    let l = leases.get(id);
    if (!l) leases.set(id, (l = { release: null, timer: null }));
    if (want) {
      if (l.timer) {
        clearTimeout(l.timer);
        l.timer = null;
      }
      if (!l.release) l.release = acquire(kind, iv);
    } else if (l.release && !l.timer) {
      const rel = l;
      l.timer = setTimeout(() => {
        rel.release?.();
        rel.release = null;
        rel.timer = null;
        syncAll();
      }, 30000);
    }
  });
}

/* ---------------------- native (GPU) layers ---------------------- */
function setNative(sourceId: string, on: boolean, data: GeoJSON.FeatureCollection | null, layers: LayerSpecification[]) {
  if (!map || !loaded) return;
  const has = !!map.getSource(sourceId);
  if (on && data) {
    if (!has) {
      map.addSource(sourceId, { type: "geojson", data });
      layers.forEach((l) => map!.addLayer(l));
    } else (map.getSource(sourceId) as GeoJSONSource).setData(data);
  } else if (!on && has) {
    layers.forEach((l) => map!.getLayer(l.id) && map!.removeLayer(l.id));
    map.removeSource(sourceId);
  }
}

const heatLayer: LayerSpecification[] = [
  {
    id: "heat-c",
    type: "circle",
    source: "heat",
    paint: {
      "circle-radius": ["interpolate", ["linear"], ["zoom"], 0, ["*", ["get", "score"], 0.35], 4, ["*", ["get", "score"], 1.6], 8, ["*", ["get", "score"], 4]],
      "circle-blur": 0.95,
      "circle-opacity": 0.5,
      "circle-color": ["get", "color"],
    },
  },
];
const thermalLayer: LayerSpecification[] = [
  { id: "thermal-g", type: "circle", source: "thermal", paint: { "circle-radius": ["interpolate", ["linear"], ["zoom"], 1, 5, 6, 14], "circle-blur": 1, "circle-opacity": 0.28, "circle-color": "#f97316" } },
  {
    id: "thermal-c",
    type: "circle",
    source: "thermal",
    paint: {
      "circle-radius": ["interpolate", ["linear"], ["zoom"], 1, 1.6, 6, 4.5],
      "circle-blur": 0.4,
      "circle-opacity": 0.95,
      "circle-color": ["interpolate", ["linear"], ["get", "frp"], 10, "#f59e0b", 50, "#ef4444", 200, "#ffffff"],
    },
  },
];
const gpsLayer: LayerSpecification[] = [
  { id: "gps-f", type: "fill", source: "gpsjam", paint: { "fill-color": "#ef4444", "fill-opacity": ["get", "o"] } },
  { id: "gps-l", type: "line", source: "gpsjam", paint: { "line-color": "#f87171", "line-opacity": 0.75, "line-width": 0.9 } },
];
const cableLayer: LayerSpecification[] = [
  { id: "cable-l", type: "line", source: "cables", paint: { "line-color": ["get", "color"], "line-opacity": 0.75, "line-width": ["interpolate", ["linear"], ["zoom"], 1, 0.6, 6, 1.6] } },
];
const pipeLayer: LayerSpecification[] = [
  { id: "pipe-l", type: "line", source: "pipes", paint: { "line-color": "#fb923c", "line-width": 2, "line-dasharray": [2, 1.5], "line-opacity": 0.95 } },
];

const GPS_ZONES: [number, number][] = [
  [55.0, 20.5],
  [59.8, 25.5],
  [43.5, 36.5],
  [34.5, 34.0],
  [26.5, 54.5],
  [31.5, 74.5],
];
function hexGrid(): GeoJSON.FeatureCollection {
  const R = 1.15;
  const features: GeoJSON.Feature[] = [];
  for (const [clat, clng] of GPS_ZONES) {
    for (let q = -2; q <= 2; q++) {
      for (let r = Math.max(-2, -q - 2); r <= Math.min(2, -q + 2); r++) {
        const ring = Math.max(Math.abs(q), Math.abs(r), Math.abs(-q - r));
        const lat = clat + R * 1.5 * r;
        const lng = clng + (R * Math.sqrt(3) * (q + r / 2)) / Math.cos(clat * DEG);
        const ring6: [number, number][] = [];
        for (let k = 0; k <= 6; k++) {
          const a = (60 * k - 30) * DEG;
          ring6.push([lng + (R * Math.cos(a)) / Math.cos(lat * DEG), lat + R * Math.sin(a)]);
        }
        features.push({ type: "Feature", properties: { o: 0.5 - ring * 0.13 }, geometry: { type: "Polygon", coordinates: [ring6] } });
      }
    }
  }
  return { type: "FeatureCollection", features };
}

function syncAll() {
  if (!map || !loaded) return;
  const L = getLayers();
  const intel = getIntelState().intel;

  setNative(
    "heat",
    L.heat,
    intel
      ? { type: "FeatureCollection", features: intel.hotspots.map((h) => ({ type: "Feature", properties: { score: h.score, color: LEVEL_COLOR[h.level] }, geometry: { type: "Point", coordinates: [h.lng, h.lat] } })) }
      : { type: "FeatureCollection", features: [] },
    heatLayer,
  );

  const th = peek<{ points: [number, number, number][] }>("thermal");
  setNative(
    "thermal",
    L.thermal && !!th,
    th ? { type: "FeatureCollection", features: th.points.map((p) => ({ type: "Feature", properties: { frp: p[2] }, geometry: { type: "Point", coordinates: [p[0], p[1]] } })) } : null,
    thermalLayer,
  );
  setNative("gpsjam", L.gpsjam, L.gpsjam ? hexGrid() : null, gpsLayer);

  const cb = peek<{ cables: GeoJSON.FeatureCollection; pipelines: GeoJSON.FeatureCollection }>("cables");
  setNative("cables", L.cables && !!cb, cb ? cb.cables : null, cableLayer);
  setNative("pipes", L.cables && !!cb, cb ? cb.pipelines : null, pipeLayer);

  // satellites: parse TLEs when new data arrives, free when layer is off
  const sd = peek<SatsData>("satellites");
  if (L.spysat && sd) {
    const ver = sd.sats.length;
    if (satVer !== ver) {
      satVer = ver;
      sats = [];
      for (const s of sd.sats) {
        try {
          sats.push({ name: s.n, rec: satellite.twoline2satrec(s.l1, s.l2), lat: 0, lng: 0, alt: 0, track: [] });
        } catch {
          /* bad TLE */
        }
      }
      satCalc = 0;
      trackCalc = 0;
    }
  } else if (!L.spysat && sats.length) {
    sats = [];
    satVer = -1;
  }
  map.triggerRepaint();
}

/* ---------------------- render loop ---------------------- */
function startLoop() {
  if (raf || !booted) return;
  const loop = (t: number) => {
    raf = requestAnimationFrame(loop);
    if (document.hidden || mode === "none") return;
    const minGap = mode === "hero" ? 1000 / 24 : 1000 / 30;
    if (t - lastFrame < minGap) return;
    const dt = Math.min(100, t - lastFrame);
    lastFrame = t;
    if (mode === "hero" && map && loaded) {
      const c = map.getCenter();
      map.setCenter([c.lng + (dt / 1000) * 3.2, c.lat + (22 - c.lat) * 0.002]);
      lastRot = t;
    }
    draw(Date.now());
  };
  raf = requestAnimationFrame(loop);
}
function stopLoop() {
  if (raf) cancelAnimationFrame(raf);
  raf = 0;
  if (cx && canvas) cx.clearRect(0, 0, canvas.width, canvas.height);
}

function gcPoints(a: { lat: number; lng: number }, b: { lat: number; lng: number }, n: number): [number, number][] {
  const la1 = a.lat * DEG,
    lo1 = a.lng * DEG,
    la2 = b.lat * DEG,
    lo2 = b.lng * DEG;
  const d = 2 * Math.asin(Math.sqrt(Math.sin((la2 - la1) / 2) ** 2 + Math.cos(la1) * Math.cos(la2) * Math.sin((lo2 - lo1) / 2) ** 2));
  const out: [number, number][] = [];
  if (d < 1e-6) return [[a.lat, a.lng]];
  for (let i = 0; i <= n; i++) {
    const f = i / n;
    const A = Math.sin((1 - f) * d) / Math.sin(d);
    const B = Math.sin(f * d) / Math.sin(d);
    const x = A * Math.cos(la1) * Math.cos(lo1) + B * Math.cos(la2) * Math.cos(lo2);
    const y = A * Math.cos(la1) * Math.sin(lo1) + B * Math.cos(la2) * Math.sin(lo2);
    const z = A * Math.sin(la1) + B * Math.sin(la2);
    out.push([Math.atan2(z, Math.hypot(x, y)) / DEG, Math.atan2(y, x) / DEG]);
  }
  return out;
}
const distKm = (a: { lat: number; lng: number }, b: { lat: number; lng: number }) => {
  const la1 = a.lat * DEG,
    la2 = b.lat * DEG;
  return 12742 * Math.asin(Math.sqrt(Math.sin((la2 - la1) / 2) ** 2 + Math.cos(la1) * Math.cos(la2) * Math.sin(((b.lng - a.lng) * DEG) / 2) ** 2));
};

const arcCache = new Map<string, { pts: [number, number][]; km: number }>();

interface Pt {
  x: number;
  y: number;
}
let cLat = 0;
let cLng = 0;
function proj(lat: number, lng: number): Pt | null {
  if (!map) return null;
  const la = lat * DEG;
  const cosd = Math.sin(la) * Math.sin(cLat) + Math.cos(la) * Math.cos(cLat) * Math.cos(lng * DEG - cLng);
  if (cosd < 0.03) return null;
  const p = map.project([lng, lat]);
  if (p.x < -60 || p.x > W + 60 || p.y < -60 || p.y > H + 60) return null;
  return p;
}
function kmPx(lat: number, lng: number, km: number): number {
  if (!map) return 0;
  const a = map.project([lng, lat]);
  const b = map.project([lng + km / (111.32 * Math.max(0.2, Math.cos(lat * DEG))), lat]);
  return Math.hypot(a.x - b.x, a.y - b.y);
}

function updateSats(now: number) {
  if (!sats.length) return;
  if (now - satCalc > 1000) {
    satCalc = now;
    const d = new Date(now);
    const gm = satellite.gstime(d);
    for (const s of sats) {
      const pv = satellite.propagate(s.rec, d);
      if (!pv || typeof pv.position === "boolean" || !pv.position) continue;
      const g = satellite.eciToGeodetic(pv.position, gm);
      s.lat = satellite.degreesLat(g.latitude);
      s.lng = satellite.degreesLong(g.longitude);
      s.alt = g.height;
    }
  }
  if (now - trackCalc > 120000) {
    trackCalc = now;
    for (const s of sats.slice(0, 12)) {
      const tr: [number, number][] = [];
      for (let k = 0; k <= 64; k++) {
        const d = new Date(now + k * 90000);
        const pv = satellite.propagate(s.rec, d);
        if (!pv || typeof pv.position === "boolean" || !pv.position) continue;
        const g = satellite.eciToGeodetic(pv.position, satellite.gstime(d));
        tr.push([satellite.degreesLat(g.latitude), satellite.degreesLong(g.longitude)]);
      }
      s.track = tr;
    }
  }
}

function ring(x: number, y: number, r: number, color: string, alpha: number, w = 1) {
  if (!cx) return;
  cx.globalAlpha = alpha;
  cx.strokeStyle = color;
  cx.lineWidth = w;
  cx.beginPath();
  cx.arc(x, y, r, 0, Math.PI * 2);
  cx.stroke();
}

function pings(x: number, y: number, color: string, now: number, seed: number, r = 26) {
  for (let k = 0; k < 2; k++) {
    const f = ((now / 2600 + seed * 0.37 + k * 0.5) % 1 + 1) % 1;
    ring(x, y, 3 + f * r, color, (1 - f) * 0.7, 1.2);
  }
}

function draw(now: number) {
  if (!cx || !map || !loaded || !canvas || W < 2) return;
  const c = cx;
  c.setTransform(dpr, 0, 0, dpr, 0, 0);
  c.clearRect(0, 0, W, H);
  const cen = map.getCenter();
  cLat = cen.lat * DEG;
  cLng = cen.lng * DEG;
  const L = getLayers();
  const intel = getIntelState().intel;
  const zoom = map.getZoom();
  const tms = now;
  c.font = "10px 'JetBrains Mono', monospace";
  c.textBaseline = "middle";

  /* hotspots: radar pings */
  if (intel && (L.heat || mode === "hero")) {
    intel.hotspots.slice(0, mode === "hero" ? 7 : 10).forEach((h, i) => {
      const p = proj(h.lat, h.lng);
      if (!p) return;
      const col = LEVEL_COLOR[h.level];
      pings(p.x, p.y, col, tms, i, 14 + h.score * 0.3);
      c.globalAlpha = 1;
      c.fillStyle = col;
      c.beginPath();
      c.arc(p.x, p.y, 2.2, 0, 7);
      c.fill();
      if (mode === "tactical" && i < 6 && zoom > 1.3) {
        c.globalAlpha = 0.9;
        c.fillStyle = "#cfe8f0";
        const nm = labelLang === "bn" ? h.nameBn : h.name;
        c.font = "11px 'Hind Siliguri', 'JetBrains Mono', sans-serif";
        c.fillText(`${nm}`, p.x + 8, p.y - 7);
        c.font = "10px 'JetBrains Mono', monospace";
        c.fillStyle = col;
        c.fillText(`${h.score}`, p.x + 8, p.y + 6);
      }
    });
  }
  if (mode !== "tactical") {
    c.globalAlpha = 1;
    return;
  }

  /* naval chokepoint radar scans */
  if (L.naval) {
    FLASHPOINTS.forEach((f, i) => {
      const p = proj(f.lat, f.lng);
      if (!p) return;
      const r = Math.max(16, Math.min(90, kmPx(f.lat, f.lng, f.radiusKm)));
      ring(p.x, p.y, r, "#22d3ee", 0.45, 1);
      ring(p.x, p.y, r * 0.5, "#22d3ee", 0.2, 1);
      const a = ((tms / 3200 + i * 0.13) % 1) * Math.PI * 2;
      c.globalAlpha = 0.16;
      c.fillStyle = "#22d3ee";
      c.beginPath();
      c.moveTo(p.x, p.y);
      c.arc(p.x, p.y, r, a - 0.7, a);
      c.closePath();
      c.fill();
      c.globalAlpha = 0.85;
      c.strokeStyle = "#67e8f9";
      c.beginPath();
      c.moveTo(p.x, p.y);
      c.lineTo(p.x + Math.cos(a) * r, p.y + Math.sin(a) * r);
      c.stroke();
      if (zoom > 1.5) {
        c.globalAlpha = 0.85;
        c.fillStyle = "#9fe9f7";
        c.font = "11px 'Hind Siliguri', sans-serif";
        c.fillText(labelLang === "bn" ? f.bn : f.en, p.x + r * 0.7 + 4, p.y - r * 0.7);
      }
    });
  }

  /* weather rings */
  if (L.weather) {
    const w = peek<{ points: { lat: number; lng: number; cloud: number | null; vis: number | null; wind: number | null }[] }>("weather");
    w?.points.forEach((pt) => {
      const p = proj(pt.lat, pt.lng);
      if (!p) return;
      const r = Math.max(18, kmPx(pt.lat, pt.lng, 160));
      const g = c.createRadialGradient(p.x, p.y, 0, p.x, p.y, r);
      g.addColorStop(0, `rgba(200,220,255,${((pt.cloud ?? 0) / 100) * 0.4})`);
      g.addColorStop(1, "rgba(200,220,255,0)");
      c.globalAlpha = 1;
      c.fillStyle = g;
      c.beginPath();
      c.arc(p.x, p.y, r, 0, 7);
      c.fill();
      c.setLineDash([3, 4]);
      ring(p.x, p.y, r, "#bcd7ff", 0.5, 1);
      c.setLineDash([]);
      c.globalAlpha = 0.95;
      c.fillStyle = "#dbe9ff";
      c.fillText(`☁${Math.round(pt.cloud ?? 0)}% · ${pt.vis != null ? (pt.vis / 1000).toFixed(1) : "-"}km · ${pt.wind != null ? Math.round(pt.wind) : "-"}km/h`, p.x + 6, p.y + r * 0.7);
    });
  }

  /* spy satellites */
  if (L.spysat && sats.length) {
    updateSats(tms);
    c.setLineDash([4, 5]);
    for (const s of sats.slice(0, 12)) {
      if (s.track.length < 2) continue;
      c.globalAlpha = 0.5;
      c.strokeStyle = "#5fbf6a";
      c.lineWidth = 1;
      c.beginPath();
      let pen = false;
      let prevLng = 0;
      for (const [la, lo] of s.track) {
        const p = proj(la, lo);
        if (!p || (pen && Math.abs(lo - prevLng) > 180)) {
          pen = false;
          prevLng = lo;
          continue;
        }
        if (!pen) c.moveTo(p.x, p.y);
        else c.lineTo(p.x, p.y);
        pen = true;
        prevLng = lo;
      }
      c.stroke();
    }
    c.setLineDash([]);
    let labels = 0;
    for (const s of sats) {
      if (!s.alt) continue;
      const p = proj(s.lat, s.lng);
      if (!p) continue;
      const foot = Math.max(8, kmPx(s.lat, s.lng, 6371 * Math.acos(6371 / (6371 + s.alt)) * 0.5));
      ring(p.x, p.y, Math.min(foot, 160), "#5fbf6a", 0.28, 1);
      c.globalAlpha = 1;
      c.fillStyle = "#86efac";
      c.save();
      c.translate(p.x, p.y);
      c.rotate(Math.PI / 4);
      c.fillRect(-3, -3, 6, 6);
      c.restore();
      if (labels < 9) {
        labels++;
        c.globalAlpha = 0.85;
        c.fillStyle = "#b7f7c6";
        c.fillText(`${s.name.slice(0, 16)} ${Math.round(s.alt)}km`, p.x + 8, p.y - 6);
      }
    }
  }

  /* cyber nodes + news-derived routes */
  if (L.cyber) {
    const cy = peek<{ c2: { byCountry: { cc: string; n: number }[] } }>("cyber");
    cy?.c2.byCountry.forEach((e, i) => {
      const g = CC[e.cc];
      if (!g) return;
      const p = proj(g.lat, g.lng);
      if (!p) return;
      pings(p.x, p.y, "#e879f9", tms, i, 10 + Math.log2(e.n + 1) * 5);
      c.globalAlpha = 1;
      c.fillStyle = "#f0abfc";
      c.beginPath();
      c.arc(p.x, p.y, 2 + Math.log2(e.n + 1), 0, 7);
      c.fill();
      c.globalAlpha = 0.85;
      c.fillText(`${e.cc} ${e.n}`, p.x + 8, p.y);
    });
    intel?.cyberRoutes.forEach((r, i) => {
      if (!r.from) return;
      drawArc(r.id, r.from, r.to, "#a78bfa", tms + i * 900, 3000, false);
    });
  }

  /* missile trajectories from news geo-tags */
  if (L.missiles && intel) {
    intel.missiles.forEach((m, i) => {
      const col = LEVEL_COLOR[m.level as ThreatLevel];
      const tgt = proj(m.to.lat, m.to.lng);
      if (m.from) drawArc(m.id, m.from, m.to, col, tms + i * 1700, 8000, true);
      if (tgt) {
        const spin = (tms / 1800 + i) * Math.PI * 2;
        c.globalAlpha = 0.9;
        c.strokeStyle = col;
        c.lineWidth = 1.2;
        c.setLineDash([3, 4]);
        c.beginPath();
        c.arc(tgt.x, tgt.y, Math.max(14, kmPx(m.to.lat, m.to.lng, 150)), 0, 7);
        c.stroke();
        c.setLineDash([]);
        c.save();
        c.translate(tgt.x, tgt.y);
        c.rotate(spin);
        for (let k = 0; k < 4; k++) {
          c.rotate(Math.PI / 2);
          c.beginPath();
          c.moveTo(9, 0);
          c.lineTo(15, 0);
          c.stroke();
        }
        c.restore();
        ring(tgt.x, tgt.y, 7, col, 0.9, 1.2);
        c.globalAlpha = 0.95;
        c.fillStyle = col;
        c.font = "10px 'JetBrains Mono', monospace";
        c.fillText(m.from ? "LOCK" : "ALERT", tgt.x + 18, tgt.y - 10);
        c.fillStyle = "#e5f6fb";
        c.font = "11px 'Hind Siliguri', sans-serif";
        c.fillText(labelLang === "bn" ? m.to.nameBn : m.to.name, tgt.x + 18, tgt.y + 3);
      }
    });
  }

  /* aircraft */
  if (L.aircraft) {
    const ad = peek<AircraftData>("aircraft");
    if (ad) {
      const dt = Math.min(120, (Date.now() - ad.fetchedAt) / 1000);
      c.globalAlpha = 0.6;
      c.fillStyle = "#67e8f9";
      c.beginPath();
      const milList: { p: Pt; ac: Ac; lat: number; lng: number }[] = [];
      for (const ac of ad.aircraft) {
        const hr = ac.h * DEG;
        const lat = ac.y + ((ac.v * dt * Math.cos(hr)) / 111320);
        const lng = ac.x + ((ac.v * dt * Math.sin(hr)) / (111320 * Math.max(0.1, Math.cos(ac.y * DEG))));
        const p = proj(lat, lng);
        if (!p) continue;
        if (ac.m) milList.push({ p, ac, lat, lng });
        else c.rect(p.x - 1, p.y - 1, 2, 2);
      }
      c.fill();
      let labels = 0;
      milList.forEach(({ p, ac, lat, lng }, idx) => {
        const hr = ac.h * DEG;
        const q = map!.project([lng + (20 / (111 * Math.max(0.2, Math.cos(lat * DEG)))) * Math.sin(hr), lat + (20 / 111) * Math.cos(hr)]);
        const ang = Math.atan2(q.y - p.y, q.x - p.x);
        c.save();
        c.translate(p.x, p.y);
        c.rotate(ang);
        c.globalAlpha = 0.4;
        c.strokeStyle = "#fb923c";
        c.lineWidth = 1;
        c.beginPath();
        c.moveTo(-3, 0);
        c.lineTo(-24, 0);
        c.stroke();
        c.globalAlpha = 1;
        c.fillStyle = "#fb923c";
        c.beginPath();
        c.moveTo(6, 0);
        c.lineTo(-4, 3.6);
        c.lineTo(-2, 0);
        c.lineTo(-4, -3.6);
        c.closePath();
        c.fill();
        c.restore();
        if ((idx + Math.floor(tms / 1600)) % 6 === 0) {
          const f = (tms % 1600) / 1600;
          ring(p.x, p.y, 4 + f * 16, "#fb923c", (1 - f) * 0.7, 1);
        }
        if (labels < 14 && (zoom > 2.4 || milList.length < 30)) {
          labels++;
          c.globalAlpha = 0.9;
          c.fillStyle = "#fed7aa";
          c.fillText(`${ac.c || ac.i.toUpperCase()} FL${String(Math.round((ac.a * 3.281) / 100)).padStart(3, "0")}`, p.x + 8, p.y - 6);
        }
      });
    }
  }

  /* satellite-mode target lock on the hottest zone */
  if (L.satmode && intel?.hotspots[0]) {
    const h = intel.hotspots[0];
    const p = proj(h.lat, h.lng);
    if (p) {
      const k = (tms % 3000) / 3000;
      const s = 70 - k * 34;
      c.globalAlpha = 0.95;
      c.strokeStyle = "#ef4444";
      c.lineWidth = 1.5;
      const x0 = p.x - s,
        y0 = p.y - s,
        d = s * 2,
        t = 12;
      c.beginPath();
      [[x0, y0, 1, 1], [x0 + d, y0, -1, 1], [x0, y0 + d, 1, -1], [x0 + d, y0 + d, -1, -1]].forEach(([x, y, sx, sy]) => {
        c.moveTo(x, y + sy * t);
        c.lineTo(x, y);
        c.lineTo(x + sx * t, y);
      });
      c.stroke();
      c.setLineDash([2, 4]);
      c.beginPath();
      c.moveTo(p.x - s - 14, p.y);
      c.lineTo(p.x + s + 14, p.y);
      c.moveTo(p.x, p.y - s - 14);
      c.lineTo(p.x, p.y + s + 14);
      c.stroke();
      c.setLineDash([]);
      c.fillStyle = "#fca5a5";
      c.fillText(`TGT-LOCK ${h.lat.toFixed(3)} ${h.lng.toFixed(3)}`, x0, y0 - 9);
    }
  }
  c.globalAlpha = 1;
}

function drawArc(id: string, from: { lat: number; lng: number }, to: { lat: number; lng: number }, color: string, t: number, period: number, missile: boolean) {
  if (!cx || !map) return;
  const c = cx;
  let a = arcCache.get(id);
  if (!a) {
    a = { pts: gcPoints(from, to, 48), km: distKm(from, to) };
    arcCache.set(id, a);
    if (arcCache.size > 60) arcCache.delete(arcCache.keys().next().value as string);
  }
  const phase = ((t % period) + period) % period / period;
  const flight = missile ? 0.7 : 0.9;
  const prog = Math.min(1, phase / flight);
  const n = a.pts.length - 1;
  const liftMax = Math.min(130, 18 + a.km * 0.022);
  const proj2 = (i: number): Pt | null => {
    const q = proj(a!.pts[i][0], a!.pts[i][1]);
    if (!q) return null;
    const f = i / n;
    return { x: q.x, y: q.y - Math.sin(Math.PI * f) * liftMax };
  };
  // faint full path
  c.setLineDash([2, 5]);
  c.globalAlpha = 0.28;
  c.strokeStyle = color;
  c.lineWidth = 1;
  c.beginPath();
  let pen = false;
  for (let i = 0; i <= n; i++) {
    const p = proj2(i);
    if (!p) {
      pen = false;
      continue;
    }
    if (!pen) c.moveTo(p.x, p.y);
    else c.lineTo(p.x, p.y);
    pen = true;
  }
  c.stroke();
  c.setLineDash([]);
  // travelled trail
  const upto = Math.floor(prog * n);
  c.globalAlpha = 0.95;
  c.lineWidth = 2;
  c.beginPath();
  pen = false;
  for (let i = Math.max(0, upto - 14); i <= upto; i++) {
    const p = proj2(i);
    if (!p) {
      pen = false;
      continue;
    }
    if (!pen) c.moveTo(p.x, p.y);
    else c.lineTo(p.x, p.y);
    pen = true;
  }
  c.stroke();
  const head = proj2(Math.min(n, upto));
  if (phase <= flight && head) {
    const g = c.createRadialGradient(head.x, head.y, 0, head.x, head.y, 10);
    g.addColorStop(0, "#ffffff");
    g.addColorStop(0.3, color);
    g.addColorStop(1, "rgba(0,0,0,0)");
    c.globalAlpha = 1;
    c.fillStyle = g;
    c.beginPath();
    c.arc(head.x, head.y, 10, 0, 7);
    c.fill();
  }
  if (missile) {
    if (phase < 0.08) {
      const p = proj2(0);
      if (p) ring(p.x, p.y, 4 + (phase / 0.08) * 22, "#ffffff", 1 - phase / 0.08, 1.5);
    }
    if (phase >= flight && phase < flight + 0.18) {
      const end = proj2(n);
      if (end) {
        const f = (phase - flight) / 0.18;
        ring(end.x, end.y + liftMax * 0, 6 + f * 40, color, 1 - f, 2);
        c.globalAlpha = (1 - f) * 0.5;
        c.fillStyle = color;
        c.beginPath();
        c.arc(end.x, end.y, 4 + f * 14, 0, 7);
        c.fill();
      }
    }
  }
  c.globalAlpha = 1;
}
