import { GEO_BY_KEY } from "./geo";
import { LEVEL_WEIGHT, type Intel } from "./types";

export interface Scenario {
  key: string;
  bn: string;
  en: string;
  keys: string[]; // gazetteer keys used to pull live reporting
  base: { military: number; econ: number; nuclear: number };
  military: { bn: string[]; en: string[] };
  econ: { bn: string[]; en: string[] };
  nuclear: { bn: string; en: string };
  facts: { bn: string; en: string };
}

/**
 * Structural parameters are analyst-style model assumptions built on widely documented facts
 * (trade volumes, nuclear status). Live reporting intensity (real news) is blended in at run time.
 */
export const SCENARIOS: Scenario[] = [
  {
    key: "hormuz",
    bn: "হরমুজ প্রণালী",
    en: "Strait of Hormuz",
    keys: ["hormuz", "iran", "saudi", "uae", "qatar", "iraq", "yemen"],
    base: { military: 62, econ: 92, nuclear: 24 },
    military: {
      bn: ["নৌ-অবরোধ ও ট্যাংকার হয়রানির ঝুঁকি বৃদ্ধি", "উপকূলীয় ক্ষেপণাস্ত্র ও ড্রোন হুমকিতে বাণিজ্যিক জাহাজ ঝুঁকিতে", "মার্কিন ও মিত্র নৌবহরের দ্রুত মোতায়েনের সম্ভাবনা"],
      en: ["Higher risk of naval blockade and tanker harassment", "Commercial shipping exposed to coastal missile and drone threats", "Likely rapid deployment of US and allied naval forces"],
    },
    econ: {
      bn: ["বিশ্বের প্রায় এক-পঞ্চমাংশ তেল ও উল্লেখযোগ্য এলএনজি এই পথে যায় (EIA)", "বিমা প্রিমিয়াম ও ফ্রেইট খরচে তাৎক্ষণিক উল্লম্ফন", "এশিয়ার আমদানিনির্ভর অর্থনীতিতে (বাংলাদেশসহ) জ্বালানি সংকটের ঝুঁকি"],
      en: ["About one-fifth of world oil and a large share of LNG transits here (EIA)", "Immediate spike in insurance premiums and freight costs", "Fuel-supply risk for import-dependent Asian economies"],
    },
    nuclear: { bn: "ইরানের পরমাণু কর্মসূচি ও মার্কিন-ইসরায়েলি প্রতিক্রিয়া এই ঝুঁকির মূল চালক।", en: "Iran's nuclear programme and US/Israeli responses are the main drivers." },
    facts: { bn: "প্রণালীর সংকীর্ণতম অংশ প্রায় ৩৯ কিমি; জাহাজ চলাচল লেন মাত্র ৩ কিমি করে প্রশস্ত।", en: "Narrowest point is ~39 km; each shipping lane is only ~3 km wide." },
  },
  {
    key: "taiwan",
    bn: "তাইওয়ান প্রণালী",
    en: "Taiwan Strait",
    keys: ["taiwan", "taiwanstrait", "china", "japan", "usa", "philippines", "scs"],
    base: { military: 74, econ: 96, nuclear: 38 },
    military: {
      bn: ["বিমান ও নৌ অবরোধ-অনুশীলন সংঘাতে রূপ নেওয়ার ঝুঁকি", "জাপান ও ফিলিপাইনে অবস্থিত মার্কিন ঘাঁটি জড়িয়ে পড়ার সম্ভাবনা", "সাবমেরিন কেবল ও জাহাজ চলাচলে ব্যাঘাত"],
      en: ["Blockade-style drills could tip into open conflict", "US bases in Japan and the Philippines could be drawn in", "Disruption to submarine cables and shipping"],
    },
    econ: {
      bn: ["বিশ্বের সবচেয়ে উন্নত সেমিকন্ডাক্টরের প্রায় ৯০% তাইওয়ানে তৈরি", "বৈশ্বিক কনটেইনার বাণিজ্যের বড় অংশ প্রণালী দিয়ে যায়", "ইলেকট্রনিক্স ও গার্মেন্ট সাপ্লাই চেইনে ব্যাপক প্রভাব"],
      en: ["Roughly 90% of the most advanced semiconductors are made in Taiwan", "A large share of global container trade passes through the strait", "Severe knock-on for electronics and apparel supply chains"],
    },
    nuclear: { bn: "চীন ও যুক্তরাষ্ট্র উভয়ই পরমাণু শক্তিধর হওয়ায় সরাসরি সংঘাত সর্বোচ্চ ঝুঁকির।", en: "Both China and the US are nuclear powers, making direct conflict the highest-risk case." },
    facts: { bn: "প্রণালীর প্রস্থ সর্বনিম্ন প্রায় ১৩০ কিমি।", en: "The strait is ~130 km wide at its narrowest." },
  },
  {
    key: "eeurope",
    bn: "পূর্ব ইউরোপ",
    en: "Eastern Europe",
    keys: ["ukraine", "russia", "belarus", "poland", "lithuania", "finland", "nato", "blacksea", "baltic", "germany"],
    base: { military: 86, econ: 70, nuclear: 46 },
    military: {
      bn: ["ক্ষেপণাস্ত্র ও ড্রোন হামলার ধারাবাহিকতা এবং গুরুত্বপূর্ণ অবকাঠামোতে আঘাত", "ন্যাটোর পূর্ব সীমান্তে সংঘাত ছড়িয়ে পড়ার ঝুঁকি", "বাল্টিক ও কৃষ্ণ সাগরে নৌ ও সাইবার ঘটনা"],
      en: ["Sustained missile/drone strikes and attacks on critical infrastructure", "Risk of spill-over along NATO's eastern flank", "Naval and cyber incidents in the Baltic and Black Seas"],
    },
    econ: {
      bn: ["ইউরোপের গ্যাস ও বিদ্যুৎ বাজারে অস্থিরতা", "কৃষ্ণ সাগর দিয়ে গম ও ভুট্টা রপ্তানি ব্যাহত হলে খাদ্যমূল্য বৃদ্ধি", "সার ও জ্বালানি সরবরাহে প্রভাব"],
      en: ["Volatility in European gas and power markets", "Grain export disruption through the Black Sea lifts food prices", "Impact on fertiliser and energy supply"],
    },
    nuclear: { bn: "রাশিয়ার পারমাণবিক অস্ত্রভাণ্ডার ও পারমাণবিক বক্তব্য উত্তেজনার প্রধান উপাদান; জাপোরিঝিয়া কেন্দ্রের নিরাপত্তাও উদ্বেগের।", en: "Russia's arsenal and nuclear rhetoric are central; Zaporizhzhia plant safety is a further concern." },
    facts: { bn: "ইউক্রেন যুদ্ধ ২০২২ সালের ২৪ ফেব্রুয়ারি পূর্ণমাত্রায় শুরু হয়।", en: "The full-scale war began on 24 February 2022." },
  },
  {
    key: "korea",
    bn: "কোরীয় উপদ্বীপ",
    en: "Korean Peninsula",
    keys: ["nkorea", "skorea", "japan", "usa", "china"],
    base: { military: 70, econ: 66, nuclear: 52 },
    military: {
      bn: ["সিউল ডিএমজেড থেকে প্রায় ৪০–৫০ কিমি দূরে—কামান ও রকেটের সরাসরি ঝুঁকি", "উত্তর কোরিয়ার ক্ষেপণাস্ত্র পরীক্ষায় জাপান সাগরে নৌ-সতর্কতা", "মার্কিন–দক্ষিণ কোরিয়া যৌথ প্রতিরক্ষা সক্রিয়"],
      en: ["Seoul lies ~40–50 km from the DMZ — direct artillery/rocket exposure", "Missile tests prompt maritime warnings in the Sea of Japan", "US–ROK joint defence activated"],
    },
    econ: {
      bn: ["মেমরি চিপ ও ইলেকট্রনিক্স সরবরাহ চেইনে ঝুঁকি (স্যামসাং, এসকে হাইনিক্স)", "পূর্ব এশীয় শিপিং রুটে বিমা ব্যয় বৃদ্ধি"],
      en: ["Risk to memory-chip and electronics supply chains", "Higher insurance costs on East Asian shipping routes"],
    },
    nuclear: { bn: "উত্তর কোরিয়া পরমাণু অস্ত্রধর রাষ্ট্র; ক্ষেপণাস্ত্র ও পরমাণু পরীক্ষা উত্তেজনার মূল সূচক।", en: "North Korea is nuclear-armed; missile and nuclear tests are the key indicators." },
    facts: { bn: "১৯৫৩ সালের যুদ্ধবিরতি এখনও কোনো শান্তিচুক্তিতে রূপ নেয়নি।", en: "The 1953 armistice has never been replaced by a peace treaty." },
  },
  {
    key: "redsea",
    bn: "লোহিত সাগর ও বাব-এল-মান্দেব",
    en: "Red Sea & Bab el-Mandeb",
    keys: ["redsea", "yemen", "suez", "egypt", "israel", "saudi"],
    base: { military: 58, econ: 80, nuclear: 14 },
    military: {
      bn: ["বাণিজ্যিক জাহাজে ড্রোন ও ক্ষেপণাস্ত্র হামলার ঝুঁকি", "আন্তর্জাতিক নৌ-টহল ও এসকর্ট মিশন বৃদ্ধি"],
      en: ["Drone and missile attack risk against merchant ships", "More international naval patrols and escort missions"],
    },
    econ: {
      bn: ["সুয়েজ খাল হয়ে বৈশ্বিক বাণিজ্যের প্রায় ১২% যায়", "কেপ অব গুড হোপ ঘুরে যাওয়ায় ভ্রমণ সময় ও খরচ বৃদ্ধি", "মিশরের সুয়েজ রাজস্বে চাপ"],
      en: ["About 12% of global trade passes via the Suez route", "Rerouting around the Cape raises transit time and cost", "Pressure on Egypt's Suez revenues"],
    },
    nuclear: { bn: "সরাসরি পারমাণবিক ঝুঁকি কম; তবে ইরান–ইসরায়েল উত্তেজনার মাধ্যমে পরোক্ষ প্রভাব সম্ভব।", en: "Direct nuclear risk is low; indirect effects possible via Iran–Israel tensions." },
    facts: { bn: "বাব-এল-মান্দেবের সংকীর্ণতম অংশ প্রায় ২৯ কিমি।", en: "Bab el-Mandeb is only ~29 km wide at its narrowest." },
  },
  {
    key: "scs",
    bn: "দক্ষিণ চীন সাগর",
    en: "South China Sea",
    keys: ["scs", "philippines", "china", "usa", "japan"],
    base: { military: 56, econ: 88, nuclear: 26 },
    military: {
      bn: ["কোস্ট গার্ড ও নৌ-মিলিশিয়ার মুখোমুখি সংঘর্ষের ঝুঁকি", "ফিলিপাইন–যুক্তরাষ্ট্র প্রতিরক্ষা চুক্তির সক্রিয়করণের সম্ভাবনা"],
      en: ["Risk of coast-guard and maritime-militia confrontations", "Possible activation of the US–Philippines defence treaty"],
    },
    econ: {
      bn: ["বৈশ্বিক সামুদ্রিক বাণিজ্যের প্রায় এক-তৃতীয়াংশ এই জলপথ দিয়ে যায়", "বাংলাদেশ–পূর্ব এশিয়া বাণিজ্যপথে প্রভাব"],
      en: ["Roughly a third of global maritime trade crosses these waters", "Impact on South Asia–East Asia trade lanes"],
    },
    nuclear: { bn: "সীমিত সংঘর্ষ থেকে বৃহত্তর চীন–যুক্তরাষ্ট্র উত্তেজনায় রূপ নিলে ঝুঁকি বাড়ে।", en: "Risk grows if limited clashes escalate into wider China–US tension." },
    facts: { bn: "২০১৬ সালের আন্তর্জাতিক ট্রাইব্যুনাল রায় চীনের ‘নাইন-ড্যাশ লাইন’ দাবি খারিজ করে।", en: "A 2016 tribunal ruling rejected China's 'nine-dash line' claims." },
  },
  {
    key: "indpak",
    bn: "ভারত–পাকিস্তান / কাশ্মীর",
    en: "India–Pakistan / Kashmir",
    keys: ["india", "pakistan", "kashmir", "afghanistan", "china"],
    base: { military: 60, econ: 55, nuclear: 58 },
    military: {
      bn: ["নিয়ন্ত্রণরেখায় গোলাবর্ষণ ও ড্রোন কার্যক্রম", "ক্ষেপণাস্ত্র ও বিমান-হামলার প্রতিশোধমূলক চক্র"],
      en: ["Shelling and drone activity along the Line of Control", "Retaliatory missile and air-strike cycles"],
    },
    econ: {
      bn: ["দক্ষিণ এশীয় বাণিজ্য, আকাশপথ ও সীমান্ত বাজারে ব্যাঘাত", "বাংলাদেশসহ প্রতিবেশী দেশের জ্বালানি ও পণ্য সরবরাহে পরোক্ষ চাপ"],
      en: ["Disruption to South Asian trade, airspace and border markets", "Indirect pressure on fuel and goods supply for neighbours incl. Bangladesh"],
    },
    nuclear: { bn: "দুই দেশই পারমাণবিক অস্ত্রধর; দ্রুত বৃদ্ধি ও ভুল হিসাবের ঝুঁকি বিদ্যমান।", en: "Both states are nuclear-armed; rapid escalation and miscalculation risk exist." },
    facts: { bn: "দুই দেশ ১৯৯৮ সালে পারমাণবিক পরীক্ষা চালায়।", en: "Both conducted nuclear tests in 1998." },
  },
];

export interface Country2 {
  key: string;
  nuclear: boolean;
  nato: boolean;
  g20: boolean;
  energy: boolean;
}
export const PAIR_COUNTRIES: Country2[] = [
  { key: "russia", nuclear: true, nato: false, g20: true, energy: true },
  { key: "ukraine", nuclear: false, nato: false, g20: false, energy: false },
  { key: "china", nuclear: true, nato: false, g20: true, energy: false },
  { key: "taiwan", nuclear: false, nato: false, g20: false, energy: false },
  { key: "usa", nuclear: true, nato: true, g20: true, energy: true },
  { key: "israel", nuclear: true, nato: false, g20: false, energy: false },
  { key: "iran", nuclear: false, nato: false, g20: false, energy: true },
  { key: "india", nuclear: true, nato: false, g20: true, energy: false },
  { key: "pakistan", nuclear: true, nato: false, g20: false, energy: false },
  { key: "nkorea", nuclear: true, nato: false, g20: false, energy: false },
  { key: "skorea", nuclear: false, nato: false, g20: true, energy: false },
  { key: "japan", nuclear: false, nato: false, g20: true, energy: false },
  { key: "turkey", nuclear: false, nato: true, g20: true, energy: false },
  { key: "saudi", nuclear: false, nato: false, g20: true, energy: true },
  { key: "poland", nuclear: false, nato: true, g20: false, energy: false },
  { key: "bangladesh", nuclear: false, nato: false, g20: false, energy: false },
];

export interface SimResult {
  title: { bn: string; en: string };
  military: number;
  econ: number;
  escalation: number;
  liveScore: number;
  evidence: number;
  military_txt: { bn: string[]; en: string[] };
  econ_txt: { bn: string[]; en: string[] };
  nuclear_txt: { bn: string; en: string };
  fact?: { bn: string; en: string };
  evidenceIds: string[];
}

const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));

function live(intel: Intel | null, keys: string[], need2 = false): { score: number; n: number; ids: string[] } {
  if (!intel) return { score: 0, n: 0, ids: [] };
  const now = Date.now();
  let s = 0;
  const ids: string[] = [];
  for (const it of intel.items) {
    const hits = new Set(it.geo.map((g) => (g.kind === "country" ? g.key : GEO_BY_KEY[g.key]?.parent || g.key)));
    const matched = keys.filter((k) => hits.has(k)).length;
    if (matched === 0 || (need2 && matched < 2 && keys.length >= 2)) continue;
    const w = LEVEL_WEIGHT[it.level] * Math.pow(0.5, (now - Date.parse(it.publishedAt)) / 3600e3 / 12) * (need2 ? 1.6 : 1);
    s += w;
    if (ids.length < 5) ids.push(it.id);
  }
  return { score: Math.round(100 * (1 - Math.exp(-s / 12))), n: ids.length, ids };
}

export function simulateScenario(intel: Intel | null, key: string): SimResult {
  const sc = SCENARIOS.find((s) => s.key === key) ?? SCENARIOS[0];
  const lv = live(intel, sc.keys);
  return {
    title: { bn: sc.bn, en: sc.en },
    military: Math.round(clamp(sc.base.military * 0.6 + lv.score * 0.4, 5, 98)),
    econ: Math.round(clamp(sc.base.econ * 0.75 + lv.score * 0.25, 5, 98)),
    escalation: Math.round(clamp(sc.base.nuclear * 0.6 + lv.score * 0.4, 3, 95)),
    liveScore: lv.score,
    evidence: lv.n,
    military_txt: sc.military,
    econ_txt: sc.econ,
    nuclear_txt: sc.nuclear,
    fact: sc.facts,
    evidenceIds: lv.ids,
  };
}

export function simulatePair(intel: Intel | null, a: string, b: string): SimResult {
  const A = PAIR_COUNTRIES.find((c) => c.key === a)!;
  const B = PAIR_COUNTRIES.find((c) => c.key === b)!;
  const ga = GEO_BY_KEY[a];
  const gb = GEO_BY_KEY[b];
  const lv = live(intel, [a, b], true);
  const nukes = Number(A.nuclear) + Number(B.nuclear);
  const nato = A.nato || B.nato;
  const military = clamp(28 + nukes * 14 + (nato ? 10 : 0) + lv.score * 0.45, 5, 98);
  const econ = clamp(24 + Number(A.g20) * 18 + Number(B.g20) * 18 + Number(A.energy || B.energy) * 12 + lv.score * 0.2, 5, 98);
  const esc = clamp(nukes === 2 ? 40 : nukes === 1 ? 20 : 8, 3, 95) * 0.6 + lv.score * 0.4 + (nato && nukes ? 6 : 0);
  return {
    title: { bn: `${ga.nameBn} বনাম ${gb.nameBn}`, en: `${ga.name} vs ${gb.name}` },
    military: Math.round(military),
    econ: Math.round(econ),
    escalation: Math.round(clamp(esc, 3, 95)),
    liveScore: lv.score,
    evidence: lv.n,
    military_txt: {
      bn: [
        nukes === 2 ? "দুই পক্ষই পারমাণবিক অস্ত্রধর—প্রচলিত সংঘাত দ্রুত কৌশলগত স্তরে যাওয়ার ঝুঁকি" : nukes === 1 ? "এক পক্ষ পারমাণবিক শক্তিধর—অসম প্রতিরোধ ও জোট-হস্তক্ষেপের সম্ভাবনা" : "উভয় পক্ষই অ-পারমাণবিক—সংঘাত প্রচলিত যুদ্ধের গণ্ডিতে সীমাবদ্ধ থাকার সম্ভাবনা বেশি",
        nato ? "ন্যাটো সংশ্লিষ্টতা থাকায় যৌথ প্রতিরক্ষা অনুচ্ছেদ আলোচনায় আসতে পারে" : "জোট-হস্তক্ষেপের সম্ভাবনা তুলনামূলক সীমিত",
        lv.n > 0 ? `সাম্প্রতিক প্রতিবেদনে উভয় দেশের উল্লেখ পাওয়া গেছে (${lv.n}টি সংবাদ)` : "সাম্প্রতিক সংবাদে দুই দেশের সরাসরি যৌথ উল্লেখ পাওয়া যায়নি",
      ],
      en: [
        nukes === 2 ? "Both sides are nuclear-armed — a conventional clash could escalate quickly" : nukes === 1 ? "One side is a nuclear power — asymmetric deterrence and alliance involvement possible" : "Neither side is nuclear-armed — conflict likely stays conventional",
        nato ? "NATO involvement could bring collective-defence provisions into play" : "Alliance intervention is comparatively limited",
        lv.n > 0 ? `Recent reporting mentions both states (${lv.n} items)` : "No recent reporting jointly mentions both states",
      ],
    },
    econ_txt: {
      bn: [A.g20 || B.g20 ? "জি-২০ অর্থনীতি জড়িত—বৈশ্বিক বাজার ও সাপ্লাই চেইনে প্রভাব" : "আঞ্চলিক বাণিজ্যে সীমিত থেকে মাঝারি প্রভাব", A.energy || B.energy ? "জ্বালানি রপ্তানিকারক জড়িত—তেল ও গ্যাসের দামে অস্থিরতা" : "জ্বালানি বাজারে প্রত্যক্ষ প্রভাব কম"],
      en: [A.g20 || B.g20 ? "G20 economy involved — global markets and supply chains affected" : "Limited to moderate regional trade impact", A.energy || B.energy ? "Energy exporter involved — oil and gas price volatility" : "Limited direct effect on energy markets"],
    },
    nuclear_txt: {
      bn: nukes ? "পারমাণবিক শক্তিধর পক্ষ থাকায় উত্তেজনা বৃদ্ধির হার ঝুঁকিপূর্ণ হিসেবে ধরা হয়েছে।" : "কোনো পক্ষের পরমাণু অস্ত্র নেই; ঝুঁকি মূলত তৃতীয় পক্ষের জড়িয়ে পড়ার ওপর নির্ভরশীল।",
      en: nukes ? "A nuclear-armed party is involved, raising the escalation estimate." : "No nuclear-armed party; risk depends on third-party involvement.",
    },
    evidenceIds: lv.ids,
  };
}
