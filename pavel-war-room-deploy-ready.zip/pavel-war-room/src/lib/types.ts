export const CATEGORIES = ["missile", "airstrike", "cyber", "naval", "border", "nuclear"] as const;
export type CategoryKey = (typeof CATEGORIES)[number];
export const LEVELS = ["LOW", "GUARDED", "ELEVATED", "HIGH", "CRITICAL"] as const;
export type ThreatLevel = (typeof LEVELS)[number];
export type Lang = "bn" | "en" | "ar";

export interface Tri {
  bn: string;
  en: string;
  ar: string;
}

export const CAT_LABEL: Record<CategoryKey, Tri> = {
  missile: { bn: "ক্ষেপণাস্ত্র সতর্কতা", en: "Missile Alert", ar: "تنبيه صاروخي" },
  airstrike: { bn: "বিমান হামলা", en: "Air Strike", ar: "غارة جوية" },
  cyber: { bn: "সাইবার হামলা", en: "Cyber Attack", ar: "هجوم سيبراني" },
  naval: { bn: "নৌবাহিনী চলাচল", en: "Naval Movement", ar: "تحركات بحرية" },
  border: { bn: "সীমান্ত উত্তেজনা", en: "Border Tension", ar: "توتر حدودي" },
  nuclear: { bn: "পারমাণবিক ঝুঁকি", en: "Nuclear Risk", ar: "خطر نووي" },
};

export const LEVEL_LABEL: Record<ThreatLevel, Tri> = {
  LOW: { bn: "নিম্ন", en: "Low", ar: "منخفض" },
  GUARDED: { bn: "সতর্ক", en: "Guarded", ar: "حذر" },
  ELEVATED: { bn: "উদ্বেগজনক", en: "Elevated", ar: "مرتفع" },
  HIGH: { bn: "উচ্চ", en: "High", ar: "عال" },
  CRITICAL: { bn: "সংকটজনক", en: "Critical", ar: "حرج" },
};

export const LEVEL_COLOR: Record<ThreatLevel, string> = {
  LOW: "#4ade80",
  GUARDED: "#22d3ee",
  ELEVATED: "#facc15",
  HIGH: "#fb923c",
  CRITICAL: "#ef4444",
};

export const LEVEL_WEIGHT: Record<ThreatLevel, number> = {
  LOW: 1,
  GUARDED: 2,
  ELEVATED: 3,
  HIGH: 4.5,
  CRITICAL: 6,
};

export interface GeoTag {
  key: string;
  name: string;
  nameBn: string;
  lat: number;
  lng: number;
  kind: "country" | "region" | "city";
}

export type PropagandaRisk = "MIN" | "LOW" | "MED" | "HIGH";

export interface Verification {
  score: number; // 0-100 source-reliability + cross-source corroboration
  risk: PropagandaRisk;
  corroboration: number; // number of other independent sources reporting a similar story
  tier: 1 | 2 | 3 | 4; // 1 wire/public broadcaster, 2 major outlet, 3 unknown, 4 state-affiliated
  unverified: boolean;
}

export interface NewsItem {
  id: string;
  title: string;
  titleT: string; // translated into requested language (falls back to original)
  summary: string;
  summaryT: string;
  url: string;
  source: string;
  via: string; // feed that supplied it (BBC RSS, GDELT, ...)
  publishedAt: string;
  category: CategoryKey;
  level: ThreatLevel;
  verification: Verification;
  geo: GeoTag[];
  translated: boolean;
}

export interface SourceStatus {
  name: string;
  ok: boolean;
  count: number;
  note?: string;
}

export interface CountryScore {
  key: string;
  en: string;
  bn: string;
  lat: number;
  lng: number;
  score: number;
  count: number;
  delta: number;
}

export interface Hotspot {
  key: string;
  name: string;
  nameBn: string;
  lat: number;
  lng: number;
  count: number;
  score: number;
  level: ThreatLevel;
}

export interface Trajectory {
  id: string;
  newsId: string;
  title: string;
  level: ThreatLevel;
  from: GeoTag | null;
  to: GeoTag;
}

export interface AnalysisMetrics {
  borderEscalation: number;
  conflictProbability: number;
  nuclearRisk: number;
  cyberThreat: number;
  instability: number;
  movementActivity: number;
  topHotspot: string | null;
  topHotspotBn: string | null;
  basisCount: number;
  recentCount: number;
}

export interface Intel {
  generatedAt: string;
  lang: Lang;
  items: NewsItem[];
  sources: SourceStatus[];
  stats: {
    total: number;
    byCategory: Record<CategoryKey, number>;
    byLevel: Record<ThreatLevel, number>;
    activeConflicts: number;
    gti: number;
    nuclearLevel: ThreatLevel;
    nuclearIndex: number;
  };
  series: Record<"all" | CategoryKey, number[]>;
  countries: CountryScore[];
  hotspots: Hotspot[];
  missiles: Trajectory[];
  cyberRoutes: Trajectory[];
  analysis: AnalysisMetrics;
}
