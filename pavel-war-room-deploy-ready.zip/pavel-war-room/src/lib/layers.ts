"use client";
import { useSyncExternalStore } from "react";

export type LayerId = "aircraft" | "missiles" | "heat" | "naval" | "cyber" | "thermal" | "gpsjam" | "spysat" | "cables" | "weather" | "satmode";

export type LayerState = Record<LayerId, boolean>;

let state: LayerState = {
  aircraft: true,
  missiles: true,
  heat: true,
  naval: true,
  cyber: false,
  thermal: false,
  gpsjam: false,
  spysat: false,
  cables: false,
  weather: false,
  satmode: false,
};
const listeners = new Set<() => void>();

export const getLayers = () => state;
export function setLayer(id: LayerId, on: boolean) {
  if (state[id] === on) return;
  state = { ...state, [id]: on };
  listeners.forEach((l) => l());
}
export const toggleLayer = (id: LayerId) => setLayer(id, !state[id]);
export const subscribeLayers = (cb: () => void) => {
  listeners.add(cb);
  return () => listeners.delete(cb);
};
export const useLayers = () => useSyncExternalStore(subscribeLayers, getLayers, getLayers);
