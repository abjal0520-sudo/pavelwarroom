import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";

type GlobalWithPool = typeof globalThis & {
  __pavelWarRoomPool?: Pool;
};

const globalForDb = globalThis as GlobalWithPool;
let database: ReturnType<typeof drizzle> | null = null;

/**
 * PostgreSQL is optional for the application runtime.
 * Without DATABASE_URL, live feeds still work; only persistence is disabled.
 */
export function getDb() {
  const databaseUrl = process.env.DATABASE_URL?.trim();
  if (!databaseUrl) return null;

  const pool =
    globalForDb.__pavelWarRoomPool ??
    new Pool({
      connectionString: databaseUrl,
      max: 3,
      idleTimeoutMillis: 10_000,
      connectionTimeoutMillis: 5_000,
    });

  if (process.env.NODE_ENV !== "production") {
    globalForDb.__pavelWarRoomPool = pool;
  } else if (!globalForDb.__pavelWarRoomPool) {
    // Reuse the pool across warm serverless invocations where the runtime permits it.
    globalForDb.__pavelWarRoomPool = pool;
  }

  database ??= drizzle(pool);
  return database;
}

export function isDatabaseConfigured() {
  return Boolean(process.env.DATABASE_URL?.trim());
}
