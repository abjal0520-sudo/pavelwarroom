import { jsonb, pgTable, text, timestamp, varchar } from "drizzle-orm/pg-core";

// Cache of machine translations (sha1(lang|text) -> translated text)
export const translations = pgTable("translations", {
  key: varchar("key", { length: 64 }).primaryKey(),
  lang: varchar("lang", { length: 8 }).notNull(),
  text: text("text").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Persisted intelligence items (real articles collected from live sources)
export const newsItems = pgTable("news_items", {
  id: varchar("id", { length: 40 }).primaryKey(),
  source: text("source").notNull(),
  title: text("title").notNull(),
  titleBn: text("title_bn"),
  url: text("url").notNull(),
  category: varchar("category", { length: 16 }),
  level: varchar("level", { length: 12 }).notNull(),
  publishedAt: timestamp("published_at").notNull(),
  firstSeen: timestamp("first_seen").defaultNow().notNull(),
  geo: jsonb("geo"),
});
