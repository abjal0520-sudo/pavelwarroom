import { NextResponse } from "next/server";
import { getIntel } from "@/lib/server/news";
import type { Lang } from "@/lib/types";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";
export const maxDuration = 60;

export async function GET(req: Request) {
  const l = new URL(req.url).searchParams.get("lang");
  const lang: Lang = l === "en" || l === "ar" ? l : "bn";
  try {
    return NextResponse.json(await getIntel(lang), { headers: { "Cache-Control": "public, s-maxage=20, stale-while-revalidate=40" } });
  } catch (e) {
    return NextResponse.json({ error: String((e as Error).message) }, { status: 502 });
  }
}
