import { getDb, isDatabaseConfigured } from "@/db";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET() {
  if (!isDatabaseConfigured()) {
    return Response.json({
      ok: true,
      database: "not_configured",
      persistence: "disabled",
    });
  }

  try {
    const db = getDb();
    if (!db) throw new Error("Database configuration is missing");
    await db.execute(sql`select 1`);
    return Response.json({ ok: true, database: "connected" });
  } catch {
    return Response.json({ ok: false, database: "unavailable" }, { status: 503 });
  }
}
