import { NextResponse } from "next/server";
import { findGeo } from "@/lib/geo";
import { classify } from "@/lib/server/classify";
import { translateMany } from "@/lib/server/translate";

export const dynamic = "force-dynamic";

const STOP = new Set("the and for with that this from have has had will would after over into amid says said are was were its their they them his her about more than been being who what when where which while also not but out off".split(" "));

/** Extractive tactical summariser: picks the most information-dense sentences and tags them. */
export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as { text?: string; lang?: string };
  const text = (body.text ?? "").replace(/\s+/g, " ").trim().slice(0, 12000);
  const lang = body.lang === "en" || body.lang === "ar" ? body.lang : "bn";
  if (text.length < 80) return NextResponse.json({ error: "short" }, { status: 400 });

  const sentences = text.match(/[^.!?।]+[.!?।]?/g)?.map((s) => s.trim()).filter((s) => s.length > 30) ?? [];
  const freq = new Map<string, number>();
  for (const w of text.toLowerCase().match(/[a-z\u0980-\u09ff\u0600-\u06ff]{4,}/g) ?? []) if (!STOP.has(w)) freq.set(w, (freq.get(w) ?? 0) + 1);
  const scored = sentences.map((s, i) => {
    const ws = s.toLowerCase().match(/[a-z\u0980-\u09ff\u0600-\u06ff]{4,}/g) ?? [];
    const sc = ws.reduce((a, w) => a + (freq.get(w) ?? 0), 0) / Math.sqrt(ws.length + 1) + (i === 0 ? 2 : 0);
    return { s, i, sc };
  });
  const picked = scored.sort((a, b) => b.sc - a.sc).slice(0, 3).sort((a, b) => a.i - b.i).map((x) => x.s.slice(0, 320));
  const cls = classify(text.slice(0, 400), text);
  const geo = findGeo(text).slice(0, 4);
  const tr = lang === "en" ? new Map<string, string>() : await translateMany(picked, lang);
  return NextResponse.json({
    category: cls.category,
    level: cls.level,
    geo,
    sentences: picked.map((s) => tr.get(s) ?? s),
    originalLength: text.length,
  });
}
