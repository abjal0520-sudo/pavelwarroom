import { NextResponse } from "next/server";
import { getAircraft, getCableAlerts, getCables, getCyber, getSatellites, getSocial, getThermal, getTimeline, getWeather } from "@/lib/server/osint";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";
export const maxDuration = 60;

export async function GET(req: Request, ctx: { params: Promise<{ kind: string }> }) {
  const { kind } = await ctx.params;
  const lang = new URL(req.url).searchParams.get("lang") ?? "bn";
  try {
    let data: unknown;
    switch (kind) {
      case "aircraft":
        data = await getAircraft();
        break;
      case "satellites":
        data = await getSatellites();
        break;
      case "cables":
        data = await getCables();
        break;
      case "cablealerts":
        data = await getCableAlerts();
        break;
      case "thermal":
        data = await getThermal();
        break;
      case "weather":
        data = await getWeather();
        break;
      case "cyber":
        data = await getCyber();
        break;
      case "social":
        data = await getSocial(lang);
        break;
      case "timeline":
        data = await getTimeline();
        break;
      default:
        return NextResponse.json({ error: "unknown feed" }, { status: 404 });
    }
    return NextResponse.json(data, { headers: { "Cache-Control": "no-store" } });
  } catch (e) {
    return NextResponse.json({ error: String((e as Error).message) }, { status: 502 });
  }
}
