import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "PAVEL WAR ROOM — গ্লোবাল থ্রেট ইন্টেলিজেন্স সিস্টেম",
  description:
    "রিয়েল-টাইম যুদ্ধ পরিস্থিতি, সাইবার হুমকি, সামরিক বিশ্লেষণ এবং বৈশ্বিক নিরাপত্তা পর্যবেক্ষণ।",
};

export const viewport: Viewport = {
  themeColor: "#03060c",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="bn" data-vision="std" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link
          rel="stylesheet"
          href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@300;400;500;600;700&family=Noto+Sans+Bengali:wght@400;500;600;700&family=Noto+Sans+Arabic:wght@400;500;700&family=Inter:wght@400;500;600;700&family=Orbitron:wght@500;700;900&family=JetBrains+Mono:wght@400;500;700&family=Share+Tech+Mono&display=swap"
        />
      </head>
      <body suppressHydrationWarning>
        {children}
        <div id="vision-overlay" aria-hidden />
      </body>
    </html>
  );
}
