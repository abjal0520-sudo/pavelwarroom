"use client";
import dynamic from "next/dynamic";
import { useEffect, useState } from "react";
import { initVision } from "@/lib/commands";
import { LangProvider, useLang } from "@/lib/i18n";
import { startIntel } from "@/lib/intelStore";
import { setBooted, setLabelLang } from "@/lib/mapController";
import { LazyMount } from "./hud";
import Hero from "./Hero";
import LoadingScreen from "./LoadingScreen";
import MobileNav from "./MobileNav";
import NewsSection from "./NewsSection";
import TacticalMap from "./TacticalMap";
import TopBar from "./TopBar";

const Dashboard = dynamic(() => import("./Dashboard"), { ssr: false });
const Analysis = dynamic(() => import("./Analysis"), { ssr: false });
const ThreatSection = dynamic(() => import("./ThreatSection"), { ssr: false });
const WarGame = dynamic(() => import("./WarGame"), { ssr: false });
const Tracking = dynamic(() => import("./Tracking"), { ssr: false });
const CyberCenter = dynamic(() => import("./CyberCenter"), { ssr: false });
const WeatherPanel = dynamic(() => import("./WeatherPanel"), { ssr: false });
const Timeline = dynamic(() => import("./Timeline"), { ssr: false });
const Social = dynamic(() => import("./Social"), { ssr: false });
const CommandTerminal = dynamic(() => import("./CommandTerminal"), { ssr: false });
const VoiceCommand = dynamic(() => import("./VoiceCommand"), { ssr: false });
const AlertToast = dynamic(() => import("./AlertToast"), { ssr: false });

function Inner() {
  const { lang, L } = useLang();
  const [phase, setPhase] = useState<"boot" | "ready">("boot");

  useEffect(() => {
    initVision();
  }, []);
  useEffect(() => {
    startIntel(lang);
    setLabelLang(lang);
  }, [lang]);
  useEffect(() => {
    document.body.style.overflow = phase === "boot" ? "hidden" : "";
  }, [phase]);

  return (
    <>
      <TopBar />
      <main className="pb-16 md:pb-0">
        <Hero />
        <NewsSection />
        <TacticalMap />
        <LazyMount id="dashboard" minH={520}>
          <Dashboard />
        </LazyMount>
        <LazyMount id="analysis" minH={520}>
          <Analysis />
        </LazyMount>
        <LazyMount id="threat" minH={520}>
          <ThreatSection />
        </LazyMount>
        <LazyMount id="wargame" minH={560}>
          <WarGame />
        </LazyMount>
        <LazyMount id="naval" minH={520}>
          <Tracking />
        </LazyMount>
        <LazyMount id="cyber" minH={520}>
          <CyberCenter />
        </LazyMount>
        <LazyMount id="weather" minH={420}>
          <WeatherPanel />
        </LazyMount>
        <LazyMount id="timeline" minH={520}>
          <Timeline />
        </LazyMount>
        <LazyMount id="social" minH={420}>
          <Social />
        </LazyMount>
        <LazyMount id="terminal" minH={420}>
          <CommandTerminal />
        </LazyMount>
        <footer className="border-t border-cyan-500/20 bg-black/40 px-4 py-8 text-center text-xs text-slate-500">
          <div className="font-display tracking-[0.3em] text-slate-300">PAVEL WAR ROOM</div>
          <p className="mx-auto mt-2 max-w-3xl leading-relaxed">
            {L(
              "এই প্ল্যাটফর্ম প্রকাশ্য সংবাদ ও ওপেন ডেটাসেট ব্যবহার করে। Reuters/AP-এর লিংক Google News RSS index থেকে পাওয়া যায়, সরাসরি তাদের licensed API থেকে নয়। ঝুঁকি সূচকগুলো রিপোর্টভিত্তিক অ্যালগরিদমিক অনুমান, অফিসিয়াল সামরিক মূল্যায়ন নয়।",
              "This platform aggregates public reporting and open datasets. Reuters/AP links are discovered through the Google News RSS index, not their licensed APIs. Risk indicators are report-based algorithmic estimates, not official military assessments.",
              "تعتمد المنصة على بيانات مفتوحة المصدر فقط. المؤشرات التحليلية تقديرات خوارزمية وليست تقييمات عسكرية رسمية.",
            )}
          </p>
        </footer>
      </main>
      <MobileNav />
      {phase === "ready" && (
        <>
          <VoiceCommand />
          <AlertToast />
        </>
      )}
      {phase === "boot" && (
        <LoadingScreen
          onEnter={() => {
            setPhase("ready");
            setBooted(true);
          }}
        />
      )}
    </>
  );
}

export default function AppShell() {
  return (
    <LangProvider>
      <Inner />
    </LangProvider>
  );
}
