"use client";
import { useRef, useState } from "react";
import { sfx } from "@/lib/audio";
import { runCommand } from "@/lib/commands";
import { useLang } from "@/lib/i18n";
import { useIntel } from "@/lib/intelStore";
import { useOsint } from "@/lib/osintStore";
import { Hud, Section, useInView } from "./hud";
import { TypedLines } from "./Typed";

export default function CommandTerminal() {
  const { L, lang, setLang } = useLang();
  const intel = useIntel();
  const [ref, vis] = useInView<HTMLDivElement>("0px");
  const sats = useOsint<{ sats: unknown[] }>("satellites", 3600000, { enabled: vis });
  const [history, setHistory] = useState<{ cmd: string; out: string; ok: boolean }[]>([]);
  const [val, setVal] = useState("");
  const box = useRef<HTMLDivElement>(null);

  const lines = [
    `> ${sats.data ? L(`স্যাটেলাইট সংযোগ স্থাপন করা হয়েছে (${sats.data.sats.length}টি সামরিক/রিকন অবজেক্ট, CelesTrak)`, `Satellite link established (${sats.data.sats.length} military/recon objects, CelesTrak)`, "تم الاتصال بالأقمار") : L("স্যাটেলাইট TLE সংযোগ স্থাপন হচ্ছে…", "Establishing satellite TLE link…", "جارٍ الاتصال")}`,
    `> ${L(`ক্ষেপণাস্ত্র গতিবিধি পর্যবেক্ষণ চলছে (${intel?.missiles.length ?? 0}টি সংবাদ-সূত্র)`, `Missile movement monitoring in progress (${intel?.missiles.length ?? 0} news-linked tracks)`, "مراقبة الصواريخ")}`,
    `> ${intel ? L(`বৈশ্বিক হুমকি বিশ্লেষণ সম্পন্ন — GTI ${intel.stats.gti}/100`, `Global threat analysis complete — GTI ${intel.stats.gti}/100`, "اكتمل التحليل") : L("বৈশ্বিক হুমকি বিশ্লেষণ চলছে…", "Global threat analysis running…", "التحليل جارٍ")}`,
    `> ${L("সাইবার প্রতিরক্ষা সক্রিয়", "Cyber defense active", "الدفاع السيبراني نشط")}`,
    `> ${L("কমান্ড লিখুন বা “help” টাইপ করুন", "Type a command or “help”", "اكتب أمراً")}`,
  ];

  const submit = (text: string) => {
    if (!text.trim()) return;
    const r = runCommand(text, { setLang, lang });
    setHistory((h) => [...h.slice(-30), { cmd: text, out: r.message, ok: r.ok }]);
    setVal("");
    setTimeout(() => box.current?.scrollTo({ top: box.current.scrollHeight }), 30);
  };

  const quick: [string, string][] = [
    ["help", "সাহায্য"],
    ["রাশিয়ার তথ্য দেখাও", "show Russia"],
    ["সাইবার হুমকি চালু করো", "cyber threats on"],
    ["স্যাটেলাইট মোড চালু করো", "satellite mode on"],
    ["নাইট ভিশন", "night vision"],
    ["অডিও বন্ধ", "mute"],
  ];

  return (
    <Section id="terminal" tag="◢ COMMAND-TERMINAL // 22" title={L("কমান্ড টার্মিনাল", "Command Terminal", "طرفية القيادة")} subtitle={L("বাংলা বা ইংরেজি কমান্ড লিখুন — ইন্টারফেস সঙ্গে সঙ্গে সাড়া দেবে। (ভয়েস কমান্ডও একই ইঞ্জিন ব্যবহার করে।)", "Type Bangla or English commands — the interface reacts instantly. (Voice commands use the same engine.)", "اكتب الأوامر")}>
      <div ref={ref}>
        <Hud title="PAVEL-WAR-ROOM // TTY1" right={<span className="mono text-[10px] text-emerald-400">● SECURE</span>} pad={false}>
          <div ref={box} className="max-h-[380px] min-h-[260px] overflow-y-auto bg-black/70 p-3 sm:p-4">
            <TypedLines lines={lines} speed={16} sound />
            {history.map((h, i) => (
              <div key={i} className="mono a-new mt-2 text-[12.5px]">
                <div className="text-cyan-300">$ {h.cmd}</div>
                <div className={h.ok ? "text-emerald-300" : "text-red-300"}>&gt; {h.out}</div>
              </div>
            ))}
          </div>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              submit(val);
            }}
            className="flex items-center gap-2 border-t border-cyan-500/20 bg-black/80 px-3 py-2"
          >
            <span className="mono text-emerald-400">$</span>
            <input value={val} onChange={(e) => { setVal(e.target.value); sfx.type(); }} placeholder={L("কমান্ড লিখুন…", "enter command…", "أدخل أمراً…")} className="mono flex-1 bg-transparent text-[13px] text-slate-100 outline-none placeholder:text-slate-600" autoComplete="off" spellCheck={false} />
            <button type="submit" className="border border-cyan-400/50 px-3 py-1 text-[12px] text-cyan-100 hover:bg-cyan-400/10">{L("চালান", "RUN", "تشغيل")}</button>
          </form>
        </Hud>
        <div className="mt-3 flex flex-wrap gap-1.5">
          {quick.map(([bn, en]) => (
            <button key={bn} onClick={() => submit(lang === "bn" ? bn : en)} className="border border-cyan-500/25 px-2.5 py-1 text-[12px] text-slate-300 hover:border-cyan-300 hover:text-white">
              {lang === "bn" ? bn : en}
            </button>
          ))}
        </div>
      </div>
    </Section>
  );
}
