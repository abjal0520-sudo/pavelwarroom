"use client";
import { useEffect, useRef, useState } from "react";
import { sfx } from "@/lib/audio";
import { runCommand } from "@/lib/commands";
import { useLang } from "@/lib/i18n";

interface SRResult {
  0: { transcript: string };
  isFinal: boolean;
}
interface SREvent {
  results: ArrayLike<SRResult>;
}
interface SR {
  lang: string;
  interimResults: boolean;
  continuous: boolean;
  start: () => void;
  stop: () => void;
  onresult: ((e: SREvent) => void) | null;
  onend: (() => void) | null;
  onerror: (() => void) | null;
}

const LANG_CODE = { bn: "bn-BD", en: "en-US", ar: "ar-SA" } as const;

/** Floating AI voice-command interface (Web Speech API) with typed fallback. */
export default function VoiceCommand() {
  const { L, lang, setLang } = useLang();
  const [open, setOpen] = useState(false);
  const [listening, setListening] = useState(false);
  const [heard, setHeard] = useState("");
  const [reply, setReply] = useState<{ ok: boolean; message: string } | null>(null);
  const [val, setVal] = useState("");
  const [supported, setSupported] = useState(true);
  const rec = useRef<SR | null>(null);

  useEffect(() => {
    const w = window as unknown as { SpeechRecognition?: new () => SR; webkitSpeechRecognition?: new () => SR };
    setSupported(!!(w.SpeechRecognition || w.webkitSpeechRecognition));
    return () => rec.current?.stop();
  }, []);

  const exec = (t: string) => {
    setHeard(t);
    setReply(runCommand(t, { setLang, lang }));
  };

  const start = () => {
    const w = window as unknown as { SpeechRecognition?: new () => SR; webkitSpeechRecognition?: new () => SR };
    const C = w.SpeechRecognition || w.webkitSpeechRecognition;
    if (!C) return;
    sfx.holo();
    const r = new C();
    r.lang = LANG_CODE[lang];
    r.interimResults = true;
    r.continuous = false;
    r.onresult = (e) => {
      const res = e.results[e.results.length - 1];
      const t = res[0].transcript;
      setHeard(t);
      if (res.isFinal) exec(t);
    };
    r.onend = () => setListening(false);
    r.onerror = () => setListening(false);
    rec.current = r;
    setListening(true);
    setHeard("");
    setReply(null);
    r.start();
  };
  const stop = () => {
    rec.current?.stop();
    setListening(false);
  };

  return (
    <div className="fixed bottom-20 right-3 z-[60] md:bottom-5 md:right-5">
      {open && (
        <div className="hud a-in mb-2 w-[min(340px,calc(100vw-1.5rem))] bg-[#060a12] p-3">
          <i className="hud-br tl" />
          <i className="hud-br tr" />
          <i className="hud-br bl" />
          <i className="hud-br brr" />
          <div className="mb-2 flex items-center justify-between">
            <span className="hud-title">{L("এআই ভয়েস কমান্ড", "AI VOICE COMMAND", "الأوامر الصوتية")}</span>
            <button onClick={() => setOpen(false)} className="text-slate-400 hover:text-white">✕</button>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={listening ? stop : start}
              disabled={!supported}
              className={`relative flex h-14 w-14 shrink-0 items-center justify-center border-2 text-xl ${listening ? "border-red-400 bg-red-500/20 text-red-200" : "border-cyan-300 bg-cyan-400/10 text-cyan-100"} disabled:opacity-40`}
              aria-label="microphone"
            >
              {listening && <span className="a-ring absolute inset-0 border border-red-400" />}
              🎙
            </button>
            <div className="min-h-[56px] flex-1">
              {listening ? (
                <div className="flex h-8 items-end gap-0.5">
                  {Array.from({ length: 16 }, (_, i) => (
                    <span key={i} className="a-glow w-1 bg-cyan-300" style={{ height: `${25 + ((i * 37) % 70)}%`, animationDelay: `${i * 0.08}s` }} />
                  ))}
                </div>
              ) : (
                <p className="text-[12px] text-slate-400">{supported ? L("মাইক চেপে বলুন…", "Tap the mic and speak…", "اضغط وتحدث") : L("এই ব্রাউজারে ভয়েস সাপোর্ট নেই—নিচে লিখুন।", "Voice not supported in this browser — type below.", "الصوت غير مدعوم")}</p>
              )}
              {heard && <p className="mono mt-1 text-[12px] text-cyan-200" dir="auto">“{heard}”</p>}
            </div>
          </div>
          {reply && <div className={`a-in mt-2 border-l-2 px-2 py-1 text-[13px] ${reply.ok ? "border-emerald-400 text-emerald-200" : "border-red-400 text-red-200"}`}>{reply.message}</div>}
          <form onSubmit={(e) => { e.preventDefault(); exec(val); setVal(""); }} className="mt-2 flex gap-1">
            <input value={val} onChange={(e) => setVal(e.target.value)} placeholder={L("অথবা কমান্ড লিখুন…", "or type a command…", "أو اكتب…")} className="min-w-0 flex-1 border border-cyan-500/25 bg-black/50 px-2 py-1.5 text-[13px] text-slate-100 outline-none focus:border-cyan-300" />
            <button className="border border-cyan-400/50 px-2 text-[12px] text-cyan-100">▶</button>
          </form>
          <div className="mt-2 space-y-1 text-[11px] text-slate-500">
            <div>“রাশিয়ার তথ্য দেখাও”</div>
            <div>“সাইবার হুমকি চালু করো”</div>
            <div>“স্যাটেলাইট মোড চালু করো”</div>
          </div>
        </div>
      )}
      <button
        onClick={() => {
          sfx.holo();
          setOpen((o) => !o);
        }}
        className={`ml-auto flex h-12 items-center gap-2 border bg-[#060a12]/95 px-3 text-sm text-cyan-100 ${listening ? "border-red-400" : "border-cyan-300/70"}`}
      >
        <span className={listening ? "a-alert text-red-300" : ""}>🎙</span>
        <span className="hidden sm:inline">{L("ভয়েস কমান্ড", "Voice", "صوت")}</span>
      </button>
    </div>
  );
}
