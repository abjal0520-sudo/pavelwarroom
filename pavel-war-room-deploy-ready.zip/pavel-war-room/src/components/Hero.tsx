"use client";
import { memo, useEffect, useRef } from "react";
import { sfx } from "@/lib/audio";
import { scrollToId } from "@/lib/commands";
import { useLang } from "@/lib/i18n";
import { setLayer } from "@/lib/layers";
import { subscribeView } from "@/lib/mapController";
import { useInView } from "./hud";
import MapSlot from "./MapSlot";

const PARTICLES = Array.from({ length: 18 }, (_, i) => ({
  left: `${(i * 53) % 100}%`,
  dur: `${9 + ((i * 7) % 10)}s`,
  delay: `-${(i * 3) % 12}s`,
  size: i % 4 === 0 ? 3 : 2,
}));

/** Coordinates ticker — written directly to the DOM (no React re-renders). */
export const CoordTicker = memo(function CoordTicker() {
  const ref = useRef<HTMLSpanElement>(null);
  useEffect(
    () =>
      subscribeView((v) => {
        if (!ref.current) return;
        const la = v.lat >= 0 ? "N" : "S";
        const lo = v.lng >= 0 ? "E" : "W";
        ref.current.textContent = `${Math.abs(v.lat).toFixed(3).padStart(7, "0")}°${la}  ${Math.abs(v.lng).toFixed(3).padStart(8, "0")}°${lo}  Z${v.zoom.toFixed(2)}`;
      }),
    [],
  );
  return <span ref={ref} className="mono">000.000°N  0000.000°E  Z0.00</span>;
});

export default function Hero() {
  const { L } = useLang();
  const [ref, vis] = useInView<HTMLElement>("0px");
  const go = (id: string) => {
    sfx.click();
    scrollToId(id);
  };
  return (
    <section id="hero" ref={ref} className={`relative flex h-[100svh] min-h-[620px] w-full items-center justify-center overflow-hidden ${vis ? "" : "is-off"}`}>
      <MapSlot mode="hero" />
      <div className="vignette pointer-events-none absolute inset-0" />
      <div className="hud-grid pointer-events-none absolute inset-0 opacity-40" />
      <div className="scanlines pointer-events-none absolute inset-0" />
      <div className="a-scan pointer-events-none absolute inset-x-0 top-0 h-1/3 bg-gradient-to-b from-transparent via-cyan-300/10 to-transparent" />

      {/* radar pulse rings */}
      <div className="pointer-events-none absolute left-1/2 top-1/2 h-[90vmin] w-[90vmin] -translate-x-1/2 -translate-y-1/2">
        {[0, 1, 2].map((i) => (
          <div key={i} className="a-ring absolute inset-0 rounded-full border border-cyan-300/50" style={{ animationDelay: `${i * 1.07}s` }} />
        ))}
      </div>

      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        {PARTICLES.map((p, i) => (
          <span key={i} className="particle" style={{ left: p.left, animationDuration: p.dur, animationDelay: p.delay, width: p.size, height: p.size }} />
        ))}
      </div>

      {/* cinematic camera drift */}
      <div className="a-drift relative z-10 mx-auto flex max-w-5xl flex-col items-center px-4 pt-28 text-center sm:pt-24">
        <div className="hud-title mb-3 a-flicker !text-[11px]">◢ {L("শ্রেণিবদ্ধ নয় · ওপেন-সোর্স ইন্টেলিজেন্স", "UNCLASSIFIED · OPEN-SOURCE INTELLIGENCE", "استخبارات مفتوحة المصدر")} ◣</div>
        <h1 className="a-flicker font-display text-[clamp(2rem,8vw,6rem)] font-black leading-none tracking-[0.12em] text-white [text-shadow:0_0_30px_rgba(34,211,238,0.55)]">
          PAVEL <span className="text-cyan-300">WAR ROOM</span>
        </h1>
        <h2 className="mt-4 text-[clamp(1.1rem,3.4vw,2rem)] font-semibold text-cyan-100">{L("গ্লোবাল থ্রেট ইন্টেলিজেন্স সিস্টেম", "Global Threat Intelligence System", "نظام استخبارات التهديدات العالمي")}</h2>
        <p className="mt-3 max-w-2xl text-sm leading-relaxed text-slate-300 sm:text-base">
          {L(
            "রিয়েল-টাইম যুদ্ধ পরিস্থিতি, সাইবার হুমকি, সামরিক বিশ্লেষণ এবং বৈশ্বিক নিরাপত্তা পর্যবেক্ষণ।",
            "Real-time conflict picture, cyber threats, military analysis and global security monitoring.",
            "وضع النزاعات في الوقت الحقيقي والتهديدات السيبرانية والتحليل العسكري ومراقبة الأمن العالمي.",
          )}
        </p>
        <div className="mt-8 flex w-full flex-col gap-3 sm:w-auto sm:flex-row">
          <button onClick={() => go("news")} className="group relative border border-cyan-300 bg-cyan-400/15 px-6 py-3 text-sm font-semibold text-white transition hover:bg-cyan-400/30">
            <span className="mono mr-2 text-cyan-300">▸</span>
            {L("কমান্ড সেন্টার খুলুন", "Open Command Center", "افتح مركز القيادة")}
          </button>
          <button onClick={() => go("map")} className="border border-emerald-400/60 bg-emerald-500/10 px-6 py-3 text-sm font-semibold text-emerald-100 transition hover:bg-emerald-400/25">
            <span className="mono mr-2 text-emerald-300">◉</span>
            {L("লাইভ ম্যাপ দেখুন", "View Live Map", "عرض الخريطة المباشرة")}
          </button>
          <button
            onClick={() => {
              sfx.holo();
              setLayer("spysat", true);
              setLayer("satmode", true);
              scrollToId("map");
            }}
            className="border border-orange-400/60 bg-orange-500/10 px-6 py-3 text-sm font-semibold text-orange-100 transition hover:bg-orange-400/25"
          >
            <span className="mono mr-2 text-orange-300">⌖</span>
            {L("স্যাটেলাইট মোড চালু করুন", "Activate Satellite Mode", "تفعيل وضع الأقمار الصناعية")}
          </button>
        </div>
      </div>

      <div className="pointer-events-none absolute inset-x-0 bottom-16 z-10 flex items-end justify-between px-4 text-[11px] text-cyan-200/80 sm:bottom-6 sm:px-8">
        <div className="space-y-0.5">
          <div className="hud-title">{L("গ্লোবাল ভিউ", "GLOBAL VIEW", "عرض عالمي")}</div>
          <CoordTicker />
        </div>
        <div className="hidden text-right sm:block">
          <div className="hud-title">{L("তথ্যসূত্র", "FEEDS", "المصادر")}</div>
          <div className="mono">BBC RSS · AL JAZEERA · GOOGLE NEWS INDEX · GDELT · OPENSKY · CELESTRAK</div>
        </div>
      </div>
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-[#03060c] to-transparent" />
    </section>
  );
}
