"use client";
import { memo } from "react";
import { sfx } from "@/lib/audio";
import { scrollToId } from "@/lib/commands";
import { useLang } from "@/lib/i18n";
import { useIntel } from "@/lib/intelStore";
import { flyTo } from "@/lib/mapController";
import { LEVELS, LEVEL_COLOR, LEVEL_LABEL, type ThreatLevel } from "@/lib/types";
import { AnimNum, Ago, Empty, Hud, Section, useInView } from "./hud";

const scoreLevel = (s: number): ThreatLevel => (s < 20 ? "LOW" : s < 40 ? "GUARDED" : s < 60 ? "ELEVATED" : s < 80 ? "HIGH" : "CRITICAL");

const Scores = memo(function Scores() {
  const { L, lang } = useLang();
  const intel = useIntel();
  const list = intel?.countries ?? [];
  if (!intel) return <Empty>{L("স্কোর গণনা চলছে…", "Computing scores…", "جارٍ الحساب")}</Empty>;
  if (!list.length) return <Empty>{L("বর্তমানে কোনো দেশ চিহ্নিত হয়নি।", "No countries flagged currently.", "لا دول")}</Empty>;
  return (
    <div className="space-y-2">
      {list.map((c, i) => {
        const lv = scoreLevel(c.score);
        const col = LEVEL_COLOR[lv];
        return (
          <button
            key={c.key}
            onClick={() => {
              sfx.lock();
              flyTo(c.lat, c.lng, 3.8);
              scrollToId("map");
            }}
            className={`relative block w-full border border-cyan-500/15 bg-[#060a12]/90 text-left transition-colors hover:border-cyan-400/50 ${i < 3 ? "px-3 py-3" : "px-3 py-2"}`}
          >
            <div className="flex items-center gap-3">
              <span className="mono w-6 text-[11px] text-slate-500">{String(i + 1).padStart(2, "0")}</span>
              <span className={`min-w-0 flex-1 truncate font-semibold text-white ${i < 3 ? "text-base" : "text-sm"}`}>
                {lang === "bn" ? c.bn : c.en}
                <span className="mono ml-2 text-[10px] font-normal text-slate-500">{c.count} rpt</span>
              </span>
              <span className="mono text-[11px]" style={{ color: c.delta > 0 ? "#ef4444" : c.delta < 0 ? "#4ade80" : "#64748b" }}>{c.delta > 0 ? `▲${c.delta}` : c.delta < 0 ? `▼${-c.delta}` : "—"}</span>
              <AnimNum value={c.score} className="w-9 text-right text-xl font-bold" />
            </div>
            <div className="mt-2 h-1.5 w-full bg-white/5">
              <div className="h-full w-full origin-left transition-transform duration-1000 ease-out" style={{ transform: `scaleX(${c.score / 100})`, background: `linear-gradient(90deg, ${col}44, ${col})`, willChange: "transform" }} />
            </div>
          </button>
        );
      })}
    </div>
  );
});

const Nuclear = memo(function Nuclear() {
  const { L, lang } = useLang();
  const intel = useIntel();
  const [ref, vis] = useInView<HTMLDivElement>("0px");
  const level = intel?.stats.nuclearLevel ?? "LOW";
  const idx = intel?.stats.nuclearIndex ?? 0;
  const col = LEVEL_COLOR[level];
  const hot = level === "HIGH" || level === "CRITICAL";
  const angle = -90 + (Math.max(0, Math.min(100, idx)) / 100) * 180;
  const nukeNews = intel?.items.filter((i) => i.category === "nuclear").slice(0, 3) ?? [];
  const seg = (i: number) => {
    const a0 = Math.PI + (i / 5) * Math.PI + 0.02;
    const a1 = Math.PI + ((i + 1) / 5) * Math.PI - 0.02;
    const r1 = 100,
      r0 = 74;
    const p = (a: number, r: number) => `${(130 + r * Math.cos(a)).toFixed(1)},${(130 + r * Math.sin(a)).toFixed(1)}`;
    return `M${p(a0, r1)} A${r1},${r1} 0 0 1 ${p(a1, r1)} L${p(a1, r0)} A${r0},${r0} 0 0 0 ${p(a0, r0)} Z`;
  };
  return (
    <Hud accent={col} title={L("পারমাণবিক ঝুঁকি মিটার (DEFCON-স্টাইল)", "NUCLEAR RISK METER (DEFCON-STYLE)", "مقياس الخطر النووي")} className="h-full">
      <div ref={ref} className={`relative mx-auto flex max-w-[420px] flex-col items-center ${vis ? "" : "is-off"}`}>
        {hot && <div className="a-glow pointer-events-none absolute left-1/2 top-[40%] h-72 w-72 -translate-x-1/2 -translate-y-1/2 rounded-full" style={{ background: `radial-gradient(circle, ${col}55, transparent 68%)` }} />}
        <div className="relative h-[250px] w-[280px]">
          <div className="a-sweep-slow absolute left-1/2 top-[130px] h-[250px] w-[250px] -translate-x-1/2 -translate-y-1/2 rounded-full border border-dashed" style={{ borderColor: `${col}66` }} />
          <div className="a-spin-rev absolute left-1/2 top-[130px] h-[210px] w-[210px] -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-dotted" style={{ borderColor: `${col}44` }} />
          <svg viewBox="0 0 260 150" className="absolute left-1/2 top-[10px] w-[260px] -translate-x-1/2">
            {LEVELS.map((l, i) => (
              <path key={l} d={seg(i)} fill={LEVEL_COLOR[l]} opacity={LEVELS.indexOf(level) === i ? 1 : 0.25} />
            ))}
            <g style={{ transform: `rotate(${angle}deg)`, transformOrigin: "130px 130px", transition: "transform 1.4s cubic-bezier(.2,.9,.2,1)" }}>
              <polygon points="130,36 125,130 135,130" fill="#fff" />
            </g>
            <circle cx="130" cy="130" r="9" fill="#060a12" stroke={col} strokeWidth="2" />
          </svg>
          <div className="absolute inset-x-0 top-[132px] text-center">
            <div className={`font-display text-3xl font-black ${hot ? "a-alert" : ""}`} style={{ color: col }}>{level}</div>
            <div className="text-sm font-semibold text-white">{LEVEL_LABEL[level][lang]}</div>
            <div className="mono text-[11px] text-slate-400">INDEX <AnimNum value={idx} className="text-slate-200" />/100</div>
          </div>
        </div>
        <div className="mt-2 grid w-full grid-cols-5 gap-1">
          {LEVELS.map((l) => (
            <div key={l} className="border px-1 py-1 text-center" style={{ borderColor: l === level ? LEVEL_COLOR[l] : "#16303d", background: l === level ? `${LEVEL_COLOR[l]}22` : "transparent" }}>
              <div className="mono text-[9px]" style={{ color: LEVEL_COLOR[l] }}>{l}</div>
              <div className="text-[10px] text-slate-300">{LEVEL_LABEL[l][lang]}</div>
            </div>
          ))}
        </div>
        <div className="mt-3 w-full">
          <div className="hud-title mb-1">{L("সংশ্লিষ্ট প্রতিবেদন", "RELATED REPORTS", "تقارير ذات صلة")}</div>
          {nukeNews.length === 0 ? <p className="text-xs text-slate-500">{L("বর্তমানে কোনো পারমাণবিক-সংশ্লিষ্ট প্রতিবেদন নেই।", "No nuclear-related reports now.", "لا تقارير")}</p> : (
            <ul className="space-y-1.5">
              {nukeNews.map((n) => (
                <li key={n.id} className="text-[12px] leading-snug text-slate-300">
                  <a href={n.url} target="_blank" rel="noreferrer" className="hover:text-white" dir="auto">▸ {n.titleT}</a>
                  <span className="mono text-[10px] text-slate-500"> · {n.source} · </span><span className="text-[10px] text-slate-500"><Ago iso={n.publishedAt} /></span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </Hud>
  );
});

export default function ThreatSection() {
  const { L } = useLang();
  return (
    <Section id="threat" tag="◢ THREAT-RANK // 11 · 12" title={L("থ্রেট স্কোর ও পারমাণবিক ঝুঁকি", "Threat Scores & Nuclear Risk", "درجات التهديد والخطر النووي")} subtitle={L("দেশভিত্তিক স্কোর = সাম্প্রতিক প্রতিবেদনের তীব্রতা × সময়-ক্ষয়। যেকোনো দেশে ক্লিক করে ম্যাপে যান।", "Country score = recent report severity × time-decay. Click a country to fly there.", "اضغط على دولة للانتقال إليها.")}>
      <div className="grid gap-4 lg:grid-cols-[minmax(0,1.2fr)_minmax(0,1fr)]">
        <Hud title={L("গ্লোবাল থ্রেট র‍্যাঙ্কিং", "GLOBAL THREAT RANKING", "ترتيب التهديد")} right={<span className="mono text-[10px] text-cyan-400">LIVE</span>}>
          <Scores />
        </Hud>
        <Nuclear />
      </div>
    </Section>
  );
}
