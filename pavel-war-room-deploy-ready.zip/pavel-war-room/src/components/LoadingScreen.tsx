"use client";
import { useEffect, useRef, useState } from "react";
import { sfx, unlockAudio } from "@/lib/audio";

const LINES = [
  "INITIALIZING GLOBAL NETWORK...",
  "CONNECTING SATELLITE GRID...",
  "LOADING INTELLIGENCE DATABASE...",
  "THREAT ANALYSIS ONLINE...",
  "PAVEL WAR ROOM ACTIVE",
];
const BN = ["গ্লোবাল নেটওয়ার্ক চালু হচ্ছে", "স্যাটেলাইট গ্রিড সংযুক্ত হচ্ছে", "গোয়েন্দা ডেটাবেস লোড হচ্ছে", "হুমকি বিশ্লেষণ অনলাইন", "পাভেল ওয়ার রুম সক্রিয়"];

type Seg = [number, number][];

/** Cinematic boot sequence. 2D-canvas orthographic globe — no WebGL context is created here. */
export default function LoadingScreen({ onEnter }: { onEnter: () => void }) {
  const cv = useRef<HTMLCanvasElement>(null);
  const code = useRef<HTMLPreElement>(null);
  const bar = useRef<HTMLDivElement>(null);
  const pct = useRef<HTMLSpanElement>(null);
  const [step, setStep] = useState(0);
  const [done, setDone] = useState(false);
  const [leaving, setLeaving] = useState(false);

  // globe
  useEffect(() => {
    const c = cv.current;
    if (!c) return;
    const ctx = c.getContext("2d");
    if (!ctx) return;
    let raf = 0;
    let alive = true;
    let segs: Seg[] = [];
    const size = Math.min(window.innerWidth * 0.8, window.innerHeight * 0.52, 520);
    const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
    c.width = c.height = size * dpr;
    c.style.width = c.style.height = `${size}px`;
    (async () => {
      const [topo, world] = await Promise.all([import("topojson-client"), import("world-atlas/countries-110m.json")]);
      const t = (world.default ?? world) as unknown as Parameters<typeof topo.mesh>[0];
      const objs = (t as unknown as { objects: { countries: Parameters<typeof topo.mesh>[1] } }).objects;
      const m = topo.mesh(t, objs.countries);
      segs = m.coordinates as unknown as Seg[];
    })();
    let lam0 = 1.2;
    let last = performance.now();
    const R = size / 2 - 6;
    const draw = (now: number) => {
      raf = requestAnimationFrame(draw);
      if (now - last < 33) return;
      lam0 += ((now - last) / 1000) * 0.45;
      last = now;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, size, size);
      const cxp = size / 2;
      const phi0 = 0.38;
      const g = ctx.createRadialGradient(cxp, cxp, R * 0.2, cxp, cxp, R * 1.08);
      g.addColorStop(0, "rgba(8,40,60,0.55)");
      g.addColorStop(0.9, "rgba(8,60,90,0.35)");
      g.addColorStop(1, "rgba(34,211,238,0.45)");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(cxp, cxp, R, 0, 7);
      ctx.fill();
      ctx.strokeStyle = "rgba(34,211,238,0.9)";
      ctx.lineWidth = 1.5;
      ctx.stroke();
      const pr = (lon: number, lat: number): [number, number, boolean] => {
        const l = (lon * Math.PI) / 180 - lam0;
        const p = (lat * Math.PI) / 180;
        const cosc = Math.sin(phi0) * Math.sin(p) + Math.cos(phi0) * Math.cos(p) * Math.cos(l);
        return [cxp + R * Math.cos(p) * Math.sin(l), cxp - R * (Math.cos(phi0) * Math.sin(p) - Math.sin(phi0) * Math.cos(p) * Math.cos(l)), cosc > 0];
      };
      // graticule
      ctx.strokeStyle = "rgba(34,211,238,0.14)";
      ctx.lineWidth = 0.7;
      for (let lat = -60; lat <= 60; lat += 30) {
        ctx.beginPath();
        let pen = false;
        for (let lon = -180; lon <= 180; lon += 6) {
          const [x, y, v] = pr(lon, lat);
          if (!v) pen = false;
          else if (!pen) (ctx.moveTo(x, y), (pen = true));
          else ctx.lineTo(x, y);
        }
        ctx.stroke();
      }
      for (let lon = -180; lon < 180; lon += 30) {
        ctx.beginPath();
        let pen = false;
        for (let lat = -90; lat <= 90; lat += 6) {
          const [x, y, v] = pr(lon, lat);
          if (!v) pen = false;
          else if (!pen) (ctx.moveTo(x, y), (pen = true));
          else ctx.lineTo(x, y);
        }
        ctx.stroke();
      }
      // borders
      ctx.strokeStyle = "rgba(103,232,249,0.85)";
      ctx.lineWidth = 0.8;
      ctx.beginPath();
      for (const s of segs) {
        let pen = false;
        for (const [lo, la] of s) {
          const [x, y, v] = pr(lo, la);
          if (!v) pen = false;
          else if (!pen) (ctx.moveTo(x, y), (pen = true));
          else ctx.lineTo(x, y);
        }
      }
      ctx.stroke();
    };
    raf = requestAnimationFrame(draw);
    return () => {
      alive = false;
      cancelAnimationFrame(raf);
      void alive;
    };
  }, []);

  // progress + terminal + encrypted code
  useEffect(() => {
    const t0 = performance.now();
    const total = 6200;
    let raf = 0;
    const hex = "0123456789ABCDEF▯▮░▒";
    const codeTimer = setInterval(() => {
      if (!code.current) return;
      let s = "";
      for (let r = 0; r < 14; r++) {
        for (let k = 0; k < 18; k++) s += hex[(Math.random() * hex.length) | 0] + (k % 2 ? " " : "");
        s += "\n";
      }
      code.current.textContent = s;
    }, 110);
    const stepTimers = LINES.map((_, i) => setTimeout(() => setStep(i + 1), (total / LINES.length) * i + 200));
    const loop = (t: number) => {
      const k = Math.min(1, (t - t0) / total);
      if (bar.current) bar.current.style.transform = `scaleX(${k})`;
      if (pct.current) pct.current.textContent = String(Math.round(k * 100)).padStart(3, "0");
      if (k < 1) raf = requestAnimationFrame(loop);
      else setDone(true);
    };
    raf = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(raf);
      clearInterval(codeTimer);
      stepTimers.forEach(clearTimeout);
    };
  }, []);

  const enter = (audio: boolean) => {
    if (audio) {
      unlockAudio();
      sfx.boot();
    } else {
      import("@/lib/audio").then((m) => m.setMuted(true));
    }
    setLeaving(true);
    setTimeout(onEnter, 650);
  };

  return (
    <div className={`fixed inset-0 z-[100] overflow-hidden bg-[#02050a] transition-opacity duration-700 ${leaving ? "opacity-0" : "opacity-100"}`}>
      <div className="hud-grid absolute inset-0 opacity-60" />
      <div className="scanlines absolute inset-0" />
      <div className="vignette absolute inset-0" />
      {/* radar sweep */}
      <div className="absolute left-1/2 top-[44%] h-[130vmax] w-[130vmax] -translate-x-1/2 -translate-y-1/2 opacity-[0.12]">
        <div className="a-sweep-slow h-full w-full rounded-full" style={{ background: "conic-gradient(from 0deg, rgba(34,211,238,0.9), rgba(34,211,238,0) 18%, transparent 100%)" }} />
      </div>
      <div className="a-scan absolute inset-x-0 top-0 h-1/3 bg-gradient-to-b from-transparent via-cyan-400/10 to-transparent" />

      <pre ref={code} className="mono absolute left-3 top-16 hidden text-[10px] leading-4 text-cyan-500/40 md:block" aria-hidden />
      <pre className="mono absolute right-3 top-16 hidden text-right text-[10px] leading-4 text-cyan-500/40 md:block" aria-hidden>
        {`SAT-GRID   ONLINE\nENCRYPTION AES-256\nUPLINK     ACTIVE\nGEO-INT    READY\nSIGINT     READY\nOSINT      READY`}
      </pre>

      <div className="relative z-10 flex h-full flex-col items-center justify-center gap-5 px-4">
        <div className="a-flicker font-display text-xs tracking-[0.5em] text-cyan-300/80">// CLASSIFIED — OSINT ONLY //</div>
        <div className="relative">
          <canvas ref={cv} className="relative z-10" />
          <div className="absolute -inset-4 rounded-full border border-cyan-400/20 a-sweep-slow" style={{ borderStyle: "dashed" }} />
          <div className="absolute -inset-8 rounded-full border border-cyan-400/10 a-spin-rev" style={{ borderStyle: "dotted" }} />
        </div>
        <h1 className="a-flicker font-display text-2xl font-black tracking-[0.25em] text-white sm:text-4xl">
          PAVEL <span className="text-cyan-300">WAR ROOM</span>
        </h1>

        <div className="w-full max-w-xl">
          <div className="mono mb-3 min-h-[116px] space-y-1 text-xs text-emerald-300 sm:text-sm">
            {LINES.slice(0, step).map((l, i) => (
              <div key={l} className="a-new flex items-center justify-between gap-3">
                <span>
                  <span className="text-cyan-500">&gt; </span>
                  {l}
                </span>
                <span className="font-sans text-[11px] text-slate-400">{BN[i]}</span>
              </div>
            ))}
            {!done && <span className="a-blink inline-block h-3 w-2 bg-emerald-300 align-middle" />}
          </div>
          <div className="relative h-2 border border-cyan-500/40 bg-black/60">
            <div ref={bar} className="absolute inset-0 origin-left bg-gradient-to-r from-cyan-500 to-emerald-400" style={{ transform: "scaleX(0)" }} />
          </div>
          <div className="mono mt-1 flex justify-between text-[11px] text-cyan-300/80">
            <span>BOOT SEQUENCE</span>
            <span>
              <span ref={pct}>000</span>%
            </span>
          </div>
        </div>

        <div className={`flex flex-col gap-2 transition-opacity duration-500 sm:flex-row ${done ? "opacity-100" : "pointer-events-none opacity-0"}`}>
          <button onClick={() => enter(true)} className="border border-cyan-300 bg-cyan-400/15 px-5 py-2.5 text-sm font-semibold text-white hover:bg-cyan-400/30">
            [ অডিও সহ প্রবেশ করুন ]
          </button>
          <button onClick={() => enter(false)} className="border border-slate-500/50 px-5 py-2.5 text-sm text-slate-300 hover:border-slate-300">
            [ নীরব প্রবেশ ]
          </button>
        </div>
      </div>
    </div>
  );
}
