"use client";
import { memo, useEffect, useRef } from "react";
import { scrollToId } from "@/lib/commands";
import { CC } from "@/lib/geo";
import { useLang } from "@/lib/i18n";
import { useIntel } from "@/lib/intelStore";
import { setLayer } from "@/lib/layers";
import { useOsint } from "@/lib/osintStore";
import { Empty, Hud, Num, Section, useInView } from "./hud";
import { TypedLines } from "./Typed";

interface CyberData {
  c2: { total: number; online: number; byCountry: { cc: string; n: number }[]; byMalware: { name: string; n: number }[] };
  kev: { total: number; last30: number; ransomware: number; latest: { id: string; vendor: string; product: string; name: string; added: string; ransomware: boolean }[] };
}

/** Matrix rain — runs only while on screen, ~15 fps. */
const Matrix = memo(function Matrix({ active }: { active: boolean }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = ref.current;
    if (!c || !active) return;
    const ctx = c.getContext("2d");
    if (!ctx) return;
    const w = (c.width = c.clientWidth);
    const h = (c.height = c.clientHeight);
    const cols = Math.floor(w / 14);
    const drops = Array.from({ length: cols }, () => Math.random() * -20);
    const chars = "01アイウエオカキクケコ░▒ABCDEF0123456789";
    let last = 0;
    let raf = 0;
    const loop = (t: number) => {
      raf = requestAnimationFrame(loop);
      if (t - last < 66) return;
      last = t;
      ctx.fillStyle = "rgba(3,6,12,0.18)";
      ctx.fillRect(0, 0, w, h);
      ctx.fillStyle = "#34d399";
      ctx.font = "12px 'JetBrains Mono', monospace";
      for (let i = 0; i < cols; i++) {
        ctx.fillText(chars[(Math.random() * chars.length) | 0], i * 14, drops[i] * 14);
        if (drops[i] * 14 > h && Math.random() > 0.96) drops[i] = 0;
        drops[i]++;
      }
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [active]);
  return <canvas ref={ref} className="h-24 w-full opacity-60" aria-hidden />;
});

export default function CyberCenter() {
  const { L, lang } = useLang();
  const intel = useIntel();
  const [ref, vis] = useInView<HTMLDivElement>("0px");
  const v = useOsint<CyberData>("cyber", 1800000, { enabled: vis });
  const d = v.data;
  const cyberNews = intel?.items.filter((i) => i.category === "cyber").slice(0, 4) ?? [];
  const maxC = Math.max(1, ...(d?.c2.byCountry.map((x) => x.n) ?? [1]));

  const lines: string[] = [
    `> ${L("নেটওয়ার্ক প্রতিরক্ষা সক্রিয়", "Network defense active", "الدفاع الشبكي نشط")}`,
    `> ${L("বৈশ্বিক ট্রাফিক পর্যবেক্ষণ চলছে", "Global traffic monitoring in progress", "مراقبة الحركة العالمية")}`,
  ];
  if (d) {
    lines.push(`> ${L(`সাইবার অনুপ্রবেশ সূচক শনাক্ত: ${d.kev.last30}টি নতুন শোষিত দুর্বলতা (৩০ দিন, CISA KEV)`, `Intrusion indicators: ${d.kev.last30} newly exploited vulnerabilities (30d, CISA KEV)`, `${d.kev.last30} ثغرات مستغلة جديدة`)}`);
    lines.push(`> ${L(`বটনেট C2 অবকাঠামো: মোট ${d.c2.total}, সক্রিয় ${d.c2.online} (abuse.ch)`, `Botnet C2 infrastructure: ${d.c2.total} total, ${d.c2.online} online (abuse.ch)`, `بنية C2: ${d.c2.total}`)}`);
    const k = d.kev.latest[0];
    if (k) lines.push(`> ${L("সর্বশেষ", "Latest", "الأحدث")}: ${k.id} — ${k.vendor} ${k.product}`);
  } else if (v.error) lines.push(`! ${L("সাইবার ফিড সাময়িকভাবে অনুপলব্ধ", "Cyber feeds temporarily unavailable", "الخلاصات غير متاحة")}`);
  else lines.push(`> ${L("থ্রেট-ইন্টেল ফিড সংযুক্ত হচ্ছে…", "Connecting threat-intel feeds…", "جارٍ الاتصال")}`);
  cyberNews.forEach((n) => lines.push(`> [${L("সাইবার", "CYBER", "سيبراني")}] ${n.titleT.slice(0, 110)}`));

  return (
    <Section id="cyber" tag="◢ CYBER-WARFARE // 14" title={L("সাইবার ওয়ারফেয়ার সেন্টার", "Cyber Warfare Center", "مركز الحرب السيبرانية")} subtitle={L("প্রকৃত থ্রেট-ইন্টেল: abuse.ch Feodo বটনেট C2 তালিকা ও CISA ‘Known Exploited Vulnerabilities’ ক্যাটালগ।", "Real threat intel: abuse.ch Feodo botnet C2 list and the CISA Known Exploited Vulnerabilities catalog.", "معلومات تهديد حقيقية")}>
      <div ref={ref} className="grid gap-4 lg:grid-cols-2">
        <Hud title="TERMINAL // INTRUSION-DETECTION" right={<span className="mono a-alert text-[10px] text-emerald-400">● MONITORING</span>} pad={false}>
          <div className="relative">
            <Matrix active={vis} />
            <div className="absolute inset-0 bg-gradient-to-b from-transparent to-[#060a12]" />
          </div>
          <div className="min-h-[250px] p-3 sm:p-4">
            <TypedLines lines={lines} speed={14} sound />
          </div>
          <div className="flex flex-wrap gap-2 border-t border-cyan-500/15 p-3">
            <button onClick={() => { setLayer("cyber", true); scrollToId("map"); }} className="border border-violet-400/50 px-3 py-1.5 text-[12px] text-violet-200 hover:bg-violet-400/10">⌁ {L("ম্যাপে C2 নোড ও রুট দেখুন", "Show C2 nodes & routes on map", "عرض العقد على الخريطة")}</button>
          </div>
        </Hud>

        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            {[
              [L("C2 মোট", "C2 TOTAL", "إجمالي C2"), d?.c2.total, "#a78bfa"],
              [L("C2 সক্রিয়", "C2 ONLINE", "نشط"), d?.c2.online, "#ef4444"],
              [L("KEV ৩০ দিন", "KEV 30D", "KEV 30"), d?.kev.last30, "#fb923c"],
              [L("র‍্যানসমওয়্যার-যুক্ত", "RANSOMWARE", "فدية"), d?.kev.ransomware, "#facc15"],
            ].map(([label, val, c]) => (
              <div key={label as string} className="border border-cyan-500/15 bg-black/30 px-3 py-2">
                <div className="hud-title" style={{ color: `${c as string}cc` }}>{label as string}</div>
                <div className="mono text-2xl font-bold text-white">{val == null ? "--" : (val as number)}</div>
              </div>
            ))}
          </div>
          <Hud title={L("C2 অবকাঠামো — দেশ অনুযায়ী", "C2 INFRASTRUCTURE BY COUNTRY", "حسب البلد")}>
            {!d ? <Empty>{v.error ? L("ডেটা অনুপলব্ধ", "Data unavailable", "غير متاح") : L("লোড হচ্ছে…", "Loading…", "تحميل")}</Empty> : (
              <div className="space-y-1.5">
                {d.c2.byCountry.slice(0, 8).map((x) => (
                  <div key={x.cc} className="flex items-center gap-2 text-[12px]">
                    <span className="mono w-7 text-slate-400">{x.cc}</span>
                    <span className="w-24 truncate text-slate-200">{CC[x.cc] ? (lang === "bn" ? CC[x.cc].bn : CC[x.cc].en) : x.cc}</span>
                    <div className="h-2 flex-1 bg-white/5"><div className="h-full w-full origin-left bg-gradient-to-r from-violet-600/40 to-fuchsia-400" style={{ transform: `scaleX(${x.n / maxC})`, transition: "transform 1s", willChange: "transform" }} /></div>
                    <Num className="w-6 text-right text-slate-200">{x.n}</Num>
                  </div>
                ))}
                <div className="mono pt-1 text-[10.5px] text-slate-500">{d.c2.byMalware.map((m) => `${m.name}:${m.n}`).join(" · ")}</div>
              </div>
            )}
          </Hud>
          <Hud title={L("CISA KEV — সর্বশেষ শোষিত দুর্বলতা", "CISA KEV — LATEST EXPLOITED", "أحدث الثغرات")}>
            {!d ? <Empty>{L("লোড হচ্ছে…", "Loading…", "تحميل")}</Empty> : (
              <ul className="space-y-1.5">
                {d.kev.latest.slice(0, 6).map((k) => (
                  <li key={k.id} className="flex flex-wrap items-baseline gap-x-2 text-[12px]">
                    <span className="mono font-bold text-orange-300">{k.id}</span>
                    <span className="text-slate-200">{k.vendor} {k.product}</span>
                    {k.ransomware && <span className="border border-red-500/50 px-1 text-[10px] text-red-300">RANSOMWARE</span>}
                    <span className="mono ml-auto text-[10px] text-slate-500">{k.added}</span>
                  </li>
                ))}
              </ul>
            )}
          </Hud>
          {intel && intel.cyberRoutes.length > 0 && (
            <Hud title={L("সংবাদ-ভিত্তিক সাইবার রুট", "NEWS-DERIVED CYBER ROUTES", "مسارات من الأخبار")}>
              <ul className="space-y-1 text-[12px] text-slate-300">
                {intel.cyberRoutes.map((r) => (
                  <li key={r.id}><span className="mono text-violet-300">{lang === "bn" ? r.from?.nameBn : r.from?.name} → {lang === "bn" ? r.to.nameBn : r.to.name}</span></li>
                ))}
              </ul>
            </Hud>
          )}
        </div>
      </div>
    </Section>
  );
}
