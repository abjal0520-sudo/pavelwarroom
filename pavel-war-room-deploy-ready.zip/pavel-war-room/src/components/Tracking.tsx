"use client";
import { memo } from "react";
import { setLayer } from "@/lib/layers";
import { scrollToId } from "@/lib/commands";
import { FLASHPOINTS } from "@/lib/geo";
import { useLang } from "@/lib/i18n";
import { useIntel } from "@/lib/intelStore";
import { useOsint } from "@/lib/osintStore";
import { Ago, Empty, Hud, Section, useInView } from "./hud";

interface Ac {
  i: string;
  c: string;
  o: string;
  a: number;
  v: number;
  h: number;
  m: 0 | 1;
  s: string;
}
interface AirData {
  total: number;
  airborne: number;
  military: number;
  emergencies: number;
  fetchedAt: number;
  aircraft: Ac[];
}

const Stat = ({ label, v, c = "#22d3ee" }: { label: string; v: React.ReactNode; c?: string }) => (
  <div className="border border-cyan-500/15 bg-black/30 px-3 py-2">
    <div className="hud-title" style={{ color: `${c}cc` }}>{label}</div>
    <div className="mono text-2xl font-bold text-white">{v}</div>
  </div>
);

const AirPanel = memo(function AirPanel() {
  const { L } = useLang();
  const [ref, vis] = useInView<HTMLDivElement>("0px");
  const v = useOsint<AirData>("aircraft", 45000, { enabled: vis });
  const d = v.data;
  const mil = d ? d.aircraft.filter((a) => a.m).sort((x, y) => y.a - x.a).slice(0, 10) : [];
  return (
    <div ref={ref}>
      <Hud title={L("লাইভ বিমান ট্র্যাকিং — OpenSky ADS-B", "LIVE AIRCRAFT — OPENSKY ADS-B", "تتبع الطائرات — OpenSky")} right={d ? <span className="mono text-[10px] text-emerald-400">● <Ago iso={new Date(d.fetchedAt).toISOString()} /></span> : undefined}>
        <div className="relative mb-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
          <Stat label={L("আকাশে (ADS-B)", "AIRBORNE", "في الجو")} v={d?.airborne ?? "--"} />
          <Stat label={L("সামরিক শনাক্ত", "MILITARY", "عسكري")} v={d?.military ?? "--"} c="#fb923c" />
          <Stat label={L("জরুরি স্কোয়াক", "EMERGENCY SQK", "طوارئ")} v={d?.emergencies ?? "--"} c="#ef4444" />
          <Stat label={L("মোট সংকেত", "TOTAL STATES", "الإجمالي")} v={d?.total ?? "--"} c="#a78bfa" />
        </div>
        {v.error && !d ? (
          <Empty>{L("OpenSky বর্তমানে অনুপলব্ধ (রেট লিমিট/সংযোগ) — কিছুক্ষণ পর স্বয়ংক্রিয়ভাবে আবার চেষ্টা হবে।", "OpenSky currently unavailable (rate limit/connection) — retrying automatically.", "OpenSky غير متاح حالياً")}</Empty>
        ) : !d ? (
          <Empty>{L("ADS-B ডেটা লোড হচ্ছে…", "Loading ADS-B data…", "جارٍ التحميل")}</Empty>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[420px] text-left text-[12px]">
              <thead className="text-slate-500">
                <tr className="border-b border-cyan-500/15">
                  <th className="py-1 font-normal">{L("কলসাইন", "CALLSIGN", "النداء")}</th>
                  <th className="font-normal">{L("দেশ", "ORIGIN", "البلد")}</th>
                  <th className="font-normal">{L("উচ্চতা", "ALT", "الارتفاع")}</th>
                  <th className="font-normal">{L("গতি", "SPD", "السرعة")}</th>
                  <th className="font-normal">HDG</th>
                </tr>
              </thead>
              <tbody className="mono">
                {mil.length === 0 && (
                  <tr><td colSpan={5} className="py-3 font-sans text-slate-500">{L("বর্তমানে কোনো সামরিক ADS-B সংকেত শনাক্ত হয়নি।", "No military ADS-B signals detected right now.", "لا إشارات عسكرية")}</td></tr>
                )}
                {mil.map((a) => (
                  <tr key={a.i} className="border-b border-cyan-500/10 text-slate-200">
                    <td className="py-1 text-orange-300">{a.c || a.i.toUpperCase()}</td>
                    <td className="font-sans">{a.o}</td>
                    <td>{Math.round(a.a).toLocaleString("en-US")} m · FL{String(Math.round((a.a * 3.281) / 100)).padStart(3, "0")}</td>
                    <td>{Math.round(a.v * 3.6)} km/h</td>
                    <td>{String(a.h).padStart(3, "0")}°</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <div className="mt-3 flex items-center justify-between gap-2">
          <p className="text-[11px] text-slate-500">{L("কেবল ADS-B-তে দৃশ্যমান বিমান; বহু সামরিক বিমান ট্রান্সপন্ডার বন্ধ রাখে।", "Only ADS-B-visible aircraft; many military flights fly with transponders off.", "فقط الطائرات المرئية")}</p>
          <button onClick={() => { setLayer("aircraft", true); scrollToId("map"); }} className="shrink-0 border border-cyan-500/40 px-2 py-1 text-[11px] text-cyan-200 hover:bg-cyan-400/10">{L("ম্যাপে দেখুন", "Show on map", "على الخريطة")}</button>
        </div>
      </Hud>
    </div>
  );
});

const NavalPanel = memo(function NavalPanel() {
  const { L, lang } = useLang();
  const intel = useIntel();
  const [ref, vis] = useInView<HTMLDivElement>("0px");
  const ca = useOsint<{ alerts: { key: string; cables: number }[] }>("cablealerts", 3600000, { enabled: vis });
  const naval = intel?.items.filter((i) => i.category === "naval") ?? [];
  return (
    <div ref={ref}>
      <Hud title={L("নৌ নজরদারি — সমুদ্র চোকপয়েন্ট", "NAVAL SURVEILLANCE — CHOKEPOINTS", "المراقبة البحرية")}>
        <div className="grid gap-2 sm:grid-cols-2">
          {FLASHPOINTS.map((f, i) => {
            const rel = intel?.items.filter((it) => it.geo.some((g) => g.key === f.key)) ?? [];
            const nv = rel.filter((it) => it.category === "naval").length;
            const cables = ca.data?.alerts.find((a) => a.key === f.key)?.cables;
            const hot = rel.some((it) => it.level === "HIGH" || it.level === "CRITICAL");
            return (
              <div key={f.key} className="flex items-center gap-3 border border-cyan-500/15 bg-black/30 p-2">
                <div className="relative h-12 w-12 shrink-0 overflow-hidden rounded-full border border-cyan-400/40">
                  <div className="absolute inset-[25%] rounded-full border border-cyan-400/25" />
                  <div className="a-sweep absolute inset-0" style={{ background: "conic-gradient(from 0deg, rgba(34,211,238,.6), transparent 30%)", animationDelay: `${-i * 0.5}s` }} />
                  {hot && <span className="a-alert absolute right-2 top-2 h-1.5 w-1.5 bg-red-500" />}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="truncate text-[13px] font-semibold text-white">{f[lang]}</div>
                  <div className="mono text-[10.5px] text-slate-400">
                    {L("সংবাদ", "RPT", "تقارير")}:<span className="text-cyan-200"> {rel.length}</span> · {L("নৌ", "NAV", "بحري")}:<span className="text-sky-300"> {nv}</span>
                    {cables != null && <> · {L("ক্যাবল", "CBL", "كابل")}:<span className="text-orange-300"> {cables}</span></>}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
        <div className="mt-3">
          <div className="hud-title mb-1">{L("সাম্প্রতিক নৌ-সংক্রান্ত প্রতিবেদন", "LATEST NAVAL REPORTS", "آخر التقارير البحرية")}</div>
          {naval.length === 0 ? <p className="text-xs text-slate-500">{L("বর্তমানে কোনো নৌ-সংক্রান্ত প্রতিবেদন নেই।", "No naval reports at the moment.", "لا تقارير")}</p> : (
            <ul className="space-y-1.5">
              {naval.slice(0, 4).map((n) => (
                <li key={n.id} className="text-[12.5px] leading-snug text-slate-300"><a href={n.url} target="_blank" rel="noreferrer" className="hover:text-white" dir="auto">▸ {n.titleT}</a> <span className="mono text-[10px] text-slate-500">· {n.source} · </span><span className="text-[10px] text-slate-500"><Ago iso={n.publishedAt} /></span></li>
              ))}
            </ul>
          )}
        </div>
        <p className="mt-3 border-t border-cyan-500/15 pt-2 text-[11px] leading-relaxed text-slate-500">
          {L(
            "সামরিক জাহাজ, সাবমেরিন ও বিমানবাহী রণতরীর AIS সংকেত সাধারণত বন্ধ থাকে ও প্রকাশ্য নয়—তাই এখানে কাল্পনিক জাহাজ অবস্থান দেখানো হয় না। রিয়েল-টাইম নৌ-ট্র্যাকিংয়ের জন্য আলাদা AIS API কী প্রয়োজন।",
            "Warship, submarine and carrier AIS transponders are normally off and not public — so no invented vessel positions are shown. Live AIS tracking requires a separate AIS API key.",
            "لا تُعرض مواقع سفن مختلقة.",
          )}
        </p>
      </Hud>
    </div>
  );
});

export default function Tracking() {
  const { L } = useLang();
  return (
    <Section id="naval" tag="◢ AIR-NAVAL // 06 · 07" title={L("আকাশ ও নৌ নজরদারি", "Air & Naval Surveillance", "المراقبة الجوية والبحرية")} subtitle={L("OpenSky ADS-B-এর প্রকৃত বিমান ডেটা এবং কৌশলগত সমুদ্র-চোকপয়েন্টের লাইভ রিপোর্ট-পর্যবেক্ষণ।", "Real OpenSky ADS-B aircraft data and live report-monitoring of strategic maritime chokepoints.", "بيانات حقيقية")}>
      <div className="grid gap-4 xl:grid-cols-2">
        <AirPanel />
        <NavalPanel />
      </div>
    </Section>
  );
}
