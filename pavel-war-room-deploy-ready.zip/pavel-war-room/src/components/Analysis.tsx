"use client";
import { memo, useMemo, useState, type ReactNode } from "react";
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { sfx } from "@/lib/audio";
import { useLang } from "@/lib/i18n";
import { useIntel } from "@/lib/intelStore";
import { CAT_LABEL, LEVEL_COLOR, LEVEL_LABEL, type CategoryKey, type ThreatLevel } from "@/lib/types";
import { Empty, Hud, LevelBadge, Num, Section } from "./hud";

const GlowBar = memo(function GlowBar({ v, color }: { v: number; color: string }) {
  return (
    <div className="relative h-2 w-full bg-white/5">
      <div className="absolute inset-y-0 left-0 w-full origin-left transition-transform duration-1000 ease-out" style={{ transform: `scaleX(${Math.max(0.02, v / 100)})`, background: `linear-gradient(90deg, ${color}55, ${color})`, willChange: "transform" }} />
      <div className="absolute inset-y-0 w-[2px] bg-white/80 transition-[left] duration-1000" style={{ left: `${v}%` }} />
    </div>
  );
});

const colorFor = (v: number) => (v < 25 ? "#4ade80" : v < 45 ? "#22d3ee" : v < 65 ? "#facc15" : v < 82 ? "#fb923c" : "#ef4444");

function Metric({ tag, text, v, note }: { tag: string; text: ReactNode; v: number; note?: string }) {
  const c = colorFor(v);
  return (
    <Hud accent={c}>
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="hud-title" style={{ color: `${c}cc` }}>{tag}</div>
          <p className="mt-1 text-[14px] leading-snug text-slate-100">{text}</p>
          {note && <p className="mt-1 text-[11px] text-slate-500">{note}</p>}
        </div>
        <div className="mono text-3xl font-bold" style={{ color: c }}>{v}<span className="text-sm">%</span></div>
      </div>
      <div className="mt-3"><GlowBar v={v} color={c} /></div>
    </Hud>
  );
}

const SERIES_COLORS: Record<string, string> = { all: "#e2e8f0", missile: "#fb923c", airstrike: "#ef4444", cyber: "#a78bfa", naval: "#38bdf8", border: "#facc15", nuclear: "#f43f5e" };

function Summarizer() {
  const { L, lang } = useLang();
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [res, setRes] = useState<null | { category: CategoryKey; level: ThreatLevel; geo: { name: string; nameBn: string }[]; sentences: string[]; originalLength: number }>(null);
  const [err, setErr] = useState(false);
  const run = async () => {
    sfx.lock();
    setBusy(true);
    setErr(false);
    try {
      const r = await fetch("/api/summarize", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ text, lang }) });
      if (!r.ok) throw new Error();
      setRes(await r.json());
      sfx.ping();
    } catch {
      setErr(true);
      setRes(null);
    } finally {
      setBusy(false);
    }
  };
  return (
    <Hud title={L("এআই সংবাদ সামারাইজার", "AI NEWS SUMMARIZER", "ملخص الأخبار الذكي")}>
      <p className="mb-2 text-[12px] text-slate-400">{L("যেকোনো দীর্ঘ ইংরেজি/বাংলা নিবন্ধ পেস্ট করুন — সংক্ষিপ্ত ট্যাকটিক্যাল সারসংক্ষেপ পাবেন।", "Paste a long article to get a short tactical summary.", "الصق مقالاً طويلاً للحصول على ملخص تكتيكي.")}</p>
      <textarea value={text} onChange={(e) => setText(e.target.value)} rows={5} placeholder={L("নিবন্ধের পূর্ণ লেখা এখানে পেস্ট করুন…", "Paste article text here…", "الصق النص هنا…")} className="w-full resize-y border border-cyan-500/25 bg-black/50 p-2 text-sm text-slate-200 outline-none focus:border-cyan-300" />
      <div className="mt-2 flex items-center gap-3">
        <button onClick={run} disabled={busy || text.trim().length < 80} className="border border-cyan-300 bg-cyan-400/15 px-4 py-1.5 text-sm text-white disabled:opacity-40">
          {busy ? L("বিশ্লেষণ হচ্ছে…", "Analyzing…", "جارٍ التحليل") : L("সারসংক্ষেপ তৈরি করুন", "Summarize", "لخّص")}
        </button>
        <span className="mono text-[11px] text-slate-500">{text.length} chars</span>
        {err && <span className="text-xs text-red-400">{L("কমপক্ষে ৮০ অক্ষরের টেক্সট দিন", "Provide at least 80 characters", "80 حرفاً على الأقل")}</span>}
      </div>
      {res && (
        <div className="a-in mt-3 border-t border-cyan-500/20 pt-3">
          <div className="mb-2 flex flex-wrap items-center gap-2">
            <LevelBadge level={res.level} />
            <span className="border border-cyan-500/25 px-1.5 py-0.5 text-[11px] text-cyan-200">{CAT_LABEL[res.category][lang]}</span>
            {res.geo.map((g) => <span key={g.name} className="border border-emerald-500/30 px-1.5 py-0.5 text-[11px] text-emerald-200">{lang === "bn" ? g.nameBn : g.name}</span>)}
          </div>
          <div className="hud-title mb-1">{L("মূল বিশ্লেষণ", "KEY ANALYSIS", "التحليل الرئيسي")}</div>
          <ul className="space-y-1.5 text-[14px] text-slate-200">
            {res.sentences.map((s, i) => <li key={i} className="flex gap-2"><span className="mono text-cyan-400">▸</span><span dir="auto">{s}</span></li>)}
          </ul>
        </div>
      )}
    </Hud>
  );
}

export default function Analysis() {
  const { L, lang } = useLang();
  const intel = useIntel();
  const a = intel?.analysis;
  const [sel, setSel] = useState<string[]>(["all", "missile", "airstrike"]);
  const data = useMemo(() => {
    if (!intel) return [];
    return Array.from({ length: 24 }, (_, i) => ({ h: `${i - 23}h`, ...Object.fromEntries(Object.entries(intel.series).map(([k, v]) => [k, v[i]])) }));
  }, [intel]);
  const top = lang === "bn" ? a?.topHotspotBn : a?.topHotspot;

  return (
    <Section id="analysis" tag="◢ AI-ANALYSIS // 09" title={L("এআই হুমকি বিশ্লেষণ", "AI Threat Analysis", "تحليل التهديدات بالذكاء الاصطناعي")} subtitle={L("লাইভ সংবাদের তীব্রতা, সময়-ক্ষয় ও প্রবণতা থেকে গণনাকৃত সূচক—এগুলো অ্যালগরিদমিক অনুমান, অফিসিয়াল পূর্বাভাস নয়।", "Indices computed from live report severity, time-decay and trend — algorithmic estimates, not official forecasts.", "مؤشرات خوارزمية من بيانات حية.")}>
      {!a ? (
        <Empty>{L("বিশ্লেষণের জন্য ডেটা সংগ্রহ চলছে…", "Collecting data for analysis…", "جارٍ جمع البيانات…")}</Empty>
      ) : (
        <div className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_minmax(0,1.1fr)]">
          <div className="grid gap-3 sm:grid-cols-2">
            <Metric tag="ESCALATION-24H" v={a.borderEscalation} text={<>{L("আগামী ২৪ ঘণ্টায় সীমান্ত উত্তেজনা বৃদ্ধির সম্ভাবনা", "Probability of border-tension escalation in the next 24h:", "احتمال تصاعد التوتر الحدودي خلال 24 ساعة")} <Num className="font-bold text-white">{a.borderEscalation}%</Num></>} note={L(`ভিত্তি: গত ৬ ঘণ্টায় ${a.recentCount}টি প্রতিবেদন`, `Basis: ${a.recentCount} reports in last 6h`)} />
            <Metric tag="CONFLICT-PROB" v={a.conflictProbability} text={<>{L("সর্বোচ্চ সংঘাত-তীব্রতার অঞ্চল:", "Highest conflict-intensity zone:", "أعلى منطقة نزاع:")} <b className="text-white">{top ?? "—"}</b></>} note={L("সংঘাত সম্ভাবনা সূচক (দেশভিত্তিক স্কোর)", "conflict probability index (country score)")} />
            <Metric tag="NUCLEAR-RISK" v={a.nuclearRisk} text={<>{L("পারমাণবিক ঝুঁকি সূচক", "Nuclear risk index", "مؤشر الخطر النووي")}: <b className="text-white">{LEVEL_LABEL[intel!.stats.nuclearLevel][lang]}</b></>} note={L("পারমাণবিক-সংশ্লিষ্ট শিরোনামের ভারযুক্ত তীব্রতা", "weighted severity of nuclear-related headlines")} />
            <Metric tag="CYBER-THREAT" v={a.cyberThreat} text={L("সাইবার হুমকির সক্রিয়তা ও সম্ভাব্য অনুপ্রবেশ ঝুঁকি", "Cyber threat activity and intrusion risk", "نشاط التهديد السيبراني")} note={L("সাইবার শিরোনামের তীব্রতা", "cyber-headline severity")} />
            <Metric tag="GEO-INSTABILITY" v={a.instability} text={L("ভূ-রাজনৈতিক অস্থিরতা (শীর্ষ ৮ দেশের গড় স্কোর)", "Geopolitical instability (avg. of top-8 countries)", "عدم الاستقرار الجيوسياسي")} />
            <Metric tag="MIL-MOVEMENT" v={a.movementActivity} text={L("সামরিক গতিবিধি পূর্বাভাস: নৌ, আকাশ ও সীমান্ত কার্যক্রম", "Military movement outlook: naval, air and border activity", "التحركات العسكرية المتوقعة")} />
            <div className="sm:col-span-2">
              <p className="mono text-[11px] text-slate-500">
                {L(`বিশ্লেষণের ভিত্তি: ${a.basisCount}টি সংবাদ · আপডেট`, `Basis: ${a.basisCount} items · updated`)} {intel!.generatedAt.slice(11, 19)}Z
              </p>
            </div>
          </div>

          <Hud title={L("২৪ ঘণ্টার কার্যক্রম গ্রাফ", "24H ACTIVITY GRAPH", "مخطط 24 ساعة")} right={<span className="mono text-[10px] text-cyan-400">LIVE</span>}>
            <div className="mb-2 flex flex-wrap gap-1.5">
              {Object.keys(SERIES_COLORS).map((k) => {
                const on = sel.includes(k);
                return (
                  <button key={k} onClick={() => { sfx.click(); setSel((s) => (on ? s.filter((x) => x !== k) : [...s, k])); }} className="border px-2 py-0.5 text-[11px]" style={{ borderColor: on ? SERIES_COLORS[k] : "#1e3a4a", color: on ? SERIES_COLORS[k] : "#64748b", background: on ? `${SERIES_COLORS[k]}18` : "transparent" }}>
                    {k === "all" ? L("সব", "All", "الكل") : CAT_LABEL[k as CategoryKey][lang]}
                  </button>
                );
              })}
            </div>
            <div className="h-[290px] w-full" dir="ltr">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={data} margin={{ top: 6, right: 8, left: -22, bottom: 0 }}>
                  <defs>
                    {Object.entries(SERIES_COLORS).map(([k, c]) => (
                      <linearGradient key={k} id={`g-${k}`} x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0" stopColor={c} stopOpacity={0.45} />
                        <stop offset="1" stopColor={c} stopOpacity={0} />
                      </linearGradient>
                    ))}
                  </defs>
                  <CartesianGrid stroke="rgba(34,211,238,0.08)" />
                  <XAxis dataKey="h" tick={{ fill: "#64748b", fontSize: 10, fontFamily: "JetBrains Mono" }} interval={3} />
                  <YAxis allowDecimals={false} tick={{ fill: "#64748b", fontSize: 10, fontFamily: "JetBrains Mono" }} />
                  <Tooltip contentStyle={{ background: "#060a12", border: "1px solid rgba(34,211,238,.4)", fontFamily: "JetBrains Mono", fontSize: 11 }} />
                  {sel.map((k) => <Area key={k} type="monotone" dataKey={k} stroke={SERIES_COLORS[k]} strokeWidth={1.6} fill={`url(#g-${k})`} isAnimationActive={false} />)}
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </Hud>
          <div className="xl:col-span-2"><Summarizer /></div>
        </div>
      )}
      <span className="hidden">{LEVEL_COLOR.LOW}</span>
    </Section>
  );
}
