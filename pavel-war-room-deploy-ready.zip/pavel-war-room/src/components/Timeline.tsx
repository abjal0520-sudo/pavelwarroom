"use client";
import { motion, useScroll, useSpring } from "framer-motion";
import { useMemo, useRef, useState } from "react";
import { sfx } from "@/lib/audio";
import { HISTORY, HIST_META, type HistType } from "@/lib/history";
import { useLang } from "@/lib/i18n";
import { useOsint } from "@/lib/osintStore";
import { CAT_LABEL, LEVEL_COLOR, type CategoryKey, type ThreatLevel } from "@/lib/types";
import { Ago, Section } from "./hud";

interface Live {
  id: string;
  title: string;
  titleBn: string | null;
  source: string;
  url: string;
  level: ThreatLevel;
  category: CategoryKey | null;
  at: string;
}
interface Row {
  key: string;
  date: string;
  type: HistType | "live";
  title: string;
  color: string;
  live?: Live;
}

export default function Timeline() {
  const { L, lang } = useLang();
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start 75%", "end 55%"] });
  const line = useSpring(scrollYProgress, { stiffness: 80, damping: 24 });
  const live = useOsint<{ items: Live[] }>("timeline", 120000);
  const [filter, setFilter] = useState<HistType | "all" | "live">("all");

  const rows = useMemo<Row[]>(() => {
    const out: Row[] = [];
    for (const l of live.data?.items ?? []) {
      out.push({ key: `l-${l.id}`, date: l.at, type: "live", title: lang === "bn" && l.titleBn ? l.titleBn : l.title, color: LEVEL_COLOR[l.level], live: l });
    }
    for (const h of HISTORY) out.push({ key: `h-${h.date}-${h.type}`, date: h.date, type: h.type, title: lang === "bn" ? h.bn : lang === "ar" ? h.ar : h.en, color: HIST_META[h.type].color });
    return out.sort((a, b) => Date.parse(b.date) - Date.parse(a.date)).filter((r) => filter === "all" || r.type === filter);
  }, [live.data, lang, filter]);

  const chips: [HistType | "all" | "live", string, string][] = [
    ["all", L("সব", "All", "الكل"), "#e2e8f0"],
    ["live", L("লাইভ", "Live", "مباشر"), "#ef4444"],
    ...(Object.keys(HIST_META) as HistType[]).map((k) => [k, HIST_META[k][lang], HIST_META[k].color] as [HistType, string, string]),
  ];

  return (
    <Section id="timeline" tag="◢ EVENT-TIMELINE // 17" title={L("ইভেন্ট টাইমলাইন", "Event Timeline", "الجدول الزمني")} subtitle={L("লাইভ সংগৃহীত উচ্চ-গুরুত্বের ঘটনা এবং নথিভুক্ত ঐতিহাসিক ঘটনা—স্ক্রল করার সাথে সাথে অ্যানিমেট হয়।", "Live high-severity events plus documented historical events — animates as you scroll.", "أحداث حية وتاريخية")}>
      <div className="mb-5 flex flex-wrap gap-1.5">
        {chips.map(([k, label, c]) => (
          <button key={k} onClick={() => { sfx.click(); setFilter(k); }} className="border px-2.5 py-1 text-xs" style={{ borderColor: filter === k ? c : "#16303d", color: filter === k ? c : "#94a3b8", background: filter === k ? `${c}18` : "transparent" }}>
            {label}
          </button>
        ))}
      </div>
      <div ref={ref} className="relative">
        <div className="absolute bottom-0 left-3 top-0 w-px bg-cyan-500/15 md:left-1/2" />
        <motion.div className="absolute bottom-0 left-3 top-0 w-[2px] origin-top bg-gradient-to-b from-cyan-300 to-cyan-500/30 md:left-1/2" style={{ scaleY: line }} />
        <div className="space-y-5">
          {rows.map((r, i) => {
            const right = i % 2 === 0;
            return (
              <motion.div key={r.key} initial={{ opacity: 0, x: right ? 40 : -40 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true, margin: "-60px" }} transition={{ duration: 0.5 }} className={`relative pl-9 md:w-1/2 md:pl-0 ${right ? "md:ml-auto md:pl-10" : "md:pr-10 md:text-right"}`}>
                <span className={`absolute top-3 h-3 w-3 -translate-x-1/2 border-2 bg-[#03060c] left-3 ${right ? "md:left-0" : "md:left-full"}`} style={{ borderColor: r.color }}>
                  {r.type === "live" && <span className="a-alert absolute inset-0" style={{ background: r.color }} />}
                </span>
                <div className="hud px-3 py-2.5" style={{ borderColor: `${r.color}44` }}>
                  <div className={`mb-1 flex flex-wrap items-center gap-2 ${right ? "" : "md:justify-end"}`}>
                    <span className="mono text-[12px] font-bold" style={{ color: r.color }}>{r.date.slice(0, 10)}</span>
                    <span className="border px-1.5 text-[10px]" style={{ borderColor: `${r.color}66`, color: r.color }}>
                      {r.type === "live" ? `● ${L("লাইভ", "LIVE", "مباشر")}${r.live?.category ? " · " + CAT_LABEL[r.live.category][lang] : ""}` : HIST_META[r.type][lang]}
                    </span>
                    {r.live && <span className="text-[10px] text-slate-500"><Ago iso={r.live.at} /></span>}
                  </div>
                  <p className="text-[14px] leading-snug text-slate-100" dir="auto">
                    {r.live ? <a href={r.live.url} target="_blank" rel="noreferrer" className="hover:underline">{r.title}</a> : r.title}
                  </p>
                  {r.live && <div className="mono mt-0.5 text-[10px] text-slate-500">{r.live.source}</div>}
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </Section>
  );
}
