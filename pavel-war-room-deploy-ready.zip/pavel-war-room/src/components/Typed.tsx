"use client";
import { memo, useEffect, useState } from "react";
import { sfx } from "@/lib/audio";

/** Realistic typing effect with blinking cursor; only types the newly-arrived tail when text grows. */
export const TypedLines = memo(function TypedLines({ lines, speed = 22, className = "", sound = false }: { lines: string[]; speed?: number; className?: string; sound?: boolean }) {
  const text = lines.join("\n");
  const [count, setCount] = useState(0);
  const done = count >= text.length;
  useEffect(() => {
    if (done) return;
    const id = setInterval(() => {
      setCount((c) => {
        if (sound && c % 3 === 0) sfx.type();
        return Math.min(text.length, c + 1);
      });
    }, speed);
    return () => clearInterval(id);
  }, [done, text.length, speed, sound]);
  const shown = text.slice(0, count).split("\n");
  return (
    <div className={`mono whitespace-pre-wrap text-[12.5px] leading-relaxed ${className}`}>
      {shown.map((l, i) => (
        <div key={i} className={l.startsWith("> ") ? "text-emerald-300" : l.startsWith("!") ? "text-red-300" : "text-slate-300"}>
          {l}
          {i === shown.length - 1 && <span className="a-blink ml-0.5 inline-block h-3.5 w-2 translate-y-0.5 bg-emerald-300" />}
        </div>
      ))}
    </div>
  );
});
