"use client";
import { useLang } from "@/lib/i18n";
import { useOsint } from "@/lib/osintStore";
import { Ago, Empty, Hud, Section, useInView } from "./hud";

interface Post {
  id: string;
  at: string;
  url: string;
  user: string;
  tag: string;
  text: string;
  textT: string;
  fav: number;
  boost: number;
}

export default function Social() {
  const { L, lang } = useLang();
  const [ref, vis] = useInView<HTMLDivElement>("0px");
  const v = useOsint<{ posts: Post[] }>("social", 120000, { lang, enabled: vis });
  const platforms: [string, boolean, string, string][] = [
    ["Mastodon (mastodon.social)", !!v.data, "পাবলিক হ্যাশট্যাগ টাইমলাইন — সক্রিয়", "Public hashtag timelines — active"],
    ["X / Twitter", false, "API কী ও পেইড অ্যাক্সেস প্রয়োজন — কনফিগার করা নেই", "Requires paid API access — not configured"],
    ["Reddit", false, "সার্ভার-সাইড অ্যাক্সেস ব্লক করা (403) — অনুপলব্ধ", "Server-side access blocked (403) — unavailable"],
    ["Telegram", false, "পাবলিক চ্যানেলের জন্য অফিসিয়াল API সেশন প্রয়োজন — কনফিগার করা নেই", "Needs an official API session — not configured"],
  ];
  return (
    <Section id="social" tag="◢ SOCIAL-INT // 19" title={L("সোশ্যাল মিডিয়া মনিটরিং", "Social Media Monitoring", "مراقبة وسائل التواصل")} subtitle={L("শুধু প্রকৃত পাবলিক পোস্ট দেখানো হয়। যেসব প্ল্যাটফর্মের অ্যাক্সেস নেই, সেগুলো স্পষ্টভাবে ‘অনুপলব্ধ’ চিহ্নিত।", "Only real public posts are shown. Platforms without access are clearly marked unavailable.", "منشورات عامة حقيقية فقط")}>
      <div ref={ref} className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_340px]">
        <div className="space-y-2.5">
          {!v.data ? (
            <Empty>{v.error ? L("সোশ্যাল ফিড সাময়িকভাবে অনুপলব্ধ", "Social feed temporarily unavailable", "غير متاح") : L("পোস্ট সংগ্রহ ও অনুবাদ চলছে…", "Collecting and translating posts…", "جارٍ التحميل")}</Empty>
          ) : (
            v.data.posts.map((p) => (
              <article key={p.id} className="border border-cyan-500/15 bg-[#060a12]/90 p-3">
                <div className="mb-1 flex flex-wrap items-center gap-2 text-[11px]">
                  <span className="mono text-cyan-300">@{p.user}</span>
                  <span className="border border-cyan-500/25 px-1 text-[10px] text-slate-300">#{p.tag}</span>
                  <span className="text-slate-500"><Ago iso={p.at} /></span>
                  <span className="mono ml-auto text-slate-500">♥{p.fav} ⟲{p.boost}</span>
                </div>
                <p className="text-[14px] leading-snug text-slate-100" dir="auto">{p.textT}</p>
                {lang !== "en" && p.textT !== p.text && <p className="mono mt-1 text-[11px] leading-snug text-slate-500" dir="ltr">{p.text}</p>}
                <a href={p.url} target="_blank" rel="noreferrer" className="mt-1 inline-block text-[11px] text-cyan-400 hover:underline">{L("মূল পোস্ট ↗", "Original post ↗", "المنشور ↗")}</a>
              </article>
            ))
          )}
        </div>
        <Hud title={L("প্ল্যাটফর্ম স্ট্যাটাস", "PLATFORM STATUS", "حالة المنصات")} className="h-fit">
          <ul className="space-y-3">
            {platforms.map(([name, ok, bn, en]) => (
              <li key={name} className="text-[12.5px]">
                <div className="flex items-center gap-2"><span className="h-2 w-2" style={{ background: ok ? "#4ade80" : "#64748b" }} /><span className="mono text-slate-100">{name}</span></div>
                <div className="ml-4 text-[11.5px] text-slate-400">{lang === "bn" ? bn : en}</div>
              </li>
            ))}
          </ul>
        </Hud>
      </div>
    </Section>
  );
}
