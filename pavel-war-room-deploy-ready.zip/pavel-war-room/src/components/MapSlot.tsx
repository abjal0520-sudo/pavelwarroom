"use client";
import { useEffect, useRef } from "react";
import { registerSlot } from "@/lib/mapController";

/** A placeholder that the single shared WebGL map is mounted into while it is the most visible slot. */
export default function MapSlot({ mode, className = "" }: { mode: "hero" | "tactical"; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    return registerSlot(el, mode);
  }, [mode]);
  return <div ref={ref} className={`absolute inset-0 overflow-hidden bg-[#02050b] ${className}`} />;
}
