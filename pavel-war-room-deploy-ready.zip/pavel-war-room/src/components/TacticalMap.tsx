"use client";
import { memo, useEffect, useRef } from "react";
import { sfx } from "@/lib/audio";
import { setVision } from "@/lib/commands";
import { FLASHPOINTS } from "@/lib/geo";
import { useLang } from "@/lib/i18n";
import { useIntel } from "@/lib/intelStore";
import { setLayer, toggleLayer, useLayers, type LayerId } from "@/lib/layers";
import { getMapStatus, subscribeMapStatus, subscribeView } from "@/lib/mapController";
import { useOsint } from "@/lib/osintStore";
import { Hud, useInView } from "./hud";
import MapSlot from "./MapSlot";

const CoordReadout = memo(function CoordReadout() {
  const a = useRef<HTMLSpanElement>(null);
  const b = useRef<HTMLSpanElement>(null);
  useEffect(
    () =>
      subscribeView((v) => {
        const f = (la: number, lo: number) => `${Math.abs(la).toFixed(4).padStart(8, "0")}°${la >= 0 ? "N" : "S"} ${Math.abs(lo).toFixed(4).padStart(9, "0")}°${lo >= 0 ? "E" : "W"}`;
        if (a.current) a.current.textContent = f(v.lat, v.lng);
        if (b.current) b.current.textContent = v.cursor ? f(v.cursor.lat, v.cursor.lng) : "--------°- ---------°-";
      }),
    [],
  );
  return (
    <div className="mono space-y-0.5 text-[11px] text-cyan-100">
      <div>
        <span className="text-slate-500">CTR </span>
        <span ref={a}>--------</span>
      </div>
      <div>
        <span className="text-slate-500">CUR </span>
        <span ref={b}>--------</span>
      </div>
    </div>
  );
});

const SatOverlay = memo(function SatOverlay() {
  const { L } = useLang();
  const t = useRef<HTMLSpanElement>(null);
  useEffect(() => {
    const id = setInterval(() => {
      if (t.current) t.current.textContent = new Date().toISOString().slice(0, 19).replace("T", " ") + "Z";
    }, 1000);
    return () => clearInterval(id);
  }, []);
  return (
    <div className="pointer-events-none absolute inset-0 z-[5]">
      <div className="scanlines absolute inset-0" />
      <div className="a-scan absolute inset-x-0 top-0 h-1/4 bg-gradient-to-b from-transparent via-red-400/10 to-transparent" />
      <div className="absolute inset-3 border border-red-400/30" />
      <div className="mono absolute left-5 top-4 flex items-center gap-2 text-[11px] text-red-300">
        <span className="a-alert h-2 w-2 bg-red-500" /> REC · ORBITAL ISR · {L("স্যাটেলাইট নজরদারি", "SATELLITE SURVEILLANCE", "مراقبة الأقمار")}
      </div>
      <div className="mono absolute right-5 top-4 text-[11px] text-red-200">
        <span ref={t}>----</span>
      </div>
      <div className="pointer-events-auto absolute bottom-16 left-1/2 flex -translate-x-1/2 gap-1.5 md:bottom-5">
        <button onClick={() => { sfx.lock(); setVision("flir"); }} className="border border-orange-400/60 bg-black/70 px-2.5 py-1 text-[11px] text-orange-200">{L("ইনফ্রারেড / থার্মাল", "INFRARED / THERMAL", "الأشعة تحت الحمراء")}</button>
        <button onClick={() => { sfx.lock(); setVision("nvg"); }} className="border border-emerald-400/60 bg-black/70 px-2.5 py-1 text-[11px] text-emerald-200">NVG</button>
        <button onClick={() => { sfx.lock(); setVision("std"); }} className="border border-cyan-400/60 bg-black/70 px-2.5 py-1 text-[11px] text-cyan-200">{L("সাধারণ", "STD", "عادي")}</button>
        <button onClick={() => { sfx.click(); setLayer("satmode", false); setVision("std"); }} className="border border-red-400/60 bg-black/70 px-2.5 py-1 text-[11px] text-red-200">✕</button>
      </div>
    </div>
  );
});

interface LayerDef {
  id: LayerId;
  icon: string;
  bn: string;
  en: string;
  ar: string;
  kind?: "aircraft" | "satellites" | "cables" | "thermal" | "cyber" | "weather";
}
const BASE: LayerDef[] = [
  { id: "aircraft", icon: "✈", bn: "বিমান ট্র্যাকিং (OpenSky)", en: "Aircraft tracking (OpenSky)", ar: "تتبع الطائرات", kind: "aircraft" },
  { id: "missiles", icon: "◎", bn: "ক্ষেপণাস্ত্র ট্র্যাজেক্টরি (সংবাদ-ভিত্তিক)", en: "Missile trajectories (news-derived)", ar: "مسارات الصواريخ" },
  { id: "heat", icon: "▓", bn: "সংঘাত হিটম্যাপ ও রাডার পিং", en: "Conflict heatmap & radar pings", ar: "خريطة حرارة النزاعات" },
  { id: "naval", icon: "⚓", bn: "নৌ রাডার স্ক্যান / চোকপয়েন্ট", en: "Naval radar scans / chokepoints", ar: "مسح بحري" },
];
const OSINT: LayerDef[] = [
  { id: "thermal", icon: "🔥", bn: "NASA FIRMS থার্মাল বিস্ফোরণ হিটম্যাপ", en: "NASA FIRMS thermal-explosion heatmap", ar: "خريطة الانفجارات الحرارية NASA", kind: "thermal" },
  { id: "gpsjam", icon: "📡", bn: "জিপিএস জ্যামিং ও ইলেকট্রনিক ওয়ারফেয়ার", en: "GPS jamming & electronic warfare", ar: "التشويش على GPS والحرب الإلكترونية" },
  { id: "spysat", icon: "🛰️", bn: "লাইভ স্পাই স্যাটেলাইট ট্র্যাকার", en: "Live spy-satellite tracker", ar: "متتبع أقمار التجسس", kind: "satellites" },
  { id: "cables", icon: "🌊", bn: "সাবমেরিন ক্যাবল ও পাইপলাইন ঝুঁকি", en: "Submarine cable & pipeline risk", ar: "الكابلات البحرية وخطوط الأنابيب", kind: "cables" },
  { id: "cyber", icon: "⌁", bn: "সাইবার C2 নোড ও রুট", en: "Cyber C2 nodes & routes", ar: "عقد الهجمات السيبرانية", kind: "cyber" },
  { id: "weather", icon: "☁", bn: "যুদ্ধক্ষেত্র আবহাওয়া ওভারলে", en: "Battlefield weather overlay", ar: "طقس ساحة المعركة", kind: "weather" },
];

const Toggle = memo(function Toggle({ def, on }: { def: LayerDef; on: boolean }) {
  const { L } = useLang();
  const v = useOsint<Record<string, unknown> & { aircraft?: unknown[]; sats?: unknown[]; points?: unknown[]; cables?: { features: unknown[] }; source?: string; live?: boolean; c2?: { total: number } }>(def.kind ?? "aircraft", 1e9, { enabled: false });
  let sub = "";
  if (on && def.kind) {
    if (v.error) sub = L("⚠ ডেটা পাওয়া যায়নি", "⚠ data unavailable", "⚠ لا بيانات");
    else if (!v.data) sub = L("লোড হচ্ছে…", "loading…", "جارٍ التحميل");
    else if (def.kind === "aircraft") sub = `${v.data.aircraft?.length ?? 0} ${L("অবজেক্ট", "objects", "جسم")}`;
    else if (def.kind === "satellites") sub = `${v.data.sats?.length ?? 0} ${L("স্যাটেলাইট", "satellites", "قمر")}`;
    else if (def.kind === "thermal") sub = `${v.data.points?.length ?? 0} ${L("অসঙ্গতি", "anomalies", "شذوذ")} · ${v.data.source?.split(" (")[0] ?? ""}`;
    else if (def.kind === "cables") sub = `${v.data.cables?.features.length ?? 0} ${L("ক্যাবল", "cables", "كابل")}`;
    else if (def.kind === "cyber") sub = `${v.data.c2?.total ?? 0} C2`;
  }
  if (on && def.id === "gpsjam") sub = L("রেফারেন্স অঞ্চল (লাইভ নয়)", "reference zones (not live)", "مناطق مرجعية");
  return (
    <button
      onClick={() => {
        toggleLayer(def.id);
        sfx.click();
        if (!on) sfx.ping();
      }}
      className={`flex w-full items-center gap-2 border px-2 py-1.5 text-left transition-colors ${on ? "border-cyan-400/50 bg-cyan-400/10" : "border-cyan-500/15 hover:border-cyan-500/40"}`}
      aria-pressed={on}
    >
      <span className="w-5 text-center text-sm">{def.icon}</span>
      <span className="min-w-0 flex-1">
        <span className={`block text-[12px] leading-tight ${on ? "text-white" : "text-slate-300"}`}>{L(def.bn, def.en, def.ar)}</span>
        {sub && <span className="mono block text-[10px] text-cyan-300/80">{sub}</span>}
      </span>
      <span className={`toggle-track ${on ? "toggle-on" : ""}`}>
        <span className="toggle-thumb" />
      </span>
    </button>
  );
});

const CableAlerts = memo(function CableAlerts() {
  const { L, lang } = useLang();
  const v = useOsint<{ alerts: { key: string; cables: number }[] }>("cablealerts", 3600000);
  const intel = useIntel();
  if (!v.data) return null;
  return (
    <div className="mt-2 border border-orange-400/30 bg-orange-500/5 p-2">
      <div className="hud-title !text-orange-300">{L("নৌ-নৈকট্য সতর্কতা", "NAVAL PROXIMITY ALERTS", "تنبيهات القرب البحري")}</div>
      <ul className="mt-1 space-y-1 text-[11px]">
        {v.data.alerts.slice(0, 6).map((a) => {
          const fp = FLASHPOINTS.find((f) => f.key === a.key);
          const news = intel?.items.filter((i) => i.category === "naval" && i.geo.some((g) => g.key === a.key)).length ?? 0;
          return (
            <li key={a.key} className="flex items-center justify-between gap-2">
              <span className="text-slate-200">{fp ? fp[lang] : a.key}</span>
              <span className="mono text-orange-300">
                {a.cables} {L("ক্যাবল", "cables", "كابل")}
                {news > 0 && <span className="a-alert ml-1 text-red-400">⚠{news}</span>}
              </span>
            </li>
          );
        })}
      </ul>
    </div>
  );
});

export default function TacticalMap() {
  const { L } = useLang();
  const layers = useLayers();
  const [ref, vis] = useInView<HTMLElement>("0px");
  const status = useRef<HTMLDivElement>(null);
  const panel = useRef<HTMLDetailsElement>(null);
  useEffect(() => {
    if (window.innerWidth < 768 && panel.current) panel.current.open = false;
  }, []);
  const air = useOsint<{ airborne: number; military: number; aircraft: unknown[] }>("aircraft", 45000, { enabled: false });

  useEffect(
    () =>
      subscribeMapStatus((s) => {
        if (status.current) status.current.textContent = s === "ready" ? "MAP: ONLINE" : s === "error" ? "MAP: WEBGL ERROR" : "MAP: INITIALIZING";
      }),
    [],
  );
  useEffect(() => {
    if (!vis) return;
    const id = setInterval(() => sfx.ping(), 11000);
    return () => clearInterval(id);
  }, [vis]);

  return (
    <section id="map" ref={ref} className={`relative h-[100svh] min-h-[640px] w-full border-y border-cyan-500/20 md:h-[92vh] ${vis ? "" : "is-off"}`}>
      <MapSlot mode="tactical" />
      <div className="pointer-events-none absolute inset-0 z-[3] bg-[radial-gradient(ellipse_at_center,transparent_55%,rgba(2,5,10,0.65)_100%)]" />
      {layers.satmode && <SatOverlay />}

      <div className="pointer-events-none absolute left-3 top-14 z-10 flex max-h-[calc(100%-7rem)] w-[min(320px,calc(100%-1.5rem))] flex-col gap-2 sm:left-5 sm:top-16">
        <div className="pointer-events-auto">
          <div className="hud-title mb-1 !text-[10px]">◢ TACTICAL-MAP // 04</div>
          <h2 className="font-display text-lg font-bold text-white sm:text-2xl">{L("ট্যাকটিক্যাল গ্লোব", "Tactical Globe", "الكرة التكتيكية")}</h2>
        </div>
        <details ref={panel} className="pointer-events-auto group min-h-0 flex-1 overflow-hidden" open>
          <summary className="hud cursor-pointer list-none bg-[#060a12]/95 px-3 py-2 text-[12px] font-semibold text-cyan-200 marker:hidden">
            <i className="hud-br tl" />
            <i className="hud-br tr" />
            ▾ {L("লাইভ ওএসআইএনটি লেয়ার", "LIVE OSINT LAYERS", "طبقات OSINT المباشرة")}
          </summary>
          <div className="hud mt-0 max-h-[52vh] space-y-1.5 overflow-y-auto bg-[#060a12]/95 p-2 no-scrollbar">
            <div className="hud-title px-1">{L("মূল লেয়ার", "CORE", "الأساسية")}</div>
            {BASE.map((d) => (
              <Toggle key={d.id} def={d} on={layers[d.id]} />
            ))}
            <div className="hud-title px-1 pt-1">{L("ওএসআইএনটি", "OSINT", "OSINT")}</div>
            {OSINT.map((d) => (
              <Toggle key={d.id} def={d} on={layers[d.id]} />
            ))}
            {layers.cables && <CableAlerts />}
            <button
              onClick={() => {
                sfx.lock();
                const on = !layers.satmode;
                setLayer("satmode", on);
                if (on) setLayer("spysat", true);
              }}
              className={`w-full border px-2 py-2 text-[12px] font-semibold ${layers.satmode ? "border-red-400 bg-red-500/20 text-red-100" : "border-orange-400/50 text-orange-200 hover:bg-orange-400/10"}`}
            >
              ⌖ {layers.satmode ? L("স্যাটেলাইট মোড বন্ধ করুন", "Disable satellite mode", "إيقاف وضع الأقمار") : L("স্যাটেলাইট নজরদারি মোড", "Satellite surveillance mode", "وضع مراقبة الأقمار")}
            </button>
          </div>
        </details>
      </div>

      <div className="pointer-events-none absolute bottom-16 right-3 z-10 hidden w-56 sm:block md:bottom-5 md:right-5">
        <Hud className="pointer-events-auto">
          <div className="hud-title mb-1">{L("ক্ষেত্র তথ্য", "FIELD DATA", "بيانات")}</div>
          <CoordReadout />
          <div className="mono mt-2 space-y-0.5 text-[11px]">
            <div ref={status} className="text-emerald-300">MAP: INITIALIZING</div>
            <div className="text-slate-400">
              ADS-B: <span className="text-cyan-200">{air.data ? air.data.airborne : "--"}</span> · MIL: <span className="text-orange-300">{air.data ? air.data.military : "--"}</span>
            </div>
          </div>
        </Hud>
      </div>
      <div className="pointer-events-none absolute bottom-16 left-3 z-10 hidden text-[10px] text-slate-400 sm:left-5 md:bottom-5 md:block">
        <span className="mono">
          <span className="text-[#fb923c]">▲</span> {L("সামরিক", "MIL", "عسكري")} · <span className="text-cyan-300">▪</span> {L("বেসামরিক", "CIV", "مدني")} · <span className="text-red-400">◎</span> {L("সংবাদ-ভিত্তিক লক্ষ্য", "NEWS-DERIVED TGT", "هدف")} · <span className="text-green-400">◆</span> SAT
        </span>
      </div>
    </section>
  );
}
