"use client";
import { useEffect, useRef, useState } from "react";
import { sfx } from "@/lib/audio";
import { GEO_BY_KEY } from "@/lib/geo";
import { useLang } from "@/lib/i18n";
import { useIntel } from "@/lib/intelStore";
import { PAIR_COUNTRIES, SCENARIOS, simulatePair, simulateScenario, type SimResult } from "@/lib/wargame";
import { Hud, Num, Section } from "./hud";

const col = (v: number) => (v < 30 ? "#4ade80" : v < 50 ? "#22d3ee" : v < 68 ? "#facc15" : v < 82 ? "#fb923c" : "#ef4444");

function Gauge({ label, v, tag }: { label: string; v: number; tag: string }) {
  const c = col(v);
  const dash = 2 * Math.PI * 42;
  return (
    <div className="flex items-center gap-3 border border-cyan-500/15 bg-black/30 p-3">
      <div className="relative h-24 w-24 shrink-0">
        <svg viewBox="0 0 100 100" className="h-full w-full -rotate-90">
          <circle cx="50" cy="50" r="42" fill="none" stroke="rgba(255,255,255,.07)" strokeWidth="7" />
          <circle cx="50" cy="50" r="42" fill="none" stroke={c} strokeWidth="7" strokeDasharray={dash} strokeDashoffset={dash * (1 - v / 100)} style={{ transition: "stroke-dashoffset 1.2s ease-out" }} />
        </svg>
        <div className="mono absolute inset-0 flex items-center justify-center text-2xl font-bold" style={{ color: c }}>{v}%</div>
      </div>
      <div>
        <div className="hud-title" style={{ color: `${c}cc` }}>{tag}</div>
        <div className="text-sm font-semibold text-white">{label}</div>
      </div>
    </div>
  );
}

export default function WarGame() {
  const { L, lang } = useLang();
  const intel = useIntel();
  const [mode, setMode] = useState<"flash" | "pair">("flash");
  const [sc, setSc] = useState(SCENARIOS[0].key);
  const [a, setA] = useState("russia");
  const [b, setB] = useState("ukraine");
  const [phase, setPhase] = useState<"idle" | "run" | "done">("idle");
  const [res, setRes] = useState<SimResult | null>(null);
  const [log, setLog] = useState<string[]>([]);
  const timers = useRef<ReturnType<typeof setTimeout>[]>([]);
  useEffect(() => () => timers.current.forEach(clearTimeout), []);

  const run = () => {
    if (mode === "pair" && a === b) return;
    sfx.lock();
    setPhase("run");
    setRes(null);
    const steps = [
      L("লাইভ সংবাদ-ডেটা সংগ্রহ…", "Ingesting live reporting…", "جمع البيانات"),
      L("সামরিক ভারসাম্য মডেল গণনা…", "Computing military balance model…", "نموذج التوازن"),
      L("সাপ্লাই-চেইন ও জ্বালানি ঝুঁকি বিশ্লেষণ…", "Analysing supply-chain & energy risk…", "تحليل الإمداد"),
      L("পারমাণবিক উত্তেজনা বৃদ্ধির হার নির্ণয়…", "Estimating nuclear escalation rate…", "تقدير التصعيد"),
    ];
    setLog([]);
    steps.forEach((s, i) => timers.current.push(setTimeout(() => { setLog((l) => [...l, s]); sfx.type(); }, i * 420)));
    timers.current.push(
      setTimeout(() => {
        setRes(mode === "flash" ? simulateScenario(intel, sc) : simulatePair(intel, a, b));
        setPhase("done");
        sfx.ping();
        sfx.holo();
      }, steps.length * 420 + 200),
    );
  };

  const T = <X extends { bn: string; en: string }>(x: X) => (lang === "bn" ? x.bn : x.en);
  const TA = (x: { bn: string[]; en: string[] }) => (lang === "bn" ? x.bn : x.en);
  const evidence = res ? (intel?.items.filter((i) => res.evidenceIds.includes(i.id)) ?? []) : [];
  const sel = "w-full border border-cyan-500/30 bg-[#060a12] px-2 py-2 text-sm text-slate-100 outline-none focus:border-cyan-300";

  return (
    <Section id="wargame" tag="◢ WAR-GAME // 13" title={L("এআই যুদ্ধ পরিস্থিতি সিমুলেটর", "AI War-Game Simulator", "محاكي الحرب بالذكاء الاصطناعي")} subtitle={L("দুটি দেশ বা ভূ-রাজনৈতিক ফ্ল্যাশপয়েন্ট বেছে নিন — লাইভ সংবাদের তীব্রতা ও নথিভুক্ত কাঠামোগত তথ্য মিলিয়ে ঝুঁকি-সূচক গণনা করা হয়। এটি পূর্বাভাস নয়, মডেল-ভিত্তিক অনুমান।", "Pick two countries or a flashpoint — live reporting intensity is blended with documented structural facts. Model-based estimate, not a prediction.", "اختر دولتين أو بؤرة توتر.")}>
      <div className="grid gap-4 lg:grid-cols-[360px_minmax(0,1fr)]">
        <Hud title={L("সিমুলেশন কনফিগারেশন", "SIMULATION CONFIG", "إعدادات المحاكاة")}>
          <div className="mb-3 grid grid-cols-2 gap-1">
            {(["flash", "pair"] as const).map((m) => (
              <button key={m} onClick={() => { sfx.click(); setMode(m); }} className={`border px-2 py-1.5 text-[12px] ${mode === m ? "border-cyan-300 bg-cyan-400/20 text-white" : "border-cyan-500/20 text-slate-400"}`}>
                {m === "flash" ? L("ফ্ল্যাশপয়েন্ট", "Flashpoint", "بؤرة") : L("দুই দেশ", "Two countries", "دولتان")}
              </button>
            ))}
          </div>
          {mode === "flash" ? (
            <label className="block text-[12px] text-slate-400">
              {L("ভূ-রাজনৈতিক ফ্ল্যাশপয়েন্ট", "Geopolitical flashpoint", "بؤرة التوتر")}
              <select value={sc} onChange={(e) => setSc(e.target.value)} className={sel + " mt-1"}>
                {SCENARIOS.map((s) => <option key={s.key} value={s.key}>{T(s)}</option>)}
              </select>
            </label>
          ) : (
            <div className="space-y-2">
              {[["A", a, setA], ["B", b, setB]].map(([lbl, val, setter]) => (
                <label key={lbl as string} className="block text-[12px] text-slate-400">
                  {L("দেশ", "Country", "دولة")} {lbl as string}
                  <select value={val as string} onChange={(e) => (setter as (v: string) => void)(e.target.value)} className={sel + " mt-1"}>
                    {PAIR_COUNTRIES.map((c) => <option key={c.key} value={c.key}>{lang === "bn" ? GEO_BY_KEY[c.key].nameBn : GEO_BY_KEY[c.key].name}</option>)}
                  </select>
                </label>
              ))}
              {a === b && <p className="text-xs text-orange-300">{L("দুটি ভিন্ন দেশ নির্বাচন করুন", "Select two different countries", "اختر دولتين مختلفتين")}</p>}
            </div>
          )}
          <button onClick={run} disabled={phase === "run" || (mode === "pair" && a === b)} className="mt-4 w-full border border-red-400 bg-red-500/15 py-3 text-sm font-bold text-red-100 transition hover:bg-red-500/30 disabled:opacity-50">
            ▶ {phase === "run" ? L("সিমুলেশন চলছে…", "Simulating…", "جارٍ المحاكاة") : L("সিমুলেশন রান করুন", "Run Simulation", "شغّل المحاكاة")}
          </button>
          <div className="mono mt-3 min-h-[84px] space-y-0.5 bg-black/50 p-2 text-[11px] text-emerald-300">
            {log.map((l, i) => <div key={i}><span className="text-cyan-500">&gt;</span> {l}</div>)}
            {phase === "run" && <span className="a-blink inline-block h-3 w-1.5 bg-emerald-300" />}
            {phase === "idle" && <span className="text-slate-600">{L("প্রস্তুত…", "standby…", "استعداد")}</span>}
          </div>
        </Hud>

        <Hud title={L("সিমুলেশন ফলাফল", "SIMULATION OUTPUT", "نتائج المحاكاة")} right={res ? <span className="mono text-[10px] text-emerald-400">COMPLETE</span> : undefined}>
          {!res ? (
            <div className="flex min-h-[320px] items-center justify-center text-center text-sm text-slate-500">
              {phase === "run" ? <span className="a-glow mono text-cyan-300">PROCESSING…</span> : L("পরিস্থিতি নির্বাচন করে “সিমুলেশন রান করুন” চাপুন।", "Select a scenario and press “Run Simulation”.", "اختر سيناريو ثم شغّل.")}
            </div>
          ) : (
            <div className="a-in space-y-4">
              <h3 className="font-display text-lg font-bold text-white sm:text-xl">{T(res.title)}</h3>
              <div className="grid gap-3 md:grid-cols-3">
                <Gauge tag="MILITARY-IMPACT" label={L("সম্ভাব্য সামরিক প্রভাব", "Military impact", "التأثير العسكري")} v={res.military} />
                <Gauge tag="ECON / OIL RISK" label={L("বৈশ্বিক অর্থনীতি ও জ্বালানি ঝুঁকি", "Global economy & energy risk", "الاقتصاد والطاقة")} v={res.econ} />
                <Gauge tag="NUCLEAR-ESCALATION" label={L("পারমাণবিক উত্তেজনা বৃদ্ধির হার", "Nuclear escalation rate", "تصعيد نووي")} v={res.escalation} />
              </div>
              <div className="grid gap-3 md:grid-cols-2">
                <div>
                  <div className="hud-title mb-1">{L("সামরিক প্রভাব", "MILITARY IMPACT", "التأثير العسكري")}</div>
                  <ul className="space-y-1 text-[13px] text-slate-200">{TA(res.military_txt).map((x, i) => <li key={i} className="flex gap-2"><span className="mono text-orange-400">▸</span>{x}</li>)}</ul>
                </div>
                <div>
                  <div className="hud-title mb-1">{L("সাপ্লাই চেইন / তেল ঝুঁকি", "SUPPLY CHAIN / OIL RISK", "سلاسل الإمداد")}</div>
                  <ul className="space-y-1 text-[13px] text-slate-200">{TA(res.econ_txt).map((x, i) => <li key={i} className="flex gap-2"><span className="mono text-cyan-400">▸</span>{x}</li>)}</ul>
                </div>
              </div>
              <div className="border-l-2 border-red-500/70 bg-red-500/5 p-2 text-[13px] text-slate-200">☢ {T(res.nuclear_txt)}</div>
              {res.fact && <p className="text-[12px] text-slate-400">ℹ {T(res.fact)}</p>}
              <div className="border-t border-cyan-500/15 pt-2">
                <div className="mono text-[11px] text-slate-400">
                  {L("লাইভ সংবাদ-তীব্রতা", "Live reporting intensity", "شدة التقارير")}: <Num className="text-cyan-200">{res.liveScore}/100</Num> · {L("সংশ্লিষ্ট প্রতিবেদন", "matching reports", "تقارير")}: <Num className="text-cyan-200">{res.evidence}</Num>
                </div>
                {evidence.length > 0 && (
                  <ul className="mt-1.5 space-y-1">
                    {evidence.map((e) => <li key={e.id} className="text-[12px] text-slate-300"><a href={e.url} target="_blank" rel="noreferrer" className="hover:text-white" dir="auto">▸ {e.titleT}</a> <span className="mono text-[10px] text-slate-500">· {e.source}</span></li>)}
                  </ul>
                )}
                <p className="mt-2 text-[11px] text-slate-500">{L("সতর্কতা: কাঠামোগত প্যারামিটারগুলো বিশ্লেষণধর্মী মডেল-অনুমান; ফলাফল ভবিষ্যদ্বাণী নয়।", "Note: structural parameters are analytical model assumptions; output is not a prediction.", "ملاحظة: النتائج ليست تنبؤات.")}</p>
              </div>
            </div>
          )}
        </Hud>
      </div>
    </Section>
  );
}
