"use client";
import { memo, useState } from "react";
import { sfx } from "@/lib/audio";
import { useLang } from "@/lib/i18n";
import { useIntelState } from "@/lib/intelStore";
import { CATEGORIES, CAT_LABEL, LEVEL_COLOR, LEVEL_LABEL, type CategoryKey, type Lang, type NewsItem, type PropagandaRisk } from "@/lib/types";
import { Ago, Empty, Hud, LevelBadge, Section } from "./hud";

const RISK: Record<PropagandaRisk, { bn: string; en: string; ar: string }> = {
  MIN: { bn: "সর্বনিম্ন", en: "Minimal", ar: "الأدنى" },
  LOW: { bn: "নিম্ন", en: "Low", ar: "منخفض" },
  MED: { bn: "মাঝারি", en: "Medium", ar: "متوسط" },
  HIGH: { bn: "উচ্চ", en: "High", ar: "مرتفع" },
};
const TIER: Record<number, { bn: string; en: string }> = {
  1: { bn: "আন্তর্জাতিক সংবাদ সংস্থা/পাবলিক সম্প্রচারক", en: "Wire service / public broadcaster" },
  2: { bn: "প্রধান গণমাধ্যম", en: "Major outlet" },
  3: { bn: "অচিহ্নিত/স্বতন্ত্র সূত্র", en: "Unclassified / independent source" },
  4: { bn: "রাষ্ট্র-সংশ্লিষ্ট গণমাধ্যম", en: "State-affiliated media" },
};

export const VerifyBadge = memo(function VerifyBadge({ item }: { item: NewsItem }) {
  const { lang, L } = useLang();
  const v = item.verification;
  const bad = v.unverified;
  const hi = v.risk === "HIGH";
  const color = bad ? (hi ? "#ef4444" : "#fb923c") : v.risk === "MED" ? "#facc15" : "#4ade80";
  return (
    <span className="inline-flex flex-wrap items-center gap-x-1.5 px-1.5 py-0.5 text-[11px] font-medium" style={{ color, border: `1px solid ${color}55`, background: `${color}10` }}>
      {bad ? (
        <>
          [{L("সতর্কতা: অসমর্থিত সূত্র", "WARNING: Unverified source", "تحذير: مصدر غير مؤكد")}
          <span className="mono">| {v.score}%</span>]
        </>
      ) : (
        <>
          [{L("সত্যতা যাচাইকৃত", "Verified", "تم التحقق")}: <span className="mono">{v.score}%</span> | {L("প্রোপাগান্ডা ঝুঁকি", "Propaganda risk", "خطر الدعاية")}: {RISK[v.risk][lang]}]
        </>
      )}
    </span>
  );
});

function bullets(it: NewsItem, lang: Lang): string[] {
  const b: string[] = [];
  const bn = lang === "bn";
  b.push(`${bn ? "শ্রেণি" : "Class"}: ${CAT_LABEL[it.category][lang]} — ${LEVEL_LABEL[it.level][lang]}`);
  if (it.geo.length) b.push(`${bn ? "সংশ্লিষ্ট অঞ্চল" : "Regions"}: ${it.geo.slice(0, 4).map((g) => (bn ? g.nameBn : g.name)).join(", ")}`);
  const t = TIER[it.verification.tier];
  b.push(`${bn ? "সূত্রের ধরন" : "Source type"}: ${bn ? t.bn : t.en}`);
  b.push(
    it.verification.corroboration > 0
      ? bn
        ? `${it.verification.corroboration}টি স্বাধীন সূত্রে অনুরূপ প্রতিবেদন`
        : `${it.verification.corroboration} independent source(s) report similar story`
      : bn
        ? "এখনও অন্য স্বাধীন সূত্রে সমর্থন পাওয়া যায়নি"
        : "No independent corroboration yet",
  );
  if (it.summaryT) b.push(it.summaryT.length > 190 ? it.summaryT.slice(0, 190) + "…" : it.summaryT);
  return b;
}

const NewsCard = memo(function NewsCard({ item, fresh, lang }: { item: NewsItem; fresh: boolean; lang: Lang }) {
  const [open, setOpen] = useState(false);
  const { L } = useLang();
  const c = LEVEL_COLOR[item.level];
  const status = item.verification.unverified ? L("অসমর্থিত", "Unverified", "غير مؤكد") : item.verification.corroboration > 0 ? L("যাচাইকৃত (একাধিক সূত্র)", "Verified (multi-source)", "مؤكد") : L("আংশিক যাচাই (একক নির্ভরযোগ্য সূত্র)", "Partially verified (single reliable source)", "تحقق جزئي");
  return (
    <article className={`relative border border-cyan-500/15 bg-[#060a12]/90 p-3 pl-4 ${fresh ? "a-new" : ""}`}>
      <span className="absolute inset-y-0 left-0 w-[3px]" style={{ background: c }} />
      <div className="flex flex-wrap items-center gap-2">
        <LevelBadge level={item.level} />
        <span className="border border-cyan-500/25 px-1.5 py-0.5 text-[11px] text-cyan-200">{CAT_LABEL[item.category][lang]}</span>
        {fresh && <span className="mono a-alert text-[10px] font-bold text-red-400">NEW</span>}
      </div>
      <h3 className="mt-2 text-[15px] font-semibold leading-snug text-white sm:text-base" dir="auto">
        {item.titleT}
      </h3>
      {lang !== "en" && item.title !== item.titleT && (
        <p className="mono mt-1 text-[11px] leading-snug text-slate-500" dir="ltr">
          {item.title}
        </p>
      )}
      <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-[12px] text-slate-400">
        <span>
          {L("উৎস", "Source", "المصدر")}: <a href={item.url} target="_blank" rel="noreferrer" className="mono text-cyan-300 hover:underline">{item.source}</a>
          <span className="mono text-slate-600"> · {item.via}</span>
        </span>
        <span><Ago iso={item.publishedAt} /></span>
        <span className="mono text-[11px] text-slate-500">{item.publishedAt.slice(0, 16).replace("T", " ")}Z</span>
      </div>
      <div className="mt-2 flex flex-wrap items-center gap-2">
        <VerifyBadge item={item} />
        <span className="text-[11px] text-slate-400">{L("যাচাই স্থিতি", "Status", "الحالة")}: <span className="text-slate-200">{status}</span></span>
        <button
          onClick={() => {
            sfx.click();
            setOpen((o) => !o);
          }}
          className="ml-auto border border-cyan-500/30 px-2 py-0.5 text-[11px] text-cyan-200 hover:bg-cyan-400/10"
        >
          {open ? L("সারসংক্ষেপ লুকান", "Hide summary", "إخفاء") : L("এআই সারসংক্ষেপ", "AI summary", "ملخص")}
        </button>
      </div>
      {open && (
        <div className="a-in mt-2 border-t border-cyan-500/15 pt-2">
          <div className="hud-title mb-1">{L("মূল বিশ্লেষণ", "KEY ANALYSIS", "التحليل الرئيسي")}</div>
          <ul className="space-y-1 text-[13px] text-slate-300">
            {bullets(item, lang).map((x, i) => (
              <li key={i} className="flex gap-2">
                <span className="mono text-cyan-400">▸</span>
                <span>{x}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </article>
  );
});

const LiveFeed = memo(function LiveFeed({ items, fresh }: { items: NewsItem[]; fresh: ReadonlySet<string> }) {
  const { lang } = useLang();
  return (
    <div className="mono h-[360px] overflow-y-auto bg-black/60 p-3 text-[11.5px] leading-relaxed no-scrollbar">
      {items.slice(0, 22).map((it) => (
        <div key={it.id} className={`mb-1.5 ${fresh.has(it.id) ? "a-new" : ""}`}>
          <span className="text-slate-500">[{it.publishedAt.slice(11, 19)}]</span>{" "}
          <span style={{ color: LEVEL_COLOR[it.level] }}>{it.level.padEnd(8, " ")}</span>{" "}
          <span className="text-cyan-300">{it.category.toUpperCase()}</span>
          <span className="text-slate-500"> › </span>
          <span className="font-sans text-slate-200" dir="auto">{it.titleT}</span>
          <span className="text-slate-600"> @{it.source}</span>
        </div>
      ))}
      <span className="a-blink inline-block h-3 w-1.5 bg-emerald-300 align-middle" />
      <span className="sr-only">{lang}</span>
    </div>
  );
});

const NOTE: Record<string, { bn: string; en: string }> = {
  nokey: { bn: "API কী কনফিগার করা নেই", en: "API key not configured" },
  error: { bn: "সংযোগ ব্যর্থ", en: "Connection failed" },
  ratelimit: { bn: "রেট লিমিট — পরে আবার চেষ্টা", en: "Rate-limited — retrying" },
  empty: { bn: "কোনো ফলাফল নেই", en: "No results" },
};

export default function NewsSection() {
  const { lang, L } = useLang();
  const { intel, fresh } = useIntelState();
  const [cat, setCat] = useState<CategoryKey | "all">("all");
  const [limit, setLimit] = useState(10);
  const items = (intel?.items ?? []).filter((i) => cat === "all" || i.category === cat);

  return (
    <Section
      id="news"
      tag="◢ INTEL-FEED // 03"
      title={L("ব্রেকিং ইন্টেলিজেন্স সিস্টেম", "Breaking Intelligence System", "نظام الاستخبارات العاجلة")}
      subtitle={L(
        "BBC, Reuters, AP, Al Jazeera ও GDELT থেকে সংগৃহীত প্রকৃত শিরোনাম — স্বয়ংক্রিয় অনুবাদ, হুমকি শ্রেণিবিন্যাস ও সত্যতা যাচাই সহ।",
        "Real headlines from BBC, Reuters, AP, Al Jazeera and GDELT — auto-translated, threat-classified and source-verified.",
        "عناوين حقيقية من BBC وReuters وAP والجزيرة وGDELT مع الترجمة والتصنيف والتحقق.",
      )}
    >
      <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_380px]">
        <div>
          <div className="mb-3 flex flex-wrap gap-1.5">
            <button onClick={() => { sfx.click(); setCat("all"); }} className={`border px-2.5 py-1 text-xs ${cat === "all" ? "border-cyan-300 bg-cyan-400/20 text-white" : "border-cyan-500/20 text-slate-400"}`}>
              {L("সব", "All", "الكل")} <span className="mono">{intel?.items.length ?? 0}</span>
            </button>
            {CATEGORIES.map((c) => (
              <button key={c} onClick={() => { sfx.click(); setCat(c); }} className={`border px-2.5 py-1 text-xs ${cat === c ? "border-cyan-300 bg-cyan-400/20 text-white" : "border-cyan-500/20 text-slate-400 hover:text-cyan-200"}`}>
                {CAT_LABEL[c][lang]} <span className="mono">{intel?.stats.byCategory[c] ?? 0}</span>
              </button>
            ))}
          </div>
          {!intel ? (
            <Empty>{L("লাইভ উৎস থেকে তথ্য সংগ্রহ ও অনুবাদ চলছে…", "Collecting and translating from live sources…", "جارٍ الجمع والترجمة…")}</Empty>
          ) : items.length === 0 ? (
            <Empty>{L("এই শ্রেণিতে বর্তমানে কোনো প্রতিবেদন নেই।", "No current reports in this category.", "لا توجد تقارير حالية.")}</Empty>
          ) : (
            <div className="space-y-2.5">
              {items.slice(0, limit).map((it) => (
                <NewsCard key={it.id} item={it} fresh={fresh.has(it.id)} lang={lang} />
              ))}
              {items.length > limit && (
                <button onClick={() => setLimit((l) => l + 10)} className="w-full border border-cyan-500/30 py-2 text-sm text-cyan-200 hover:bg-cyan-400/10">
                  {L("আরও দেখুন", "Show more", "عرض المزيد")} (<span className="mono">{items.length - limit}</span>)
                </button>
              )}
            </div>
          )}
        </div>

        <div className="space-y-4">
          <Hud title={L("টার্মিনাল লাইভ ফিড", "TERMINAL LIVE FEED", "البث الطرفي المباشر")} right={<span className="mono text-[10px] text-emerald-400">● STREAM</span>} pad={false}>
            <LiveFeed items={intel?.items ?? []} fresh={fresh} />
          </Hud>
          <Hud title={L("সোর্স স্ট্যাটাস", "SOURCE STATUS", "حالة المصادر")}>
            <ul className="space-y-1.5 text-[13px]">
              {(intel?.sources ?? []).map((s) => (
                <li key={s.name} className="flex items-center justify-between gap-2">
                  <span className="flex items-center gap-2">
                    <span className="h-2 w-2" style={{ background: s.ok ? "#4ade80" : s.note === "nokey" ? "#64748b" : "#ef4444" }} />
                    <span className="mono text-slate-200">{s.name}</span>
                  </span>
                  <span className="text-[11px] text-slate-400">
                    {s.ok ? (
                      <>
                        <span className="mono">{s.count}</span> {L("আইটেম", "items", "عنصر")}
                      </>
                    ) : (
                      NOTE[s.note ?? "error"]?.[lang === "bn" ? "bn" : "en"]
                    )}
                  </span>
                </li>
              ))}
            </ul>
            <p className="mt-3 border-t border-cyan-500/15 pt-2 text-[11px] leading-relaxed text-slate-500">
              {L(
                "সত্যতা স্কোর = সূত্রের নির্ভরযোগ্যতা স্তর + স্বাধীন সূত্রের সমর্থন। রাষ্ট্র-সংশ্লিষ্ট মিডিয়া স্বয়ংক্রিয়ভাবে উচ্চ প্রোপাগান্ডা ঝুঁকিতে চিহ্নিত হয়। এটি সূত্র-ভিত্তিক মূল্যায়ন, ছবি/ভিডিও ডিপফেক শনাক্তকরণ নয়।",
                "Verification = source reliability tier + independent corroboration. State-affiliated media is auto-flagged as high propaganda risk. This is source-based assessment, not pixel-level deepfake detection.",
                "التحقق = موثوقية المصدر + التأكيد المستقل.",
              )}
            </p>
          </Hud>
        </div>
      </div>
    </Section>
  );
}
