"use client";
import { memo } from "react";
import { useLang } from "@/lib/i18n";
import { useIntel } from "@/lib/intelStore";
import { LEVEL_COLOR, LEVEL_LABEL } from "@/lib/types";

/** Scrolling intelligence bar: transform-only marquee fed by real, translated headlines. */
const Ticker = memo(function Ticker() {
  const intel = useIntel();
  const { L, lang } = useLang();
  const all = intel?.items ?? [];
  const items = [...all.filter((i) => i.level !== "LOW").slice(0, 10), ...all.filter((i) => i.level === "LOW").slice(0, 6)];
  const hot = items.some((i) => i.level === "HIGH" || i.level === "CRITICAL");
  return (
    <div className="flex h-6 items-center overflow-hidden">
      <div className={`z-10 flex h-full shrink-0 items-center gap-1.5 bg-[#060a12] pe-2 text-[11px] font-bold ${hot ? "text-red-400" : "text-cyan-300"}`}>
        <span className={`h-2 w-2 ${hot ? "a-alert bg-red-500" : "bg-cyan-400"}`} />
        {L("ব্রেকিং", "BREAKING", "عاجل")}
      </div>
      <div className="relative min-w-0 flex-1 overflow-hidden">
        {items.length === 0 ? (
          <div className="mono text-[11px] text-slate-500">{L("লাইভ উৎস থেকে তথ্য সংগ্রহ চলছে…", "Collecting from live sources…", "جارٍ جمع البيانات…")}</div>
        ) : (
          <div className="a-marquee flex w-max items-center whitespace-nowrap" style={{ animationDuration: `${items.length * 9}s` }}>
            {[0, 1].map((k) => (
              <div key={k} className="flex items-center" aria-hidden={k === 1}>
                {items.map((it) => (
                  <a key={`${k}-${it.id}`} href={it.url} target="_blank" rel="noreferrer" className="mx-5 flex items-center gap-2 text-[12px] text-slate-200 hover:text-white">
                    <span className="mono text-[10px] font-bold" style={{ color: LEVEL_COLOR[it.level] }}>
                      [{LEVEL_LABEL[it.level][lang]}]
                    </span>
                    <span>{it.titleT}</span>
                    <span className="mono text-[10px] text-slate-500">— {it.source}</span>
                  </a>
                ))}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
});
export default Ticker;
