"use client";
import { memo } from "react";
import { scrollToId } from "@/lib/commands";
import { THEATRES } from "@/lib/geo";
import { useLang } from "@/lib/i18n";
import { setLayer } from "@/lib/layers";
import { useOsint } from "@/lib/osintStore";
import { Empty, Hud, Section, useInView } from "./hud";

interface Pt {
  key: string;
  temp: number | null;
  cloud: number | null;
  vis: number | null;
  wind: number | null;
  gust: number | null;
  precip: number | null;
  code: number;
}

function cond(code: number): { bn: string; en: string; icon: string } {
  if (code === 0) return { bn: "পরিষ্কার আকাশ", en: "Clear sky", icon: "☀" };
  if (code <= 3) return { bn: "আংশিক মেঘলা", en: "Partly cloudy", icon: "⛅" };
  if (code === 45 || code === 48) return { bn: "কুয়াশা", en: "Fog", icon: "🌫" };
  if (code <= 57) return { bn: "গুঁড়ি বৃষ্টি", en: "Drizzle", icon: "🌦" };
  if (code <= 67) return { bn: "বৃষ্টি", en: "Rain", icon: "🌧" };
  if (code <= 77) return { bn: "তুষারপাত", en: "Snow", icon: "❄" };
  if (code <= 82) return { bn: "ঝড়ো বৃষ্টি", en: "Showers", icon: "🌧" };
  if (code <= 86) return { bn: "তুষার-ঝড়", en: "Snow showers", icon: "❄" };
  return { bn: "বজ্রঝড়", en: "Thunderstorm", icon: "⛈" };
}

function effects(p: Pt, bn: boolean): { text: string; c: string }[] {
  const out: { text: string; c: string }[] = [];
  if (p.vis != null && p.vis < 3000) out.push({ text: bn ? "দৃশ্যমানতা কম — আকাশ/ড্রোন পর্যবেক্ষণ সীমিত" : "Low visibility — air/drone observation limited", c: "#fb923c" });
  if ((p.cloud ?? 0) > 80) out.push({ text: bn ? "ঘন মেঘ — অপটিক্যাল স্যাটেলাইট ইমেজিং বাধাগ্রস্ত (SAR/IR কার্যকর)" : "Heavy cloud — optical satellite imaging obstructed (SAR/IR still works)", c: "#facc15" });
  if ((p.gust ?? p.wind ?? 0) > 45) out.push({ text: bn ? "প্রবল বাতাস — ড্রোন ও হেলিকপ্টার অভিযান ঝুঁকিপূর্ণ" : "Strong winds — drone/helicopter ops hazardous", c: "#ef4444" });
  if ((p.precip ?? 0) > 1.5) out.push({ text: bn ? "বৃষ্টি — ভারী যান চলাচল ও সরবরাহ ধীর" : "Rain — heavy vehicle movement and logistics slowed", c: "#38bdf8" });
  if (p.temp != null && p.temp < -5) out.push({ text: bn ? "তীব্র ঠান্ডা — সরঞ্জাম ও সেনা সহনশীলতায় চাপ" : "Severe cold — strain on equipment and personnel", c: "#93c5fd" });
  if (p.temp != null && p.temp > 38) out.push({ text: bn ? "তীব্র গরম — সেনা ও যন্ত্রের অতিরিক্ত তাপচাপ" : "Extreme heat — thermal stress on troops and machinery", c: "#f97316" });
  if (!out.length) out.push({ text: bn ? "অপারেশনাল আবহাওয়া অনুকূল" : "Operational weather favourable", c: "#4ade80" });
  return out;
}

const Cell = memo(function Cell({ p, bn, lang }: { p: Pt; bn: boolean; lang: "bn" | "en" | "ar" }) {
  const t = THEATRES.find((x) => x.key === p.key)!;
  const c = cond(p.code);
  const fx = effects(p, bn);
  const cloud = p.cloud ?? 0;
  return (
    <Hud className="h-full">
      <div className="pointer-events-none absolute inset-0 overflow-hidden opacity-70">
        <div className="a-marquee absolute -top-4 left-0 h-14 w-[200%]" style={{ opacity: cloud / 160, background: "radial-gradient(ellipse at 20% 50%, rgba(200,220,255,.5), transparent 40%), radial-gradient(ellipse at 60% 40%, rgba(200,220,255,.4), transparent 35%), radial-gradient(ellipse at 90% 60%, rgba(200,220,255,.5), transparent 40%)", animationDuration: "70s" }} />
      </div>
      <div className="relative">
        <div className="flex items-start justify-between gap-2">
          <div>
            <div className="text-[13px] font-semibold text-white">{t[lang]}</div>
            <div className="text-[12px] text-slate-400">{bn ? c.bn : c.en}</div>
          </div>
          <div className="text-2xl">{c.icon}</div>
        </div>
        <div className="mono mt-2 grid grid-cols-4 gap-1 text-center text-[11px]">
          {[
            ["TEMP", p.temp != null ? `${p.temp.toFixed(0)}°` : "--"],
            ["CLOUD", `${cloud.toFixed(0)}%`],
            ["VIS", p.vis != null ? `${(p.vis / 1000).toFixed(1)}km` : "--"],
            ["WIND", p.wind != null ? `${p.wind.toFixed(0)}` : "--"],
          ].map(([k, v]) => (
            <div key={k} className="border border-cyan-500/15 bg-black/30 py-1">
              <div className="text-[9px] text-slate-500">{k}</div>
              <div className="text-cyan-100">{v}</div>
            </div>
          ))}
        </div>
        <ul className="mt-2 space-y-1">
          {fx.map((f, i) => (
            <li key={i} className="flex gap-1.5 text-[12px] leading-snug" style={{ color: f.c }}>
              <span className="mono">▸</span>
              {f.text}
            </li>
          ))}
        </ul>
      </div>
    </Hud>
  );
});

export default function WeatherPanel() {
  const { L, lang } = useLang();
  const [ref, vis] = useInView<HTMLDivElement>("0px");
  const v = useOsint<{ points: Pt[] }>("weather", 600000, { enabled: vis });
  return (
    <Section id="weather" tag="◢ WAR-WEATHER // 16" title={L("আবহাওয়া ও যুদ্ধক্ষেত্র ওভারলে", "Weather + War Overlay", "الطقس وساحة المعركة")} subtitle={L("Open-Meteo থেকে প্রকৃত বর্তমান আবহাওয়া—সংঘাত অঞ্চলে দৃশ্যমানতা, মেঘ, বাতাস ও অভিযানের ওপর সম্ভাব্য প্রভাব।", "Live Open-Meteo conditions over conflict theatres — visibility, cloud, wind and likely operational effects.", "طقس حي")}>
      <div ref={ref}>
        {!v.data ? (
          <Empty>{v.error ? L("আবহাওয়া ডেটা অনুপলব্ধ", "Weather data unavailable", "غير متاح") : L("আবহাওয়া ডেটা লোড হচ্ছে…", "Loading weather…", "تحميل")}</Empty>
        ) : (
          <>
            <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
              {v.data.points.map((p) => (
                <Cell key={p.key} p={p} bn={lang === "bn"} lang={lang} />
              ))}
            </div>
            <button onClick={() => { setLayer("weather", true); scrollToId("map"); }} className="mt-3 border border-sky-400/50 px-3 py-1.5 text-[12px] text-sky-200 hover:bg-sky-400/10">☁ {L("ম্যাপে আবহাওয়া ওভারলে দেখুন", "Show weather overlay on map", "عرض الطقس على الخريطة")}</button>
          </>
        )}
      </div>
    </Section>
  );
}
