"use client";
import { memo, useEffect, useRef } from "react";
import { setMuted, sfx, useMuted } from "@/lib/audio";
import { scrollToId, setVision, useVision, type Vision } from "@/lib/commands";
import { useLang } from "@/lib/i18n";
import { useIntelState } from "@/lib/intelStore";
import type { Lang } from "@/lib/types";
import Ticker from "./Ticker";

/** Isolated 1 Hz clock: writes to the DOM directly so nothing else re-renders. */
const Clock = memo(function Clock() {
  const ref = useRef<HTMLSpanElement>(null);
  useEffect(() => {
    const tick = () => {
      if (!ref.current) return;
      const d = new Date();
      ref.current.textContent = d.toISOString().slice(11, 19) + "Z";
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);
  return (
    <span className="mono text-[13px] text-cyan-200">
      UTC <span ref={ref}>--:--:--Z</span>
    </span>
  );
});

const VISIONS: { id: Vision; code: string; bn: string; en: string; ar: string }[] = [
  { id: "std", code: "STD", bn: "সাধারণ স্যাটেলাইট", en: "Standard Satellite", ar: "قمر صناعي عادي" },
  { id: "nvg", code: "NVG", bn: "নাইট ভিশন", en: "Night Vision", ar: "رؤية ليلية" },
  { id: "flir", code: "FLIR", bn: "থার্মাল ক্যামেরা", en: "FLIR Thermal", ar: "كاميرا حرارية" },
  { id: "crt", code: "CRT", bn: "ট্যাকটিক্যাল রাডার", en: "Tactical Radar", ar: "رادار تكتيكي" },
];

const VisionSwitcher = memo(function VisionSwitcher() {
  const v = useVision();
  const { L, lang } = useLang();
  return (
    <div className="flex items-center gap-1" role="group" aria-label="vision mode">
      <span className="hud-title mr-1 hidden xl:inline">{L("অপটিক্যাল মোড", "OPTICS", "البصريات")}</span>
      {VISIONS.map((x) => (
        <button
          key={x.id}
          onClick={() => {
            setVision(x.id);
            sfx.lock();
          }}
          title={`${x[lang]} (${x.code})`}
          className={`border px-2 py-1 text-[11px] leading-none transition-colors ${v === x.id ? "border-cyan-300 bg-cyan-400/20 text-cyan-100" : "border-cyan-500/20 text-slate-400 hover:border-cyan-400/60 hover:text-cyan-200"}`}
        >
          <span className="hidden xl:inline">{x[lang]} </span>
          <span className="mono text-[10px] xl:opacity-70">{`${lang === "bn" ? "(" : "["}${x.code}${lang === "bn" ? ")" : "]"}`}</span>
        </button>
      ))}
    </div>
  );
});

const AudioToggle = memo(function AudioToggle() {
  const muted = useMuted();
  const { L } = useLang();
  return (
    <button
      onClick={() => {
        setMuted(!muted);
        if (muted) sfx.ping();
      }}
      className={`border px-2 py-1 text-[11px] leading-none ${muted ? "border-red-500/40 text-red-300" : "border-emerald-400/40 text-emerald-300"}`}
      aria-pressed={!muted}
    >
      [{L("অডিও", "AUDIO", "الصوت")}: {muted ? L("বন্ধ", "OFF", "إيقاف") : L("চালু", "ON", "تشغيل")}]
    </button>
  );
});

const LangSwitch = memo(function LangSwitch() {
  const { lang, setLang } = useLang();
  const items: [Lang, string][] = [
    ["bn", "বাংলা"],
    ["en", "EN"],
    ["ar", "عربي"],
  ];
  return (
    <div className="flex">
      {items.map(([k, label]) => (
        <button
          key={k}
          onClick={() => {
            sfx.click();
            setLang(k);
          }}
          className={`border px-2 py-1 text-[11px] leading-none ${lang === k ? "border-cyan-300 bg-cyan-400/20 text-white" : "border-cyan-500/20 text-slate-400 hover:text-cyan-200"}`}
        >
          {label}
        </button>
      ))}
    </div>
  );
});

const LiveStatus = memo(function LiveStatus() {
  const { conn } = useIntelState();
  const { L } = useLang();
  const color = conn === "live" ? "#4ade80" : conn === "connecting" ? "#facc15" : "#ef4444";
  return (
    <span className="flex items-center gap-1.5 text-[11px] text-slate-300">
      <span className="h-2 w-2 a-alert" style={{ background: color }} />
      {conn === "live" ? L("লাইভ", "LIVE", "مباشر") : conn === "connecting" ? L("সংযোগ হচ্ছে", "LINKING", "جارٍ الاتصال") : L("অফলাইন", "OFFLINE", "غير متصل")}
    </span>
  );
});

const NAV: [string, string, string, string][] = [
  ["news", "ব্রেকিং", "Breaking", "عاجل"],
  ["map", "ট্যাকটিক্যাল ম্যাপ", "Tactical Map", "الخريطة"],
  ["dashboard", "ড্যাশবোর্ড", "Dashboard", "لوحة"],
  ["analysis", "এআই বিশ্লেষণ", "AI Analysis", "تحليل"],
  ["wargame", "সিমুলেটর", "Simulator", "محاكاة"],
  ["cyber", "সাইবার", "Cyber", "سيبراني"],
  ["timeline", "টাইমলাইন", "Timeline", "الجدول"],
];

export default function TopBar() {
  const { L } = useLang();
  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-cyan-500/20 bg-[#060a12]/90 backdrop-blur-sm">
      <div className="flex h-11 items-center gap-3 px-3 sm:px-5">
        <button onClick={() => scrollToId("hero")} className="flex items-center gap-2" aria-label="PAVEL WAR ROOM">
          <span className="relative block h-6 w-6">
            <span className="absolute inset-0 border border-cyan-400/80 a-sweep-slow" style={{ clipPath: "polygon(0 0,100% 0,100% 40%,0 40%)" }} />
            <span className="absolute inset-[5px] bg-cyan-400/90 a-glow" />
          </span>
          <span className="font-display text-[13px] font-bold tracking-[0.18em] text-white sm:text-sm">
            PAVEL <span className="text-cyan-300">WAR ROOM</span>
          </span>
        </button>
        <nav className="ml-4 hidden items-center gap-0.5 lg:flex">
          {NAV.map(([id, bn, en, ar]) => (
            <button key={id} onClick={() => { sfx.click(); scrollToId(id); }} className="px-2.5 py-1 text-[12px] text-slate-300 hover:bg-cyan-400/10 hover:text-cyan-100">
              {L(bn, en, ar)}
            </button>
          ))}
        </nav>
        <div className="ml-auto flex items-center gap-3">
          <LiveStatus />
          <span className="hidden sm:inline">
            <Clock />
          </span>
          <AudioToggle />
          <LangSwitch />
        </div>
      </div>
      <div className="flex items-center gap-3 border-t border-cyan-500/10 bg-black/30 px-3 py-1 sm:px-5">
        <VisionSwitcher />
        <div className="hidden min-w-0 flex-1 lg:block">
          <Ticker />
        </div>
      </div>
      <div className="border-t border-cyan-500/10 lg:hidden">
        <Ticker />
      </div>
    </header>
  );
}
