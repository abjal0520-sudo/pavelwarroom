"use client";
import { useEffect, useState } from "react";
import { scrollToId } from "@/lib/commands";
import { useLang } from "@/lib/i18n";
import { onAlert } from "@/lib/intelStore";
import { CAT_LABEL, LEVEL_COLOR, LEVEL_LABEL, type NewsItem } from "@/lib/types";

/** Flashing breaking-alert indicator for newly detected HIGH / CRITICAL reports. */
export default function AlertToast() {
  const { lang, L } = useLang();
  const [items, setItems] = useState<NewsItem[]>([]);
  const [flash, setFlash] = useState(false);

  useEffect(
    () =>
      onAlert((a) => {
        setItems((cur) => [...a.slice(0, 2), ...cur].slice(0, 3));
        setFlash(true);
        setTimeout(() => setFlash(false), 1800);
        setTimeout(() => setItems((cur) => cur.filter((x) => !a.some((y) => y.id === x.id))), 12000);
      }),
    [],
  );

  return (
    <>
      {flash && <div className="a-alert pointer-events-none fixed inset-0 z-[80] border-4 border-red-500/60" />}
      <div className="pointer-events-none fixed right-3 top-[104px] z-[70] flex w-[min(380px,calc(100vw-1.5rem))] flex-col gap-2 lg:top-[84px]">
        {items.map((it) => (
          <button key={it.id} onClick={() => scrollToId("news")} className="hud a-new pointer-events-auto bg-[#0a0508] p-3 text-left" style={{ borderColor: `${LEVEL_COLOR[it.level]}88` }}>
            <i className="hud-br tl" style={{ borderColor: LEVEL_COLOR[it.level] }} />
            <i className="hud-br brr" style={{ borderColor: LEVEL_COLOR[it.level] }} />
            <div className="flex items-center gap-2 text-[11px] font-bold" style={{ color: LEVEL_COLOR[it.level] }}>
              <span className="a-alert h-2 w-2" style={{ background: LEVEL_COLOR[it.level] }} />
              {L("নতুন সতর্কতা", "NEW ALERT", "تنبيه جديد")} · [{LEVEL_LABEL[it.level][lang]}] · {CAT_LABEL[it.category][lang]}
            </div>
            <div className="mt-1 text-[13px] leading-snug text-white" dir="auto">{it.titleT}</div>
            <div className="mono mt-1 text-[10px] text-slate-500">{it.source}</div>
          </button>
        ))}
      </div>
    </>
  );
}
