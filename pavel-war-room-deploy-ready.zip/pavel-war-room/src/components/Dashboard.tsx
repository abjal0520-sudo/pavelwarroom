"use client";
import { memo, useEffect, useRef, useState } from "react";
import { useLang } from "@/lib/i18n";
import { useIntel } from "@/lib/intelStore";
import { useOsint } from "@/lib/osintStore";
import { LEVEL_COLOR, LEVEL_LABEL } from "@/lib/types";
import { AnimNum, Hud, Section, Sparkline, useInView } from "./hud";

const Card = memo(function Card({ title, tag, value, suffix, color, series, sub, icon }: { title: string; tag: string; value: number | null; suffix?: string; color: string; series: number[]; sub?: React.ReactNode; icon: string }) {
  return (
    <div className="relative min-w-[78%] snap-center sm:min-w-0">
      <Hud accent={color} className="h-full">
        <div className="pointer-events-none absolute inset-0 a-glow" style={{ background: `linear-gradient(180deg, ${color}12, transparent 60%)` }} />
        <div className="relative flex items-start justify-between">
          <div>
            <div className="hud-title" style={{ color: `${color}cc` }}>{tag}</div>
            <div className="mt-1 text-[13px] font-semibold text-slate-200">{title}</div>
          </div>
          <div className="relative h-10 w-10 shrink-0">
            <div className="a-sweep absolute inset-0 rounded-full border border-dashed" style={{ borderColor: `${color}88` }} />
            <div className="absolute inset-0 flex items-center justify-center text-base" style={{ color }}>{icon}</div>
          </div>
        </div>
        <div className="relative mt-2 flex items-end gap-2">
          {value == null ? <span className="mono text-3xl font-bold text-slate-500">--</span> : <AnimNum value={value} suffix={suffix} className="text-4xl font-bold text-white" />}
          <span className="mb-1.5 h-2 w-2 a-alert" style={{ background: color }} />
        </div>
        <div className="relative mt-1 h-4 text-[11px] text-slate-400">{sub}</div>
        <div className="relative mt-1">
          <Sparkline data={series.length ? series : new Array(24).fill(0)} color={color} />
          <div className="mono flex justify-between text-[9px] text-slate-600">
            <span>-24h</span>
            <span>NOW</span>
          </div>
        </div>
      </Hud>
    </div>
  );
});

export default function Dashboard() {
  const { L, lang } = useLang();
  const intel = useIntel();
  const [ref, vis] = useInView<HTMLDivElement>("0px");
  const air = useOsint<{ airborne: number; military: number; emergencies: number; fetchedAt: number }>("aircraft", 45000, { enabled: vis });
  const hist = useRef<number[]>([]);
  const [airSeries, setAirSeries] = useState<number[]>([]);
  useEffect(() => {
    if (air.data) {
      hist.current = [...hist.current, air.data.airborne].slice(-24);
      setAirSeries(hist.current);
    }
  }, [air.version, air.data]);

  const s = intel?.stats;
  const ser = intel?.series;
  return (
    <Section id="dashboard" tag="◢ THREAT-BOARD // 08" title={L("গ্লোবাল থ্রেট ড্যাশবোর্ড", "Global Threat Dashboard", "لوحة التهديدات العالمية")} subtitle={L("প্রতিটি কার্ড লাইভ সংবাদ-ডেটা ও সেন্সর ফিড থেকে গণনা করা হয়।", "Every card is computed from live reporting and sensor feeds.", "تُحسب كل بطاقة من بيانات حية.")}>
      <div ref={ref} className="no-scrollbar -mx-3 flex snap-x snap-mandatory gap-3 overflow-x-auto px-3 pb-2 sm:mx-0 sm:grid sm:grid-cols-2 sm:overflow-visible sm:px-0 lg:grid-cols-4">
        <Card icon="⚔" tag="ACTIVE-CONFLICTS" title={L("সক্রিয় সংঘাত", "Active Conflicts", "النزاعات النشطة")} value={s?.activeConflicts ?? null} color="#ef4444" series={ser?.all ?? []} sub={L("শনাক্ত সংঘাত অঞ্চল", "detected zones", "مناطق")} />
        <Card icon="◎" tag="MISSILE-ALERT" title={L("ক্ষেপণাস্ত্র সতর্কতা", "Missile Alerts", "تنبيهات الصواريخ")} value={s ? s.byCategory.missile : null} color="#fb923c" series={ser?.missile ?? []} sub={L("গত ২৪ ঘণ্টার প্রতিবেদন", "reports, last 24h", "تقارير 24 ساعة")} />
        <Card icon="⌁" tag="CYBER-ATTACK" title={L("সাইবার হামলা", "Cyber Attacks", "هجمات سيبرانية")} value={s ? s.byCategory.cyber : null} color="#a78bfa" series={ser?.cyber ?? []} sub={L("গত ২৪ ঘণ্টার প্রতিবেদন", "reports, last 24h", "تقارير 24 ساعة")} />
        <Card
          icon="✈"
          tag="AIR-ACTIVITY"
          title={L("বিমান কার্যক্রম", "Air Activity", "النشاط الجوي")}
          value={air.data ? air.data.airborne : null}
          color="#22d3ee"
          series={airSeries}
          sub={air.data ? <span>{L("সামরিক শনাক্ত", "military flagged", "عسكري")}: <span className="mono text-orange-300">{air.data.military}</span> · {L("জরুরি স্কোয়াক", "emerg.", "طوارئ")}: <span className="mono text-red-300">{air.data.emergencies}</span></span> : air.error ? L("OpenSky পাওয়া যায়নি", "OpenSky unavailable", "غير متاح") : L("OpenSky লোড হচ্ছে", "loading OpenSky", "تحميل")}
        />
        <Card icon="⚓" tag="NAVAL-MOVEMENT" title={L("নৌবাহিনী চলাচল", "Naval Movement", "التحركات البحرية")} value={s ? s.byCategory.naval : null} color="#38bdf8" series={ser?.naval ?? []} sub={L("গত ২৪ ঘণ্টার প্রতিবেদন", "reports, last 24h", "تقارير 24 ساعة")} />
        <Card icon="☢" tag="NUCLEAR-RISK" title={L("পারমাণবিক ঝুঁকি", "Nuclear Risk", "الخطر النووي")} value={s ? s.nuclearIndex : null} suffix="" color={s ? LEVEL_COLOR[s.nuclearLevel] : "#facc15"} series={ser?.nuclear ?? []} sub={s ? <span style={{ color: LEVEL_COLOR[s.nuclearLevel] }}>{LEVEL_LABEL[s.nuclearLevel][lang]} · <span className="mono">{s.nuclearLevel}</span></span> : null} />
        <div className="relative min-w-[78%] snap-center sm:col-span-2 sm:min-w-0">
          <Card icon="◉" tag="GLOBAL-THREAT-INDEX" title={L("বৈশ্বিক হুমকি সূচক", "Global Threat Index", "مؤشر التهديد العالمي")} value={s ? s.gti : null} suffix="/100" color="#f43f5e" series={ser?.all ?? []} sub={L("সময়-ক্ষয়সহ ভারযুক্ত প্রতিবেদন-তীব্রতা", "decay-weighted report severity", "شدة التقارير المرجحة")} />
        </div>
      </div>
    </Section>
  );
}
