"use client";
import { memo, useEffect, useRef, useState, useSyncExternalStore, type ReactNode, type RefObject } from "react";
import { useLang } from "@/lib/i18n";
import { LEVEL_COLOR, LEVEL_LABEL, type ThreatLevel } from "@/lib/types";

/** Pause CSS animations (via .is-off) when a block is off-screen. */
export function useInView<T extends Element>(margin = "150px"): [RefObject<T | null>, boolean] {
  const ref = useRef<T | null>(null);
  const [vis, setVis] = useState(true);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(([e]) => setVis(e.isIntersecting), { rootMargin: margin });
    io.observe(el);
    return () => io.disconnect();
  }, [margin]);
  return [ref, vis];
}

/** Mount children only once the block approaches the viewport (lazy sections). */
export function LazyMount({ children, minH = 480, id }: { children: ReactNode; minH?: number; id?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const [on, setOn] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) {
          setOn(true);
          io.disconnect();
        }
      },
      { rootMargin: "700px" },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return (
    <div ref={ref} data-lazy={id} style={on ? undefined : { minHeight: minH }}>
      {on ? children : null}
    </div>
  );
}

export function Hud({
  children,
  className = "",
  title,
  right,
  accent,
  pad = true,
}: {
  children: ReactNode;
  className?: string;
  title?: string;
  right?: ReactNode;
  accent?: string;
  pad?: boolean;
}) {
  return (
    <div className={`hud ${className}`} style={accent ? { borderColor: `${accent}55` } : undefined}>
      <i className="hud-br tl" style={accent ? { borderColor: accent } : undefined} />
      <i className="hud-br tr" style={accent ? { borderColor: accent } : undefined} />
      <i className="hud-br bl" style={accent ? { borderColor: accent } : undefined} />
      <i className="hud-br brr" style={accent ? { borderColor: accent } : undefined} />
      <span className="hud-cross" style={{ top: 3, left: "50%" }}>+</span>
      <span className="hud-cross" style={{ bottom: 3, left: "50%" }}>+</span>
      {title && (
        <div className="flex items-center justify-between gap-2 border-b border-cyan-500/15 px-3 py-1.5">
          <span className="hud-title">{title}</span>
          {right}
        </div>
      )}
      <div className={pad ? "p-3 sm:p-4" : ""}>{children}</div>
    </div>
  );
}

export function Section({ id, tag, title, subtitle, children, className = "" }: { id: string; tag: string; title: string; subtitle?: string; children: ReactNode; className?: string }) {
  const [ref, vis] = useInView<HTMLElement>("100px");
  return (
    <section id={id} ref={ref} className={`relative mx-auto w-full max-w-[1500px] px-3 py-10 sm:px-6 sm:py-14 ${vis ? "" : "is-off"} ${className}`}>
      <div className="mb-6 flex items-end gap-3">
        <div className="h-10 w-1 bg-cyan-400/80" />
        <div>
          <div className="hud-title mb-1 !text-[10px]">{tag}</div>
          <h2 className="font-display text-xl font-bold tracking-wide text-white sm:text-3xl">{title}</h2>
          {subtitle && <p className="mt-1 max-w-3xl text-sm text-slate-400">{subtitle}</p>}
        </div>
        <div className="ml-auto hidden h-px flex-1 bg-gradient-to-r from-cyan-500/40 to-transparent md:block" />
      </div>
      {children}
    </section>
  );
}

export const Num = memo(function Num({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <span className={`mono ${className}`}>{children}</span>;
});

export const LevelBadge = memo(function LevelBadge({ level, bracket = true }: { level: ThreatLevel; bracket?: boolean }) {
  const { lang } = useLang();
  const c = LEVEL_COLOR[level];
  const label = LEVEL_LABEL[level][lang];
  const sfx = lang === "bn" ? " সতর্কতা" : lang === "ar" ? "" : "";
  return (
    <span className="inline-flex items-center gap-1.5 px-1.5 py-0.5 text-[11px] font-semibold" style={{ color: c, border: `1px solid ${c}66`, background: `${c}14` }}>
      <span className={`h-1.5 w-1.5 ${level === "CRITICAL" || level === "HIGH" ? "a-alert" : ""}`} style={{ background: c }} />
      {bracket ? `[${label}${sfx}]` : label}
      <span className="mono text-[9px] opacity-70">{level}</span>
    </span>
  );
});

/* shared minute ticker for all relative timestamps */
const tickL = new Set<() => void>();
let tickN = 0;
let tickT: ReturnType<typeof setInterval> | null = null;
const tickSub = (cb: () => void) => {
  tickL.add(cb);
  if (!tickT)
    tickT = setInterval(() => {
      tickN++;
      tickL.forEach((l) => l());
    }, 30000);
  return () => {
    tickL.delete(cb);
    if (!tickL.size && tickT) {
      clearInterval(tickT);
      tickT = null;
    }
  };
};

export const Ago = memo(function Ago({ iso }: { iso: string }) {
  const { lang } = useLang();
  useSyncExternalStore(tickSub, () => tickN, () => 0);
  const mins = Math.max(0, Math.floor((Date.now() - Date.parse(iso)) / 60000));
  if (mins < 1) return <span>{lang === "bn" ? "এইমাত্র" : lang === "ar" ? "الآن" : "just now"}</span>;
  const [n, unit] =
    mins < 60
      ? [mins, lang === "bn" ? "মিনিট আগে" : lang === "ar" ? "دقيقة مضت" : "min ago"]
      : mins < 1440
        ? [Math.floor(mins / 60), lang === "bn" ? "ঘণ্টা আগে" : lang === "ar" ? "ساعة مضت" : "h ago"]
        : [Math.floor(mins / 1440), lang === "bn" ? "দিন আগে" : lang === "ar" ? "يوم مضى" : "d ago"];
  return (
    <span>
      <span className="mono">{n}</span> {unit}
    </span>
  );
});

/** Animated number: tweens through requestAnimationFrame only while the value changes. */
export const AnimNum = memo(function AnimNum({ value, decimals = 0, suffix = "", className = "" }: { value: number; decimals?: number; suffix?: string; className?: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const cur = useRef(0);
  useEffect(() => {
    const from = cur.current;
    const t0 = performance.now();
    let id = 0;
    const step = (t: number) => {
      const k = Math.min(1, (t - t0) / 700);
      const e = 1 - Math.pow(1 - k, 3);
      cur.current = from + (value - from) * e;
      if (ref.current) ref.current.textContent = cur.current.toFixed(decimals) + suffix;
      if (k < 1) id = requestAnimationFrame(step);
    };
    id = requestAnimationFrame(step);
    return () => cancelAnimationFrame(id);
  }, [value, decimals, suffix]);
  return (
    <span ref={ref} className={`mono ${className}`}>
      {value.toFixed(decimals)}
      {suffix}
    </span>
  );
});

export const Sparkline = memo(function Sparkline({ data, color = "#22d3ee", h = 30 }: { data: number[]; color?: string; h?: number }) {
  const w = 120;
  const max = Math.max(1, ...data);
  const pts = data.map((v, i) => `${((i / Math.max(1, data.length - 1)) * w).toFixed(1)},${(h - 2 - (v / max) * (h - 5)).toFixed(1)}`);
  const id = `sg${color.replace("#", "")}`;
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="h-8 w-full" preserveAspectRatio="none" aria-hidden>
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={color} stopOpacity=".35" />
          <stop offset="1" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <polygon points={`0,${h} ${pts.join(" ")} ${w},${h}`} fill={`url(#${id})`} />
      <polyline points={pts.join(" ")} fill="none" stroke={color} strokeWidth="1.4" vectorEffect="non-scaling-stroke" />
    </svg>
  );
});

export function Empty({ children }: { children: ReactNode }) {
  return <div className="border border-dashed border-cyan-500/20 px-3 py-6 text-center text-sm text-slate-400">{children}</div>;
}
