"use client";
import { sfx } from "@/lib/audio";
import { scrollToId } from "@/lib/commands";
import { useLang } from "@/lib/i18n";

const ITEMS: [string, string, string, string, string][] = [
  ["news", "◉", "ব্রেকিং", "News", "عاجل"],
  ["map", "⌖", "ম্যাপ", "Map", "خريطة"],
  ["dashboard", "▦", "ড্যাশ", "Dash", "لوحة"],
  ["analysis", "◈", "এআই", "AI", "ذكاء"],
  ["wargame", "☢", "সিম", "Sim", "محاكاة"],
];

/** Tactical bottom navigation — mobile only. */
export default function MobileNav() {
  const { L } = useLang();
  return (
    <nav className="fixed inset-x-0 bottom-0 z-50 grid grid-cols-5 border-t border-cyan-500/30 bg-[#060a12]/95 pb-[env(safe-area-inset-bottom)] md:hidden">
      {ITEMS.map(([id, icon, bn, en, ar]) => (
        <button
          key={id}
          onClick={() => {
            sfx.click();
            scrollToId(id);
          }}
          className="flex flex-col items-center gap-0.5 py-2 text-slate-300 active:bg-cyan-400/10"
        >
          <span className="mono text-base leading-none text-cyan-300">{icon}</span>
          <span className="text-[10px]">{L(bn, en, ar)}</span>
        </button>
      ))}
    </nav>
  );
}
