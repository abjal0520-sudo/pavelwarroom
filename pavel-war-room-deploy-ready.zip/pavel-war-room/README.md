# PAVEL WAR ROOM

A Next.js OSINT dashboard that aggregates publicly available reporting and selected open datasets. It is not a military command system and does not have access to classified or complete military telemetry.

## Requirements

- Node.js 20.9 or newer (Node.js 22 LTS is recommended)
- npm
- Optional: a hosted PostgreSQL database for persistent news history and translation caching

## Run locally

```bash
npm install
cp .env.example .env.local
npm run dev
```

Open http://localhost:3000.

The app can start without `DATABASE_URL`. In that mode, live feeds and the dashboard remain available, but database-backed history and cross-invocation translation caching are disabled. Add a hosted PostgreSQL connection string to enable persistence.

## Environment variables

| Variable | Required | Purpose |
| --- | --- | --- |
| `DATABASE_URL` | No | Hosted PostgreSQL connection string for persistent history and translation cache |
| `NEWSAPI_KEY` | No | Additional news aggregation source |
| `ACLED_KEY` | No | ACLED conflict-event dataset access |
| `ACLED_EMAIL` | No | Email associated with the ACLED credential |
| `FIRMS_MAP_KEY` | No | NASA FIRMS active-fire data |
| `OPENSKY_USER` | No | Optional OpenSky account username |
| `OPENSKY_PASS` | No | Optional OpenSky account password |

Never add secret keys with a `NEXT_PUBLIC_` prefix. These credentials must remain server-side.

## PostgreSQL setup

Create a PostgreSQL database with a managed provider such as Neon or Supabase. Copy its connection string into `DATABASE_URL`, then run:

```bash
npm run db:push
```

For migration-based deployment, use `npm run db:generate` when the schema changes, commit the generated `drizzle/` migration files, and run `npm run db:migrate` against the target database.

## Build and run

```bash
npm run typecheck
npm run lint
npm run build
npm run start
```

## Deploy to Vercel

1. Push this folder to a GitHub repository.
2. In Vercel, import the repository. Vercel should detect Next.js automatically.
3. Use the project root as the Root Directory. Keep the build command as `npm run build` and install command as `npm install` (the defaults are fine).
4. Add whichever environment variables you use under Project Settings → Environment Variables. `DATABASE_URL` is optional; add it only after creating a hosted PostgreSQL database.
5. Deploy. If you add or change environment variables, redeploy so the new values are applied.
6. Check `/api/health`. It reports whether PostgreSQL is connected, not configured, or unavailable.

Do not deploy with the local placeholder URL `127.0.0.1`. On Vercel that address refers to the function's own runtime, not your computer.

## Deploy to Netlify

Connect the same Git repository and let Netlify detect Next.js. Use `npm run build` as the build command if it is not detected automatically. Add the same server-side environment variables in Site configuration → Environment variables. The app uses Node.js route handlers and is not a static-export-only site.

## Data integrity notes

- BBC and Al Jazeera items are collected from their public RSS feeds.
- Reuters and AP items in this project are discovered through Google News RSS queries; this is not direct access to Reuters or AP licensed APIs.
- GDELT is a media-monitoring index. A GDELT result means coverage was observed, not that an event has been independently confirmed.
- NewsAPI and ACLED are included only when valid credentials are configured.
- OpenSky shows aircraft that its public ADS-B network can observe. It is not a complete military aircraft picture.
- NASA FIRMS points are satellite fire/thermal detections, not proof of a missile strike or explosion. NASA EONET fallback items are labelled separately.
- Satellite positions are derived from published orbital elements (TLE), not live classified tracking.
- The missile/event route graphics are derived from locations mentioned in news reports. They are not missile telemetry.
- Threat and risk indicators are heuristic estimates derived from collected reports. They are not official government threat levels or predictions.

When a source is unavailable, the dashboard should show that source as unavailable rather than inventing replacement events.
